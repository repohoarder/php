<?php 
session_start();

$submitted	= isset($_REQUEST['Email'])? true: false;

if($submitted):

	$error = false;

	// error checking	
	if(empty($_REQUEST['FirstName']) || $_REQUEST['FirstName'] == "First Name") $error = "Please enter valid first name.";
	if(empty($_REQUEST['LastName']) || $_REQUEST['LastName'] == "Last Name") $error = "Please enter valid last name.";
	if(empty($_REQUEST['Address']) || $_REQUEST['Address'] == "Address") $error = "Please enter valid address.";
	if(empty($_REQUEST['Email']) || $_REQUEST['Email'] == "Email") $error = "Please enter valid email.";
	if(empty($_REQUEST['City']) || $_REQUEST['City'] == "City") $error = "Please enter valid city.";	
	if(empty($_REQUEST['PostalCode']) || $_REQUEST['PostalCode'] == "Postal Code" || !is_numeric($_REQUEST['PostalCode'])) $error = "Please enter valid zip code.";
	if(empty($_REQUEST['State'])) $error = "Please select state.";

	// if no errors, set session and redirect
	if(!$error): 
		
		// set session
		$_SESSION['first_name']	= $_REQUEST['FirstName'];
		$_SESSION['last_name']	= $_REQUEST['LastName'];
		$_SESSION['email']		= $_REQUEST['Email'];
		$_SESSION['phone']		= '5555555555';
		$_SESSION['address']	= $_REQUEST['Address'];
		$_SESSION['city']		= $_REQUEST['City'];
		$_SESSION['state']		= $_REQUEST['State'];
		$_SESSION['zip']		= $_REQUEST['PostalCode'];
		$_SESSION['country']	= 'USA';
		
		// redirect
		header("Location: checkout.php");
	endif;
else:

	$_SESSION['affiliate_id']	= ($_REQUEST['aff'])? $_REQUEST['aff']: $_SESSION['affiliate_id'];
	$_SESSION['subid']			= ($_REQUEST['subid'])? $_REQUEST['subid']: $_SESSION['subid'];

endif;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Slim Quick</title>
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>

<body>

<div id="form_container">
	
    <div id="form" class="center">
    	
    	<?php 
    	if($error) echo "<center><p style='color:red;'>$error</p></center>";
    	?>
    	
       	<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <input value="<?php echo ($_REQUEST['FirstName'])? $_REQUEST['FirstName']: "First Name"; ?>" type="text" name="FirstName" id="FirstName" value="First Name" onblur="if(this.value==''){this.value='First Name';}" onfocus="if(this.value=='First Name'){this.value='';}" />
            <input value="<?php echo ($_REQUEST['LastName'])? $_REQUEST['LastName']: "Last Name"; ?>" type="text" name="LastName" id="LastName" value="Last Name" onblur="if(this.value==''){this.value='Last Name';}" onfocus="if(this.value=='Last Name'){this.value='';}" />
            <input value="<?php echo ($_REQUEST['Address'])? $_REQUEST['Address']: "Address"; ?>" type="text" name="Address" id="Address" value="Address" onblur="if(this.value==''){this.value='Address';}" onfocus="if(this.value=='Address'){this.value='';}" />
            <input value="<?php echo ($_REQUEST['PostalCode'])? $_REQUEST['PostalCode']: "Postal Code"; ?>" type="text" name="PostalCode" id="PostalCode" value="Potal Code" onblur="if(this.value==''){this.value='Postal Code';}" onfocus="if(this.value=='Postal Code'){this.value='';}" />
            <input value="<?php echo ($_REQUEST['City'])? $_REQUEST['City']: "City"; ?>" type="text" name="City" id="City" value="City" onblur="if(this.value==''){this.value='City';}" onfocus="if(this.value=='City'){this.value='';}" />
            <select name="State" id="State">
                <option value="" local="office_global_select">State</option>
                <option value="AL">Alabama</option>
                <option value="AK">Alaska</option>
                <option value="AZ">Arizona</option>
                <option value="AR">Arkansas</option>
                <option value="AA">Armed Forces Americas</option>
                <option value="AE">Armed Forces Europe</option>
                <option value="AP">Armed Forces Pacific</option>
                <option value="CA">California</option>
                <option value="CO">Colorado</option>
                <option value="CT">Connecticut</option>
                <option value="DE">Delaware</option>
                <option value="DC">District of Columbia</option>
                <option value="FL">Florida</option>
                <option value="GA">Georgia</option>
                <option value="GU">Guam</option>
                <option value="HI">Hawaii</option>
                <option value="ID">Idaho</option>
                <option value="IL">Illinois</option>
                <option value="IN">Indiana</option>
                <option value="IA">Iowa</option>
                <option value="KS">Kansas</option>
                <option value="KY">Kentucky</option>
                <option value="LA">Louisiana</option>
                <option value="ME">Maine</option>
                <option value="MD">Maryland</option>
                <option value="MA">Massachusetts</option>
                <option value="MI">Michigan</option>
                <option value="MN">Minnesota</option>
                <option value="MS">Mississippi</option>
                <option value="MO">Missouri</option>
                <option value="MT">Montana</option>
                <option value="NE">Nebraska</option>
                <option value="NV">Nevada</option>
                <option value="NH">New Hampshire</option>
                <option value="NJ">New Jersey</option>
                <option value="NM">New Mexico</option>
                <option value="NY">New York</option>
                <option value="NC">North Carolina</option>
                <option value="ND">North Dakota</option>
                <option value="OH">Ohio</option>
                <option value="OK">Oklahoma</option>
                <option value="OR">Oregon</option>
                <option value="PA">Pennsylvania</option>
                <option value="PR">Puerto Rico</option>
                <option value="RI">Rhode Island</option>
                <option value="SC">South Carolina</option>
                <option value="SD">South Dakota</option>
                <option value="TN">Tennessee</option>
                <option value="TX">Texas</option>
                <option value="UT">Utah</option>
                <option value="VT">Vermont</option>
                <option value="VI">Virgin Islands</option>
                <option value="VA">Virginia</option>
                <option value="WA">Washington</option>
                <option value="DC">Washington D.C.</option>
                <option value="WV">West Virginia</option>
                <option value="WI">Wisconsin</option>
                <option value="WY">Wyoming</option>
            </select>

            <input value="<?php echo ($_REQUEST['Email'])? $_REQUEST['Email']: "Email"; ?>" type="text" name="Email" id="Email" value="Email" onblur="if(this.value==''){this.value='Email';}" onfocus="if(this.value=='Email'){this.value='';}" />
            
            <br />
            <br />
            
            <div class="bold" style="font-size:12pt;">We respect your <a href="privacy.htm">privacy</a> and will not<br />share your information. Our <a href="terms.htm">Terms</a>.</div>
            
            
            <br />
        
            <input type="image" src="images/button.png" width="288" height="80" style="width: 288px; height: 80px;" />
    
    	</form>
    
    </div>
    
    
</div>


<div id="container">
	
    <div id="header_container">
   		<div id="header_banner">
        	
            <div id="logo"><img src="images/logo.png" width="335" height="77" alt="All Natural Slim Quick" /></div>        	
            <div id="try_it_now_bug"><img src="images/try_it_today.png" width="250" height="98" alt="Try It Now" /></div>
            
        </div>
    </div>
    
    <div id="header_white_layer_1"></div>
    <div id="header_white_layer_2"></div>
    
    <div id="content">
    
    	<div style="padding: 20px;"><img src="images/easy_way_to_lose.png" width="606" height="120" alt="The Easiest Way To Lose 20lbs" /></div>
        
        <div class="blue_line" style="height: 10px;"></div>
        
        <div style="padding: 40px 45px;">
        
        
		<script src="/flowplayer/flowplayer-3.2.8.min.js"></script>
		<a href="/video/phase2.flv" style="display:block;width:542px;height:302px;" id="player"></a>
	 
	    <script language="JavaScript">
	    	flowplayer("player", "/flowplayer/flowplayer-3.2.9.swf");
	    </script>
        
        
        <!-- 
        	<script src="js/AC_RunActiveContent.js" type="text/javascript" language="javascript"></script>
            <script src="js/valid.js" type="text/javascript" language="javascript"></script>
			<noscript>
				 <object width='542' height='302' id='flvPlayer'>
				  <param name='allowFullScreen' value='true'>
				  <param name='movie' value='OSplayer.swf?movie=video/phase2.flv&btncolor=0x333333&accentcolor=0x7f5bb2&txtcolor=0xffffff&volume=&previewimage=previewimageurl&autoplay=On&autoload=On&mute='>
				  <embed src='OSplayer.swf?movie=video/phase2.flv&btncolor=0x333333&accentcolor=0x7f5bb2&txtcolor=0xffffff&volume=&previewimage=previewimageurl&autoplay=On&autoload=On&mute=' width='542' height='302' allowFullScreen='true' type='application/x-shockwave-flash'>
				 </object>
				</noscript>
        
        	<!-- <img src="images/video_place_holder.png" width="542" height="302" alt="Video Place Holder" /> -->
        	
        </div>
        
        <div style="padding: 135px 0 25px 65px;"><img src="images/slim_quick_testimony.png" width="501" height="58" alt="I cannot imagine my life without Slim Quick" /></div>
        
        <div class="blue_line" style="height: 2px;"></div>
        
        <table cellpadding="0" cellspacing="0">
        <tr>
        	<td valign="top" class="left_column">         
            	<div style="padding: 20px;">
                    <h1>Slim Quick Works! <span class="small">See the results for yourself!</span></h1> 
                    
                    Slim Quick's revolutionary Phase 2 formula helps you lose weight by neutralizing the "starchy" components of carbohydrates and increases your body's ability to digest carbs while blocking the breakdown of starch to sugars or fat. One or more studies have shown that people using Slim Quick have also lost, on average, more than 10% of body fat mass and more than 3% in waist circumference.  This percentage is much higher than the typical amount of fat loss from a low-calorie diet alone.

					<br />
					<br />
                    
                	<h2>Lose Weight, Feel Great. Outsmart Fat Instead of Piling It On Cutting Out Foods You Love!</h2>
                    
                    <div class="clear" style="padding: 10px 0;">
                    	<img src="images/food.jpg" width="315" height="189" alt="Place Holder Image" style="margin: 0 10px 0 0; float: left;" />
                    	
                        <b class="green">DON'T GIVE UP YOUR FAVORITE FOODS</b><br />
						Pastas, Breads and other starch rich foods are the first to go in a low-calorie or carb restrictive diet. With Slim Quick, you can maintain a healthy lifestyle through exercise and diet, eat the foods you love and still lose weight.
                        
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        <br />
                        
                    </div>
                    
                    <h2 class="clear">PHASE 2® is clinically tested to reduce body fat!</h2>
                    
                    
                    <div class="clear" style="padding: 10px 0;">
                    	<img src="images/slim_quick_graph.png" width="315" height="189" alt="Place Holder Image" style="margin: 0 10px 0 0; float: left;" />
                    	
                        <b class="green">FAT LOSS AT WEEK 12 BURNED </b><br />
						Clinical trials have shown that the tertile of subjects who ate the most carbohydrates experienced a significant reduction in both weight and waist size with the addition of the white bean extract compared to the placebo group of the same tertile of carbohydrate consumption.
                        
                        <br />
                        <br />
                        <br />
                        <br />
                        
                        
                    </div>
                    
                </div>
            
                <div class="yellow_bar"><h2 class="black">The press has great things to say about Slim Quick's Phase 2®.</h2></div>
                
            	<div style="padding: 10px;">
                
			        <div class="blue_line" style="height: 2px;"></div>
                    
                    	<table cellpadding="10">
                        <tr>
                        	<td valign="top"><img src="images/dr_oz.png" width="117" height="54" alt="Dr. Oz" /></td>
                        	<td class="bold">"Studies prove that taking supplements that contain white kidney bean extract or raspberry ketones will stop your body from absorbing the carbs and fats from your meal."                           </td>
                        </tr>
                        </table>
                    
			        <div class="blue_line" style="height: 2px;"></div>
                    
                    	<table cellpadding="10">
                        <tr>
                        	<td valign="top"><img src="images/ucla.png" width="117" height="54" alt="UCLA" /></td>
                        	<td class="bold">UCLA researchers have found an extract in white kidney beans may help athe body stop carbs from breaking down into sugars. A digestive enzyme in the body normally acts like scissors, literally cutting starches into little sugars. Phase 2 stops the enzyme from cutting, so the starches stay in the body as long fibers and are burned off quicker. Patients in the clinical studies who took Phase 2 lost body fat, not lean muscle.</td>
                        </tr>
                        </table>
                    
                    
                </div>
            </td>
        	<td valign="top" class="right_column">   
            
            	<div style="padding: 20px 10px 0 0;">
            
                    <h1>Slim Quick is Natural.</h1> 
            
            		<img src="images/active_ingredients.png" width="390" height="73" alt="Active Ingredients" />
                    
                    	<table cellpadding="10">
                        <tr>
                        	<td class="bold">
                            <b>White Kidney Bean Extract (Phaseolamin) Phase 2®</b><br />
							Clinically shown to delay the digestion and absorption of starch calories, Phase 2 nuetralizes some of the digestive enzyme alpha amylase, allowing our bodies to digest carbs before they turn into fat.
							</td>
                        	<td valign="top"><img src="images/stuff-1.png" width="102" height="102" alt="Kidney Bean Extract" /></td>
                        </tr>
                        </table>
                    
			        <div class="blue_line" style="height: 2px;"></div>
                    
                    	<table cellpadding="10">
                        <tr>
                        	<td class="bold">
                            
                            <strong>Chromium (as amino acid chelate)</strong><br />
							After chromium enters the human body, it teams up with other elements to keep our metabolism tuned and efficient. Chromium is the central atom in the "glucose tolerance factor" (GTF), a hormone-like compound that works with insulin to transport glucose - the body's quickest fuel - out of the blood and into the cells.
                            
                            </td>
                        	<td valign="top"><img src="images/stuff-2.png" width="102" height="102" alt="Kidney Bean Extract" /></td>
                        </tr>
                        </table>
                    
			        <div class="blue_line" style="height: 2px;"></div>
                    
                    	<table cellpadding="10">
                        <tr>
                        	<td class="bold" valign="top">
                            
                            <strong>Guarana (seed), Panax ginseng (extract), Ginkgo biloba (leaf)</strong><br />
							Used together in a proprietary blend to aid in weight loss
                            
                            
                            </td>
                        	<td valign="top"><img src="images/stuff-3.png" width="102" height="102" alt="Kidney Bean Extract" /></td>
                        </tr>
                        </table>
                    
                    <div class="yellowish_box">What is Phase 2®?<br />Phase 2 Carb Controller™ is an all-natural, non-stimulant white kidney bean extract that is used as an ingredient in a variety of nutritional supplements. It is the first carbohydrate blocker clinically proven in multiple studies to delay the digestion and absorption of carbohydrates. This, in turn, reduces the caloric impact of starchy foods, and also lowers the glycemic index. When used in conjunction with a sensible diet and exercise, Phase 2 may assist in weight control. While there is no such thing as a magic weight control pill, Phase 2 may enable people concerned with weight control and/or blood glucose levels to enjoy carb-rich foods again in moderation.</div>
                    
                    <br />
                    <br />
                    
                    <a href="#form_container"><img src="images/say_no_to_fat.png" width="400" height="145" alt="Say No To Fat." /></a>
            
            	</div>
            
            </td>            
        </tr>
        </table>
        
		<div class="blue_line" style="height: 2px;"></div> 
        
        <br />
        
        <table cellpadding="0" cellspacing="0">
        <tr>
        	<td valign="top" class="left_column" style="width: 600px; padding: 0 10px 0 0;">    
                 
                 <div style="padding: 0 0 0 10px;">
                    
                    <h1>People all over America are losing weight<br />& feeling great!</h1> 
                    
                    <img src="images/befor_after_1.png" width="194" height="186" alt="Before and After" />
                    <img src="images/befor_after_2.png" width="194" height="186" alt="Before and After" />
                    <img src="images/befor_after_3.png" width="194" height="186" alt="Before and After" />
                    <img src="images/befor_after_4.png" width="194" height="186" alt="Before and After" />
                    <img src="images/befor_after_5.png" width="194" height="186" alt="Before and After" />
                    <img src="images/befor_after_6.png" width="194" height="186" alt="Before and After" />

                 </div>  
                  
                  <br />
                  
                  <img src="images/risk-free.png" width="610" height="42" />
                  
                  <br />
                  <br />
                  
                  <a href="#form_container"><img src="images/trial_order.png" width="610" height="80" /></a>
                  
            </td>
        	<td valign="top" class="right_column" style="padding: 0 0 0 10px">   
            
                <div class="yellowish_box" style="padding: 5px;">
                
                	<div class="video_player_blue"><a href="#form_container"><img src="images/measure.jpg" width="340" height="233" /></a></div>
                
                	<div class="box_quote">
                    	"I had a great experience with Slim Quick. My energy increased. It helped control my appetite. My body was getting cut all while having no adverse feelings like caffeine does. Slim Quick is totally natural and feels totally natural."
						<div class="right">— Alejandro M., Los Angeles</div>
                    </div>
                
                	<div class="box_quote">
                    	"Slim Quick was the boost I needed to get back into my skinny jeans. My midsection is definitely leaner. My arms, hips, and thighs have slimmed and tightened too. Now I have more energy and sleep better!"
						<div class="right">— Jessica B., Cleveland</div>
                    </div>
                
                	<div class="box_quote">
                    	"I've struggled with weight for the past 10 years. I've tried everything and nothing has made a difference until Slim Quick. In less than a month, my BMI has gone down and I'm wearing two sizes smaller!" 
						<div class="right">— Lisa K., Tucson</div>
                    </div>
                
                </div>
                
            </td>            
        </tr>
        </table>
            
        <br />
        
        <div class="center">
        
        	<img src="images/compare.png" width="980" height="495" />
            
            <br />
            <br />
            
           	<h2>Slim Quick is the best all natural weight loss supplement. Other dietary programs cannot compare.</h2>
        
        
	    </div>
        
            <br />
            
        <div class="blue_line" style="height: 2px;"></div>
            
        <div class="left" style="padding: 10px;">
        	
            <h1>Slim Quick is offering an Internet-Only 14 DAY TRIAL!</h1>
            <h2>Let Slim Quick help you reach your weight loss goals. It's easy! Just follow the steps below.</h2>
            
        </div>
            
    </div>
    
</div>
<div id="bottom_flags">
	<a href="#form_container"><img src="images/send_my_order.png" width="1100" height="210" alt="Send me my trial order" /></a>
	<img src="images/waiting_for.png" width="1100" height="140" alt="What are you waiting for" />
</div>

<?php include("footer.php"); ?>
