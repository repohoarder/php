<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Slim Quick</title>
<link rel="stylesheet" type="text/css" href="style.css"/>

<style>
	
	input
	{
		border: 1px solid #00aeef;
		padding: 5px;
		margin: 5px 0  0;
	}
	select
	{
		border: 1px solid #00aeef;
		padding: 4px;
	}
</style>
</head>

<?php include("pixel.php"); ?>

<body>
<p style="font-size:18pt;font-weight:bold;text-align:center;margin: 50px 50px 50px 50px;">Thank You!</p>
</body>
</html>

<?php //include("footer.php"); ?>