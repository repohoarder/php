<?php 
session_start();
include("db.php");

$submitted	= isset($_REQUEST['CardNumber'])? true: false;

if($submitted):
	
	// initialize variables
	$error	= false;
	$sid	= "89";
	
	# Affiliate ID
	$affiliate_id	= $_SESSION['affiliate_id'];
	$subid			= $_SESSION['subid'];
	
	# Address variables
	$pfirstname	= $_SESSION['first_name'];
	$plastname	= $_SESSION['last_name'];
	$pphone		= $_SESSION['phone'];
	$pemail		= $_SESSION['email'];
	$paddress1	= $_SESSION['address'];
	$pcity		= $_SESSION['city'];
	$pstate		= $_SESSION['state'];
	$pzip		= $_SESSION['zip'];
	$pcountry	= $_SESSION['country'];
	
	# CC Details
	$ccnum	= $_REQUEST['CardNumber'];
	$cvv	= $_REQUEST['CVV'];
	$month	= $_REQUEST['Month'];
	$year	= $_REQUEST['Year'];
	$amount	= "4.95";
	$agree	= isset($_REQUEST['agree'])? true: false;
	
	if(!is_numeric($ccnum)) $error	= "Please enter valid Credit Card.";
	if(!is_numeric($cvv)) $error	= "Please enter valid CVV.";
	if(empty($month) || empty($year)) $error	= "Please enter valid Expiration Date.";
	if(!$agree) $error	= "You must agree to the terms and conditions.";
	
	if(!$error):
	
		$url		= "https://secure.chargebackguardiangateway.com/api/transact.php"; 
		$post_array	= array(
			'type'		=> 'sale',
			'username'	=> 'stratixhealthcbggw',
			'password'	=> 'letmein1',
			'ccnumber'	=> $ccnum,
			'ccexp'		=> $month.$year,
			'amount'	=> $amount
		);
	
		// generate query string from post_data
		$query_string = http_build_query($post_array);
		
		// initialize curl
		$ch = curl_init();
		
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

		$results = curl_exec ($ch);
		
		// clean up response
		$clean	= explode("&",$results);
		foreach($clean AS $key => $value):
			$cleaner	= explode("=",$value);
			$response[$cleaner[0]]	= $cleaner[1];
		endforeach;
	
		// store info in DB
		// insert transaction into spc_orders table
		$sql = "
		INSERT INTO spc_orders 
		(firstname, lastname, ccnum, ccfour, cctype, ccexp, address, city, state, zip, phone, email, country, ip, amount, datetime, itemsarray, referrer, returnurl, affid, passover, paymentstatus, transactionid, responsecode, responsetext, pid, sid, gatewayid, isupsell, user_agent) 
		VALUES 
		('".mysql_real_escape_string($firstname)."', '".mysql_real_escape_string($lastname)."', '".mysql_real_escape_string($ccnum)."', ccfour, '$cvv', '".mysql_real_escape_string($month.$year)."', '".mysql_real_escape_string($address1)."', '".mysql_real_escape_string($city)."', '".mysql_real_escape_string($state)."', '".mysql_real_escape_string($zip)."', '".mysql_real_escape_string($phone)."', '".mysql_real_escape_string($email)."', '".mysql_real_escape_string($country)."', '".mysql_real_escape_string($ip)."', '".mysql_real_escape_string($amount)."', NOW(), 'Slim Quick Fast', '".mysql_real_escape_string($_SERVER['HTTP_HOST'])."', '".mysql_real_escape_string($_SERVER['HTTP_HOST'])."', '".mysql_real_escape_string($_SESSION['affiliate_id'])."', '".mysql_real_escape_string($_SESSION['subid'])."', '".$responses['authcode']."', '".$responses['transactionid']."', '".$responses['response_code']."', '".$responses['responsetext']."', '89', '89', '0', '0', '".mysql_real_escape_string($_SERVER['HTTP_USER_AGENT'])."')";
		mysql_query($sql);
	
		// if success, move to thank you
		if($response == "Success"):
			header("Location: thankyou.php");
		endif;
	
		$error = $response;
		
	endif;
	
endif;


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Slim Quick</title>
<link rel="stylesheet" type="text/css" href="style.css"/>

<style>
	
	input
	{
		border: 1px solid #00aeef;
		padding: 5px;
		margin: 5px 0  0;
	}
	select
	{
		border: 1px solid #00aeef;
		padding: 4px;
	}
</style>
</head>

<body>

<div id="complete_container">
	
    <div id="coupon_code_form" style="float:left; margin: 600px 0 0 115px;">
       <input type="text" id="coupon_code" name="coupon_code" value="COUPON CODE" onblur="if(this.value==''){this.value='COUPON CODE';}" onfocus="if(this.value=='COUPON CODE'){this.value='';}" /><input type="submit" value="APPLY" style="padding: 4px; color: #fff; background: #00aeef; cursor: pointer;" />
    </div>
    
    
    <div id="complete" class="center">
    	
        <div style="padding: 0px 30px; text-align:left">
        
        <?php 
        if($error) echo "<center><p style='color:red;font-weight:bold;'>$error</p></center>";
        ?>
        
        <img src="images/icons.png" width="166" height="35" />
        
       	<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        	
            <span class="blue">Card Type</span>
            <select name="CardType" id="CardType" style="width: 214px;">
                <option value="Visa">Visa</option>
                <option value="MasterCard">MasterCard</option>
            </select>
        	
            <input type="text" name="CardNumber" id="CardNumber" value="Card Number" onblur="if(this.value==''){this.value='Card Number';}" onfocus="if(this.value=='Card Number'){this.value='';}" style="width: 287px;" />
            <input type="text" name="CVV" id="CVV" value="CVV" onblur="if(this.value==''){this.value='CVV';}" onfocus="if(this.value=='CVV'){this.value='';}" style="width: 200px; margin-bottom: 5px;" />&nbsp;&nbsp;&nbsp;(what is this?)
	

            <span class="blue">EXPIRATION</span>
            
            
            <select name="Month" id="Month" style="width: 100px;">
                <option value="">Month</option>
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
                <option value="04">04</option>
                <option value="05">05</option>
                <option value="06">06</option>
                <option value="07">07</option>
                <option value="08">08</option>
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select>
            <select name="Year" id="Year" style="width: 100px;">
                <option value="">Year</option>
                <option value="2012">2012</option>
                <option value="2013">2013</option>
                <option value="2014">2014</option>
                <option value="2015">2015</option>
                <option value="2016">2016</option>
            </select>
            
            <br />
            <br />
            
            <div class="center smaller"  style="font-size:12pt;">
            SlimQuick takes <a href="privacy.htm">privacy</a> & security seriously. We use
			the most advanced form of SSL encryption
			technologies to secure your transaction.
            
            <br />            
            <br />
            
            <table align="center">
            <tr>
            	<td valign="top"><input type="checkbox" name="agree" style="border: none" /></td>
            	<td class="left" style="font-size:12pt;">I have read, understand and agree<br />to the <a href="terms.htm">Terms and Conditions</a></td>
            </tr>
            </table>
            
            </div>
            
            
            
            <br />
            <br />
        
            <input type="image" src="images/rush.png" width="300" height="80" style="width: 300px; height: 80px; border: none;" />
    
    	</form>
        
    	</div>
    </div>
    
    
</div>



<div id="container">
	
    <div id="header_container">
   		<div id="header_banner">
        	
            <div id="logo"><img src="images/logo.png" width="335" height="77" alt="All Natural Slim Quick" /></div>        	
            
        </div>
    </div>
    
    <div id="header_white_layer_1"></div>
    <div id="header_white_layer_2"></div>
    
    <div id="content">
    
    	<div style="padding: 10px 0 30px 10px; font-size: 16px;" class="bold">
        
        	<h1 style="font-size: 36px;">Congratualtions!</h1>
            
            You are one step closer to a slimmer, more confident you.<br />
			Please enter your billing information for the shipping and handling fees.
            
            <br />
        
        </div>
    	
    
        
        <div class="blue_line" style="height: 10px;"></div>
        
        <div class="blue_border" style="margin: 40px 40px; padding: 30px; width: 482px; height: 245px;">
        
        	<table cellpadding="0" cellspacing="0">
            <tr>
	            <td valign="top" style="padding: 0 20px 0 0;"><h1>SLIMQUICK 14 DAY TRIAL</h1></td>
	            <td class="yellow_background"><img src="images/bottle.jpg" width="100" /></td>
	            <td valign="top" style="padding: 0 10px 0; text-align: right">
                	
                    <h1>$0.00</h1>
                    
                    
                    <br />
                    <br />
                    <br />
                    
                    <img src="images/free.png" width="91" height="91" alt="Free" />
                
                
                </td>
            </tr>
            <tr>
	            <td colspan="2" style="padding: 20px 0px 0 20px; text-align: right"><h2>SlimQuick Shipping</h2></td>
	            <td style="padding: 20px 10px 0; text-align: right"><h2>$4.95</h2></td>
            </tr>
            <tr>
	            <td></td>
	            <td style="padding: 20px 0px 0 20px; text-align: right"><h2>TOTAL</h2></td>
	            <td style="padding: 20px 10px 0; text-align: right"><h2>$4.95</h2></td>
            </tr>
            </table>
        
        
        </div>
        
        
        <div class="smaller" style="width: 542px; margin: 130px 0 0 0; padding: 0 45px 45px 45px;">
        Details: There is a small shipping and handling fee charged to ship the item to you today. You will receive your Slim Quick within 3-4 business days of them being shipped and are only being charged the total amount listed above today to start your trial. Pursuant to this trial offer you will be billed the full Slim Quick membership joining fee of $89.97 unless you cancel before the expiration of the fourteen day trial period. Slim Quick is a supplemental product that goes along with the Slim Quick program portal website that you get access to. You can cancel at any time by emailing us at support@slimquickfast.com or by calling (801) 610-4600. The Slim Quick auto-ship program ships you out a new supply every month for the full Slim Quick membership price unless cancelled. The trial period begins upon your order date as this is when you are given access to the Slim Quick portal website.
        </div>
        
            
    </div>
    
</div>

<?php include("footer.php"); ?>

