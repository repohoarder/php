<div id="footer">
    
    Copyright &copy; 2012 SlimBlastFast.com. All Rights Reserved.<br />
    Slim Blast Fast Customer Care: (801) 610-4600 available 9:00am &middot; 5:00pm EST Mon. to Fri.<br />
    <a href="privacy.htm">Privacy Policy by TRUSTe</a> | <a href="terms.htm">Terms & Conditions</a> | <a href="contact.php">Contact</a><br /><br />
    
    <span class="smaller">
    *The statements made on this website have not been evaluated by the Food & Drug Administration. The FDA evaluates only food and drugs,<br />
    not supplements like this product. This product is not intended to diagnose, prevent, treat, or cure any disease.
    </span>

</div>

</body>
</html>