<?php 
session_start();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Slim Quick</title>
<link rel="stylesheet" type="text/css" href="style.css"/>

<style>
	
	input
	{
		border: 1px solid #00aeef;
		padding: 5px;
		margin: 5px 0  0;
	}
	select
	{
		border: 1px solid #00aeef;
		padding: 4px;
	}
</style>
</head>

<body>





<div id="container">
	
    <div id="header_container">
   		<div id="header_banner">
        	
            <div id="logo"><img src="images/logo.png" width="335" height="77" alt="All Natural Slim Quick" /></div>        	
            
        </div>
    </div>
    
    <div id="header_white_layer_1"></div>
    <div id="header_white_layer_2"></div>
    
    <div id="content">
    
    	<div style="padding: 10px 0 30px 10px; font-size: 16px;" class="bold">
        
        	<h1 style="font-size: 36px;">Slim Quick Fast Contact Information</h1>
            
            <br />
        
        </div>
    	
    
        
        <div class="blue_line" style="height: 10px;"></div>
        

        
        
        <div class="" style="width: 542px; margin: 130px 0 0 0; padding: 0 45px 45px 45px;">
			
			<p><strong>Corportate Information</strong></p>
			<p>5255 North Edgewood Drive, Suite 125</p>
			<p>Provo, UT 84604</p>
			<p>Phone: (801) 610-4600</p>
			
			<br>
			
			<p><strong>Customer Support</strong></p>
			<p>Email: support@slimquickfast.com</p>
			<p>Phone: (801) 610-4600</p>
			                    
        </div>
        
            
    </div>
    
</div>

<?php include("footer.php"); ?>

