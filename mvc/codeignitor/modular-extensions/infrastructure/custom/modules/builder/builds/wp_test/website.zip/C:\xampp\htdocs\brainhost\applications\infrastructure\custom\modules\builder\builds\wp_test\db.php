<?php 
$dbuser = '577988_crm';
$dbpass	='Rx45hnj23kl54!';
$dbhost ='mysql50-86.wc2';
$db = '577988_crm';
$dbconn = mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect');
mysql_select_db($db,$dbconn);
?>