<?php

class Dashboard extends MX_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$data 	= array();

		// grab lead data
		$leads 	= $this->platform->post('argall/lead/get');

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin');

		// set data variables
		$data['warnings']	= array('You have used approximately 90% of your monthly usage.');

		// load view
		$this->template->build('dashboard/dashboard', $data);
	}
}