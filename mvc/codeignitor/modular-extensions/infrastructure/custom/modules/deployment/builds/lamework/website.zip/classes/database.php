<?php

class Database
{
	var $_host	= "localhost",
		$_user 	= "freesola",
		$_pass 	= "Matthew20!",
		$_db 	= "freesola_receptive",
		$_conn 	= FALSE;

	public function __construct($host=FALSE,$user=FALSE,$pass=FALSE)
	{
		// if custom host, user and password are passed, then set them
		if ($host AND $user AND $pass):
			
			// set custom connection variables
			$this->_host 	= $host;
			$this->_user 	= $user;
			$this->_pass 	= $pass;

		endif;

		// connect to database
		$this->_connect();
	}

	public function insert($table,$insert)
	{
		// initialize variables
		$fields = array();
		$values = array();

		// iterate insert array to create fields and values string(s)
		foreach ($insert AS $key => $value):

			// add to fields and values arrays, respectively
			$fields[] 	= $key;
			$values[] 	= stripslashes($value);

		endforeach;

		// generate INSERT query
		$sql 	= '
		INSERT INTO 
			'.$table.'
		('.implode(',',$fields).')
			VALUES 
		("'.implode('","',$values).'")
		';

		// insert 
		$obj 	= mysql_query($sql,$this->_conn);

		return mysql_insert_id($this->_conn);
	}

	public function update($table,$where,$update)
	{

		// return num rows affected
		return mysql_num_rows($obj);
	}

	public function select($select,$table,$where,$only_return_first=FALSE)
	{
		// initialize variables
		$response 	= array();
		$clause 	= '';

		// iterate where clause
		$counter 	= 0;
		foreach ($where AS $key => $value):

			// increment counter
			$counter++;

			// add to where clause
			$clause .= $key.' = "'.stripslashes($value).'"';

			// if this isn't the last value, we need to add AND
			if ($counter < count($where))
				$clause 	.= ' AND ';

		endforeach;

		// generate INSERT query
		$sql 	= '
		SELECT 
			'.$select.'
		FROM 
			'.$table.'
		WHERE 
			'.$clause.'
		';

		// select
		$obj 	= mysql_query($sql,$this->_conn);		

		// iterate query object
		while ($row = mysql_fetch_assoc($obj)):

			// add to response
			$response[]	= $row;

		endwhile;

		// if only_return_first boolean, then set repsonse to the first record only
		if ($only_return_first AND isset($response[0]))
			$response	= $response[0];

		// return response
		return $response;
	}

	public function delete()
	{


	}

	public function sql($sql)
	{
		// initialize variables
		$response 	= array();

		// run query
		$obj		= mysql_query($sql);
		
		// iterate query object
		while ($row = mysql_fetch_assoc($obj)):

			// add to response
			$response[]	= $row;

		endwhile;

		// return response
		return $response;
	}

	private function _connect()
	{
		// if already connected, just move on
		if ( ! $this->_conn):

			// connect
			$this->_conn 	= mysql_connect($this->_host, $this->_user, $this->_pass) or die('Unable to connect to database (1)');

			// select database
			if ($this->_db)
				mysql_select_db($this->_db) or die('Unable to connect to database (2)');

		endif;
	}

	private function _disconnect()
	{
		mysql_close();
	}
}
