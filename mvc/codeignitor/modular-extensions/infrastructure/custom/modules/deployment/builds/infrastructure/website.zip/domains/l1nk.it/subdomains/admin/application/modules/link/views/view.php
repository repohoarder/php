
<div class="panel-wrapper"> 

	<div class="panel"> 

		<div class="title"> 
			
			<h4>View Links</h4> 

			<div class="collapse">collapse</div> 
		</div>  

		<div class="content"> 
			<!-- ## Panel Content  -->  
			<table id="sample-table" class=""> 
				<thead> 
					<tr> 
						<th>ID</th> 
						<th>URL</th> 
						<th>Redirect</th> 
						<th>Active</th>
					</tr> 
				</thead> 

				<tbody> 

					<?php
					// iterate all links
					foreach ($links AS $key => $value):
					?>

						<tr> 
							<td><?php echo $value['id']; ?></td> 
							<td><a href="<?php echo $value['domain']; ?>" target="_blank"><?php echo $value['domain']; ?></a></td>
							<td><?php echo $value['url']; ?></td>
							<td><?php echo ($value['active'])? 'Active': 'Inactive'; ?></td> 
						</tr> 

					<?php
					endforeach;
					?>

				</tbody> 
			</table>  
			<!-- ## / Panel Content  --> 

		</div> 
		
	</div>  

	<!-- <div class="shadow"></div> -->

</div>

