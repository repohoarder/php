<?php

class Offer extends MX_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		redirect('offer/create');
	}

	public function create()
	{
		$data 	= array();

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: Create Campaign');

		// load view
		$this->template->build('offer/create', $data);
	}

	public function view()
	{
		$data 	= array();

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: View Campaign(s)');

		// load view
		$this->template->build('offer/view', $data);	
	}

}