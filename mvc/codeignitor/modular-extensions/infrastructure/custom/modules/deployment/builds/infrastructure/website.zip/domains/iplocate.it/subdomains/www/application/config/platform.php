<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['platform']	= array(
	'url'	=> 'http://app.weblumps.com/',	// This is the Platform URL to use
	'salt'	=> '1pL0c4t3iT',
	'app'	=> 'iplocate.it'
);

if ($_SERVER['SERVER_ADDR'] == '127.0.0.1'):

	$infra_subdomain = explode('.',$_SERVER['SERVER_NAME']);
	array_shift($infra_subdomain);

	$config['platform']['url'] = 'http://app.weblumps.'.implode('.',$infra_subdomain).'/';
	
endif;
