<?php

require_once(CUSTOM_PATH.'core/MY_Hooks.php');