
<?php
// testing
$verticals 	= array(
	array(
		'id'	=> 1,
		'name'	=> 'Health'
	),
	array(
		'id'	=> 2,
		'name'	=> 'Insurance'
	),
);

?>

<div class="panel-wrapper fixed"> 

	<div class="panel ">  

		<div class="title"> 

			<h4>Campaign - Create New</h4> 

			<div class="collapse">collapse</div> 

		</div>  

		<div class="content"> <!-- ## Panel Content  -->  

			<form method="post" action="">

				<div class="group fixed"> 
					<label>Campaign Name</label> 
					<input type="text" value="" name="campaign" placeholder="Site Buyer Data" /> 
				</div>  

				<div class="group fixed"> 
					<label>Vertical</label> 
					<div id="uniform-undefined">
						<select name="vertical" style="opacity: 0;"> 
							<?php
							// iterate all domains
							foreach ($verticals AS $key => $value):
							?>
								<option value="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></option>
							<?php
							endforeach;
							?>
						</select>
					</div> 
				</div>

				<div class="group fixed"> 
					<label>Site URL</label> 
					<input type="text" value="" name="site" placeholder="http://www.google.com" /> 
					<p class="note">This is the URL that the lead was captured on.</p>
				</div>  

				<a href="#" class="button-blue">Create New Campaign <!-- <img src="http://quickadmin.weblumps.com/weblumps/quickadmin/images/icon-star-white.png" alt=""> --></a>

			</form>  <!-- ## / Panel Content  --> 

		</div> 

	</div>  

	<div class="shadow"></div> 
</div>