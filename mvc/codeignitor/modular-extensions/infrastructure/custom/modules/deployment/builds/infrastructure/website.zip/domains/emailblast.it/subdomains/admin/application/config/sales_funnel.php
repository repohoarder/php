<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require_once(CUSTOM_PATH.'config/sales_funnel.php');

$config['funnel_type']	= 'order';