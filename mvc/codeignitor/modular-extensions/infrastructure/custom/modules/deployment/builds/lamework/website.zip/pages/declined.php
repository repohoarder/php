<?php

global 	$session,
		$theme;

// include header
$theme->load('header');
?>


<h1>Your Payment Has Failed.</h1>


<?php

_debug($session->get_all());

// include footer
$theme->load('footer');



