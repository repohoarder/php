<?php

require_once('infusionsoft/isdk.php');

class Infusionsoft
{
	var $_app,
		$_date,
		$_merchant_id;

	public function __construct()
	{
		// create new instance of infusionsoft
		$this->_app 			= new iSDK;

		// set connection config
		$this->_app->cfgCon("jcoplin");

		// set current date
		$this->_date 			= $this->_app->infuDate(date("d-m-Y"));

		// set merchant id to use
		$this->_merchant_id 	= 2;
	}

	public function contact($email,$data=array())
	{
		// add email address to $add array
		$add 			= $data;
		$add['Email'] 	= $email;

		// add contact
		$cid 	= $this->_app->addCon($add);

		// return contact id
		return $cid;
	}

	public function update($cid,$data=array())
	{
		// update contact
		$this->_app->updateCon($cid,$data);

		return $cid;
	}

	public function credit_card($data=array())
	{
		// add credit card
		$ccid 	= $this->_app->dsAdd("CreditCard",$data);
	
		// return credit card id
		return $ccid;
	}

	public function email($email,$list)
	{

	}

	/*
		product_type
     * @paramOption 1 Shipping
     * @paramOption 2 Tax
     * @paramOption 3 Service & Misc
     * @paramOption 4 Product
     * @paramOption 5 Upsell Product
     * @paramOption 6 Fiance Charge
     * @paramOption 7 Special
     * @paramOption 8 Program
     * @paramOption 9 Subscription Plan
     * @paramOption 10 Special:Free Trial Days
     * @paramOption 12 Special: Order Total
     * @paramOption 13 Special: Category
     * @paramOption 14 Special: Shipping
	*/
	public function sale($cid=FALSE,$ccid=FALSE,$products=array(),$affiliate_id=0)
	{
		// if no cid or no credit card id, then return false
		if ( ! $cid OR ! $ccid)	
			return FALSE;

		// create blank order
		$order_id 	= $this->_app->blankOrder($cid,'Order Description',$this->_date,$affiliate_id,$affiliate_id);

		// make sure order id is an int
		$order_id 	= (int)$order_id;

		// iterate all products
		foreach ($products AS $key => $value):

			// initia;ize variables
			$id 	= $value['id'];
			$type 	= $value['type'];	// this is the product type
			$price 	= $value['price'];
			$desc 	= $value['description'];
			$qty 	= $value['quantity'];

			// add item to order
			$this->_app->addOrderItem($order_id,$id,$type,(float)$price,$qty,$desc,'');

		endforeach;

		// charge invoice
		$result 	= $this->_app->chargeInvoice($order_id,'',$ccid,$this->_merchant_id,FALSE);

		// return response
		return $result;
	}
}

