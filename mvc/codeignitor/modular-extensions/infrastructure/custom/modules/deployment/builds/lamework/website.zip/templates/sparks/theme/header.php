<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->
<head>

	<!-- Meta -->
	<meta charset="utf-8">
	<meta name="keywords" content="HTML5 Template" />
	<meta name="description" content="Sparks - Responsive HTML5 Landing Page">
	<meta name="author" content="">

	<title>Chuck Hughes' Wealth Creation Alliance</title>

	<!-- Mobile Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Favicons -->
	<link rel="shortcut icon" href="/theme/assets/img/favicon.ico">
	<link rel="apple-touch-icon" href="/theme/assets/img/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="/theme/assets/img/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="/theme/assets/img/apple-touch-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="144x144" href="/theme/assets/img/apple-touch-icon-144x144.png">

	<!-- Google Webfonts -->
	<link href='http://fonts.googleapis.com/css?family=Raleway:400,100,200,300,500,600,700,800,900' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Droid+Serif:400italic' rel='stylesheet' type='text/css'>

	<!-- CSS -->
	<link rel="stylesheet" href="/theme/assets/css/bootstrap.css">
	<link rel="stylesheet" href="/theme/assets/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="/theme/assets/css/style.css">
	<link rel="stylesheet" href="/theme/assets/js/owl-carousel/owl.carousel.css" />
	<link rel="stylesheet" href="/theme/assets/js/owl-carousel/owl.theme.css" />
	<link rel="stylesheet" href="/theme/assets/css/flexslider.css"/>

	<!--[if IE 8]>
		<link rel="stylesheet" type="text/css" href="/theme/assets/css/ie8.css" media="screen" />
	<![endif]-->

	<!-- Add custom CSS here -->
	<link href="/theme/assets/css/custom.css" rel="stylesheet">

	<!--[if lt IE 9]>
      	<script src="/theme/assets/js/html5shiv.js"></script>
	      <script src="/theme/assets/js/respond.js"></script>
	<![endif]-->

</head>
<body>

<div class="body">