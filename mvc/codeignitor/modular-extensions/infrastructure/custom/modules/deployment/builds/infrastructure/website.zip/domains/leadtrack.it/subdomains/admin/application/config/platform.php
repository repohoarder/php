<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['platform']	= array(
	'url'	=> 'http://app.weblumps.com/',	// This is the Platform URL to use
	'salt'	=> 'L3aDTR4cK',
	'app'	=> 'admin.leadtrack.it'
);


if ($_SERVER['SERVER_ADDR'] == '127.0.0.1'):

	$infra_subdomain = explode('.',$_SERVER['SERVER_NAME']);
	array_shift($infra_subdomain);

	$config['platform']['url'] = 'http://app.weblumps.code/';
	
endif;