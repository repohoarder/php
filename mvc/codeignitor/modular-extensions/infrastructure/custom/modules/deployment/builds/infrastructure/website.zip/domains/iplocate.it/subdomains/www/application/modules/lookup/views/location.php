<?php
// if ip variable is not set, set it to user's IP
$ip 	= ( ! isset($ip))? $_SERVER['REMOTE_ADDR']: $ip;
?>


<form action="/lookup/location/" method="POST" id="whois_form">

<div id="floater-home-search">
	<p class="hdtagline">
	<label>
		<input name="ip" type="text" class="searchfield" id="Search" value="<?php echo $ip; ?>" onfocus="if (this.value == '<?php echo $ip; ?>') this.value='';" onblur="if (this.value == '') this.value='Type here for whois, domain and keyword results';" />
	</label>
	
	<label>
		<input name="image" type="image" value="Submit" id="btn_submit" src="http://iplocate.weblumps.com/weblumps/whois/images/but_go.gif" align="default">
	</label>
</div>

</form>

<div id="floater-home-search-bg"></div>


<?php
// if ip location data is supplied, show it
if (isset($location) AND ! empty($location)):

	echo '

		<table style="top: 300px;text-align:left;position:absolute;">
				<tr>
					<td><strong>City</strong></td>
					<td>'.$location['city'].'</td>
				</tr>
				<tr>
					<td><strong>Region</strong></td>
					<td>'.$location['region'].'</td>
				</tr>
				<tr>
					<td><strong>Postal Code</strong></td>
					<td>'.$location['postal_code'].'</td>
				</tr>
				<tr>
					<td><strong>Country Code</strong></td>
					<td>'.$location['country_code'].'</td>
				</tr>
				<tr>
					<td><strong>Country Code (3)</strong></td>
					<td>'.$location['country_code3'].'</td>
				</tr>
				<tr>
					<td><strong>Country Name</strong></td>
					<td>'.$location['country_name'].'</td>
				</tr>
				<tr>
					<td><strong>Longitude</strong></td>
					<td>'.$location['longitude'].'</td>
				</tr>
				<tr>
					<td><strong>Latitude</strong></td>
					<td>'.$location['latitude'].'</td>
				</tr>
				<tr>
					<td><strong>Area Code</strong></td>
					<td>'.$location['area_code'].'</td>
				</tr>
				<tr>
					<td><strong>DMA Code</strong></td>
					<td>'.$location['dma_code'].'</td>
				</tr>
				<tr>
					<td><strong>Metro Code</strong></td>
					<td>'.$location['metro_code'].'</td>
				</tr>
				<tr>
					<td><strong>Continent Code</strong></td>
					<td>'.$location['continent_code'].'</td>					
				</tr>
		</table>
	';

endif;