<?php

class Theme
{
	public function __construct()
	{

	}

	public function load($page)
	{
		// make sure file exists
		if ( ! file_exists(BASE_PATH.'theme/'.$page.'.php'))
			return $this->error('Unable to load requested file.');
		
		// require the page
		require_once(BASE_PATH.'theme/'.$page.'.php');
	}	

	public function page($page)
	{
		// make sure file exists
		if ( ! file_exists(BASE_PATH.'pages/'.$page.'.php'))
			return $this->error('404: File does not exist');
		
		// require the page
		require_once(BASE_PATH.'pages/'.$page.'.php');
	}

	public function error($error)
	{
		echo '<p style="font-weight:bold;font-size:150%;">'.$error.'</p>';
		exit;
	}
}