
<div class="panel-wrapper"> 

	<div class="panel"> 

		<div class="title"> 
			
			<h4>Campaigns</h4> 

			<div class="collapse"><a href="/campaign/create">Add New</a></div> 
		</div>  

		<div class="content"> 
			<!-- ## Panel Content  -->  
			<table id="sample-table" class=""> 
				<thead> 
					<tr> 
						<td>ID</th>
						<th>Campaign</th>
						<th>Vertical</th> 
						<th>Website</th> 
						<th>Code</th>
					</tr> 
				</thead> 

				<tbody> 
					<tr> 
						<td>1</td> 
						<td>MaxLeanX Buyer</td>
						<td>Health</td> 
						<td>maxleanx.com</td> 
						<td><a href="/integration/1">Get Code</a></td>
					</tr> 

					<tr> 
						<td>3</td> 
						<td>Auto Landing Page</td>
						<td>Insurance</td> 
						<td>auto-warranty-experts.com</td> 
						<td><a href="/integration/3">Get Code</a></td>
					</tr> 

				</tbody> 
			</table>  
			<!-- ## / Panel Content  --> 

		</div> 
		
	</div>  

	<!-- <div class="shadow"></div> -->

</div>

