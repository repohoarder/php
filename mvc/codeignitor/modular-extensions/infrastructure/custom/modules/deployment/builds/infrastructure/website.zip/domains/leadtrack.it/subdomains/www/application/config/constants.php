<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


require_once(CUSTOM_PATH.'config/constants.php');

define('SITE', 			'leadtrack.it');
define('SITE_ADMIN',	'admin.leadtrack.it');
define('SITE_TITLE',	'Lead Track It');
define('SITE_LOGO',		'http://leadtrack.weblumps.com/leadtrack/images/logo.png');