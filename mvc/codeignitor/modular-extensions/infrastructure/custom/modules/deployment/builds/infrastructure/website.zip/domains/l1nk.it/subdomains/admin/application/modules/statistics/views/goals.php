<?php

echo 'this is where we will show goal statistics.';