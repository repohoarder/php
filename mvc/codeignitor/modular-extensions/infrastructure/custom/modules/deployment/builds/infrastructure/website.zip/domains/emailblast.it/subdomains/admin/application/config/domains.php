<?php

$config['available_tlds'] = array(

	'com', 'net', 'org', 'info', 'biz'
);