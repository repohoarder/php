<?php

class Usage extends MX_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$data 	= array();

		// set template layout to use
		$this->template->set_layout('default');

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: Usage');

		// load view
		$this->template->build('usage/usage', $data);
	}

}