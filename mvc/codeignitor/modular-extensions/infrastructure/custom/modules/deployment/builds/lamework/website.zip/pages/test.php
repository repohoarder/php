<?php

global 	$session,
		$infusionsoft;

/*
## ADD CONTACT

// initialize varibales
$email 	= 'testing@mctesterson.com';
$data 	= array(
	'FirstName'	=> 'Tester',
	'LastName'	=> 'McTestington'
);

// print cid
$cid 	= $infusionsoft->contact($email,$data);
*/

/*
## UPDATE CONTACT

// initialize variables
$cid 	= '2300293';
$data 	= array(
	'FirstName'			=> 'NewFirstName',
	'LastName'			=> 'NewLastName',
	'StreetAddress1'	=> '123 Test Avenue',
	'StreetAddress2'	=> '',
	'City' 				=> 'Akron',
	'PostalCode' 		=> '44333',
	'State'				=> 'OH',
	'Country'			=> 'United States',
	'Phone1'			=> '3305556666'
);

// update cid
$cid 	= $infusionsoft->update($cid,$data);

echo $cid;
*/


/*
## ADD CREDIT CARD

// initialize variables
$card 	= array(
	"ContactId" 		=> '2300293',
	"NameOnCard" 		=> 'Name on Card',
	"CardNumber"		=> '4111111111111111',
	"CardType"			=> 'Visa',
	"CVV2"				=> '123',
	"ExpirationMonth"	=> '12',
	"ExpirationYear"	=> '14'
);

// add credit card
$ccid 	= $infusionsoft->credit_card($card);

echo $ccid;
*/


/*
## PROCESS SALE

// initialize variables
$cid 			= '2300293';
$ccid 			= '8003';
$affiliate_id	= 0;
$products 		= array(
	array(
		'id' 			=> 294,	// test product
		'type' 			=> 4,	// Product
		'price' 		=> 10.00,
		'description' 	=> 'TEST',
		'quantity'		=> 1
	),
	array(
		'id' 			=> 320,	// test product
		'type' 			=> 5,	// Product
		'price' 		=> 10.00,
		'description' 	=> 'Test',
		'quantity'		=> 1
	),	
);

// process sale
$sale 	= $infusionsoft->sale($cid,$ccid,$products,$affiliate_id);

## EXAMPLE RESPONSE:
# Array
# (
#     [Successful] => 
#     [Message] => This transaction has been declined. (2)
#     [RefNum] => 5957215087
#     [Code] => DECLINED
# )
*/



echo 'done!';




