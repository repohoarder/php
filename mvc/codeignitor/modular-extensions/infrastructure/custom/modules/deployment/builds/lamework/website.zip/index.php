<?php
session_start();

// define variables
define('SEPARATOR', DIRECTORY_SEPARATOR);
define('BASE_PATH', dirname(__FILE__).SEPARATOR);
define('BASE_URL', 'http://'.$_SERVER['SERVER_NAME'].'/');
define('REQUEST_URI', preg_replace('/\?' . $_SERVER['QUERY_STRING'] . '/i', ”, $_SERVER['REQUEST_URI']));

// load config
require_once(BASE_PATH.'config'.SEPARATOR.'config.php');

// timezone setting
date_default_timezone_set($config['timezone']);

// define test mode
define('TEST_MODE', $config['debug']);

// initialize the system
require_once(BASE_PATH.'classes'.SEPARATOR.'initialize.php');


exit;


// include needed classes
require_once('classes/dba.php');

$test 	= $dba->sql('select * from visitors');
echo 'test';
print "<pre>";
print_r($test);
exit;
//$debug->arr($test,TRUE);



exit;

// see if data has been POSTed
$submitted 	= (isset($_REQUEST['submit']))? TRUE: FALSE;

// if submitted
if ($submitted):

	header("Location: /order.php");
	exit;

endif;

################################################################

// require HTML header
require_once('inc/header.php');
?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
	<table>
		<tr>
			<td>Company Name:</td>
			<td><input type="text" name="company" value="" /></td>
		</tr>
		<tr>
			<td>Email Address:</td>
			<td><input type="text" name="email" value="" /> <p style="font-size:75%;color:red;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;*this will be used as your account username</p></td>
		</tr>
		<tr>
			<td>Zip Code:</td>
			<td><input type="text" name="zip" value="" /></td>
		</tr>
		<tr>
			<td colspan="2"><input type="submit" name="submit" value="Submit" /></td>
		</tr>
	</table>
</form>

<?php
// require footer
require_once('inc/footer.php');

################################################################
