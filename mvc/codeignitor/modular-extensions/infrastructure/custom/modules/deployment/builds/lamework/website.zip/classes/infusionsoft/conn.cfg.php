<?php

$connInfo = array('jcoplin:tradewinspublish:i:b267995084ec49d1831db3dfe48c8f5b:This is the connection for applicationName.infusionsoft.com');

?>