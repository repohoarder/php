<?


define('IMAGE_DIR', 'wp-content/uploads/', true); //<- this is where the images are saved to. Include trailing slash.
ini_set('memory_limit', '999999999999M');
ini_set('set_time_limit', 0);

define('WP_USE_THEMES', false);
require_once('wp-blog-header.php');
require_once('wp-admin/includes/image.php' );

$mode = $_REQUEST['mode'];
$terms = stripslashes(strip_tags($_POST['terms']));


/*====================================
get_wp_posts() - fetches most recent posts from WP and return array with the useful bits
====================================*/
function get_wp_posts($count = 12){ 
	query_posts('showposts=12');
	while ( have_posts() ) : the_post();
		$this_cat_obj = get_the_category(get_the_ID());
		$wp_posts[] = array(
						'title' => get_the_title(), 
						'id' => get_the_ID(), 
						'cat_id' => $this_cat_obj[0]->cat_ID, 
						'cat_name' => $this_cat_obj[0]->name
						); 
	endwhile;
	wp_reset_query();
	return $wp_posts;
}

/*====================================
build_select_field() - builds select drop down box for the image with list of posts, feed it img_id, img_url and an array of wp_posts
====================================*/

function build_select_field($img_id, $img_url, $thumb_url, $wp_posts){ 
	$select = '<select size="1" name="img[' . $img_id . '][post]">' . "\r\n\t" . '<option value="" selected="selected">---SELECT THIS IMAGE---</option>' . "\r\n";
	foreach((array)$wp_posts as $p){
		$select .= "\t" . '<option value="'. $p['id'] . '">' . $p['cat_name'] . ' &raquo; ' . $p['title'] . '</option>' . "\r\n";
	}
	$select .= '</select>' . "\r\n";
	$select .= '<input type="hidden" name="img[' . $img_id . '][thumb_url]" value="' . $thumb_url . '" />' . "\r\n";
	$select .= '<input type="hidden" name="img[' . $img_id . '][img_url]" value="' . $img_url . '" />' . "\r\n";

	return $select;
}


/*====================================
array_remove_empty() - removes empty elements/indexes from an array
====================================*/
function array_remove_empty($arr){
	$narr = array();
	while(list($key, $val) = each($arr)){
		if (is_array($val)){
			$val = array_remove_empty($val);
			if (count($val)!=0){
				$narr[$key] = $val;
			}
		}else{
			if (trim($val) != ""){
				$narr[$key] = $val;
			}
		}
	}
	unset($arr);
	return $narr;
}




/*====================================
rm_dir() - delete all files and sub directories of a given directory. But not the directory itself. 
====================================*/
function rm_dir($directory, $empty=FALSE){
	if(substr($directory,-1) == '/'){
		$directory = substr($directory,0,-1);
	}
	if(!file_exists($directory) || !is_dir($directory)){
		return FALSE;
	}elseif(is_readable($directory)){
		$handle = opendir($directory);
		while (FALSE !== ($item = readdir($handle))){
			if($item != '.' && $item != '..'){
				$path = $directory.'/'.$item;
				if(is_dir($path)) {
					rm_dir($path);
				}else{
					unlink($path);
				}
			}
		}
		closedir($handle);
		if($empty == FALSE){
			if(!rmdir($directory)){
				return FALSE;
			}
		}
	}
	return TRUE;
}

/*====================================
handle_import_file() - dHandle an individual file import into WP media gallery
====================================*/
function handle_import_file($file, $post_id = 0) {
	set_time_limit(120);
	$time = current_time('mysql');
	if ( $post = get_post($post_id) ) {
		if ( substr( $post->post_date, 0, 4 ) > 0 )
			$time = $post->post_date;
	}

	// A writable uploads dir will pass this test. Again, there's no point overriding this one.
	if ( ! ( ( $uploads = wp_upload_dir($time) ) && false === $uploads['error'] ) )
		return new WP_Error($uploads['error']);

	$wp_filetype = wp_check_filetype( $file, null );

	extract( $wp_filetype );
	
	if ( ( !$type || !$ext ) && !current_user_can( 'unfiltered_upload' ) )
		return new WP_Error('wrong_file_type', __( 'File type does not meet security guidelines. Try another.' ) ); //A WP-core string..

	//Is the file allready in the uploads folder?
	if( preg_match('|^' . preg_quote(str_replace('\\', '/', $uploads['basedir'])) . '(.*)$|i', $file, $mat) ) {

		$filename = basename($file);
		$new_file = $file;

		$url = $uploads['baseurl'] . $mat[1];

		$attachment = get_posts(array( 'post_type' => 'attachment', 'meta_key' => '_wp_attached_file', 'meta_value' => $uploads['subdir'] . '/' . $filename ));
		if ( !empty($attachment) )
			return $attachments[0]->ID;

		//Ok, Its in the uploads folder, But NOT in WordPress's media library.
		if ( preg_match("|(\d+)/(\d+)|", $mat[1], $datemat) ) //So lets set the date of the import to the date folder its in, IF its in a date folder.
			$time = mktime(0, 0, 0, $datemat[2], 1, $datemat[1]);
		else //Else, set the date based on the date of the files time.
			$time = @filemtime($file);

		if ( $time ) {
			$post_date = date( 'Y-m-d H:i:s', $time);
			$post_date_gmt = gmdate( 'Y-m-d H:i:s', $time);
		}
	} else {	

		$filename = wp_unique_filename( $uploads['path'], basename($file));

		// copy the file to the uploads dir
		$new_file = $uploads['path'] . '/' . $filename;
		if ( false === @copy( $file, $new_file ) )
			wp_die(sprintf( __('The selected file could not be copied to %s.', 'add-from-server'), $uploads['path']));

		// Set correct file permissions
		$stat = stat( dirname( $new_file ));
		$perms = $stat['mode'] & 0000666;
		@ chmod( $new_file, $perms );
		// Compute the URL
		$url = $uploads['url'] . '/' . $filename;

	}

	// Compute the URL
	$url = $uploads['url'] . '/' . rawurlencode($filename);

	//Apply upload filters
	$return = apply_filters( 'wp_handle_upload', array( 'file' => $new_file, 'url' => $url, 'type' => $type ) );
	$new_file = $return['file'];
	$url = $return['url'];
	$type = $return['type'];

	$title = preg_replace('!\.[^.]+$!', '', basename($file));
	$content = '';

	// use image exif/iptc data for title and caption defaults if possible
	if ( $image_meta = @wp_read_image_metadata($new_file) ) {
		if ( '' != trim($image_meta['title']) )
			$title = trim($image_meta['title']);
		if ( '' != trim($image_meta['caption']) )
			$content = trim($image_meta['caption']);
	}

	if ( empty($post_date) )
		$post_date = current_time('mysql');
	if ( empty($post_date_gmt) )
		$post_date_gmt = current_time('mysql', 1);

	// Construct the attachment array
	$attachment = array(
		'post_mime_type' => $type,
		'guid' => $url,
		'post_parent' => $post_id,
		'post_title' => $title,
		'post_name' => $title,
		'post_content' => $content,
		'post_date' => $post_date,
		'post_date_gmt' => $post_date_gmt
	);

	// Save the data
	$id = wp_insert_attachment($attachment, $new_file, $post_id);
	if ( !is_wp_error($id) ) {
		$data = wp_generate_attachment_metadata( $id, $new_file );
		wp_update_attachment_metadata( $id, $data );
	}

	return $id;
}


/*====================================
file_extension() - generic file extension sniffer - just grabs ext from URL (not seucre l know!)
====================================*/
function file_extension($filename){
	$parts = explode('.', $filename);
	return $parts[(count($parts)-1)];
}


# /********************** 
# *@url - url of page you'd like to fetch
# *@postdata - array, or straight string of variables to be sent to url with POST method as apposed to GET method
# *@items - headers returned form server requires cURL
# */ 
function fetch($url, $postdata = false, $ref = false, $return_headers = false) {
	$ualist[] = "Mozilla/5.0 (compatible; Konqueror/4.0; Microsoft Windows) KHTML/4.0.80 (like Gecko)";
	$ualist[] = "Mozilla/5.0 (compatible; Konqueror/3.92; Microsoft Windows) KHTML/3.92.0 (like Gecko)";
	$ualist[] = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0; WOW64; SLCC1; .NET CLR 2.0.50727; .NET CLR 3.0.04506; Media Center PC 5.0; .NET CLR 1.1.4322; Windows-Media-Player/10.00.00.3990; InfoPath.2";
	$ualist[] = "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 1.1.4322; InfoPath.1; .NET CLR 2.0.50727; .NET CLR 3.0.04506.30; Dealio Deskball 3.0)";
	$ualist[] = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; NeosBrowser; .NET CLR 1.1.4322; .NET CLR 2.0.50727)";
	$ualist[] = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.11) Gecko/20071127 Firefox/2.0.0.11";

	if(function_exists('curl_init')){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_USERAGENT, $ualist[array_rand($ualist)]);
		curl_setopt($ch, CURLOPT_REFERER, $url);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array("Expect:"));
		if (!ini_get('open_basedir') && !ini_get('safe_mode')) {
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
			curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
		}
		if($postdata){
			if(!is_array($postdata)){
				$post_data_array = explode('&', $postdata);
				foreach($post_data_array as $var){
					$val = explode('=', $var);
					$postdata[$val[0]] = $val[1];
				}
			}
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
		}

		if($return_headers){
			$c = curl_exec($ch);
			$response = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		}else{
			$response = curl_exec($ch);
		}
		curl_close($ch);
		return $response;
	}else{
		@$fp = fsockopen("www.google.com", 80, $errno, $errstr, 5);
		if(!$fp){  
			die('<b>Critical Error:</b> fetch() function requires cURL or fsockopen to run properly. This server supports neither.');
			return false;  
		}
		@fclose($fp);
		$url_info = parse_url($url);
		$request .= "POST " . $url_info["path"] . "?" . $url_info["query"] . " HTTP/1.1\n";
		$request .= "Host: " . $url_info["host"] . "\n";  
		$request .= "Referer:\n";
		$request .= "User-Agent:      " . $ualist[array_rand($ualist)]. "\r\n";
		$request .= "Content-type: application/x-www-form-urlencoded\n";
		
		if(is_array($postdata)){
			$postdata_string = '';
			$insert_and_symbol = ''; 
			$postdata_keys = array_keys($postdata);
			for($i=0;$i<count($postdata);$i++){
				$postdata_string .= $insert_and_symbol . $postdata_keys[$i] . '=' . $postdata[$postdata_keys[$i]];
				$insert_and_symbol = '&'; 
			}
			$postdata = $postdata_string;
		}

		$request .= "Content-length: " . strlen($postdata) . "\n";
		$request .= "Connection: close\n";
		$request .= "\n";
		$request .= $postdata . "\n";

		if($fp = fsockopen( $url_info["host"], 80, $errno, $errstr, 15.0)){
			fwrite($fp, $request);
			$responseHeader = '';
			$responseContent = '';
			do{
				$responseHeader.= fread($fp, 1);
			}

			while (!preg_match('/\\r\\n\\r\\n$/', $responseHeader));
			if(!strstr($responseHeader, "Transfer-Encoding: chunked")){
				while(!feof($fp)){
					$responseContent .= fgets($fp, 128);
				}
			}else{
				while($chunk_length = hexdec(fgets($fp))){
					$responseContentChunk = '';
					$read_length = 0;
					while ($read_length < $chunk_length){
						$responseContentChunk .= fread($fp, $chunk_length - $read_length);
						$read_length = strlen($responseContentChunk);
					}
					$responseContent.= $responseContentChunk;
					fgets($fp);
				}
			}
		}
		return chop($responseContent);
	}
}

if(!function_exists(fetchcache)){
	function fetchcache($url, $textonly = false) {
	  $text = $textonly ? '&strip=1' : '';
	  $response = fetch('http://google.com/search?q=cache:' . $url . $text, false);
	  $response = strstr($response, '�'.date('Y').' Google') ? false : $response;
	  return $response;
	}
}


# /********************** 
# *@keyword - keyword(s) to search for images
# *@engine - image search engine to query (google|photobucket|yahoo|flickr)
# *@items - number of images to fetch. 
# *@bare - 0 = echo images / 1 = return array with images/thumbs
# */  
function images($keyword, $source = 'flickr', $items = 3, $bare = false) {
	$output = array();

	$sources = array('google', 'photobucket', 'yahoo', 'flickr');
	if(strstr($source, '|')){
		$source = explode('|', $source);
		shuffle($source);
		$source = $source[0];
	}

	if (!in_array($source, $sources)) {
		$source = $sources[array_rand($sources)];
	}

	$yahoo_api = 'YahooDemo';
	//get Yahoo API here: http://developer.yahoo.com/ 

	if($source == 'google'){
		$url = 'http://images.google.com/images?hl=en&q=' . urlencode($keyword) . '&btnG=Search+Images&gbv=1';
		$re = "/href=\/imgres\?imgurl=(.+?)&.+?img src=([^\s]+?) width=(\d+) height=(\d+)/im";

	}else if($source == 'photobucket'){
		$url = 'http://feed.photobucket.com/images/' . urlencode($keyword) . '/feed.rss';
		$re = "/<item>.+?<title>.+?<\/title>.+?<guid>(.+?)<\/guid>.+?<media:thumbnail url=\"(.+?)\" \/>.+?<\/item>/ims";

	}else if($source == 'yahoo'){ 
		$url = 'http://api.search.yahoo.com/ImageSearchService/V1/imageSearch?appid=' . $yahoo_api . '&query=' . urlencode($keyword) . '&results=' . $items;
		$re = "/<Result>.+?<ClickUrl>(.+?)<\/ClickUrl><RefererUrl>.+?<\/RefererUrl>.*?<Url>(.+?)<\/Url><Height>(.+?)<\/Height><Width>(.+?)<\/Width>.*?<\/Result>/ims";

	}else{
		$url = 'http://www.flickr.com/search/?q=' . urlencode($keyword) . '&ct=0&mt=photos&z=t';
		$re = "/<img src=\"(http:\/\/\w+?.static.flickr.com\/\d+\/[\w]+?)_t.jpg\".+?alt=\"(.+?)\".+?class=\"pc_img\".+?\/>/";
	}

	$serp = fetch($url);
	if(preg_match_all($re, $serp, $images)){
		unset($images[0]);
		unset($images[3]);
		unset($images[4]);

		for($i=0;$i<$items;$i++){
			if($source == 'google'){
				$output[$i]['image'] = $images[1][$i];
				$output[$i]['thumbnail'] = $images[2][$i];

			}else if($source == 'photobucket'){
				$output[$i]['image'] = $images[1][$i];
				$output[$i]['thumbnail'] = html_entity_decode($images[2][$i]);

			}else if($source == 'yahoo'){
				$output[$i]['image'] = $images[1][$i];
				$output[$i]['thumbnail'] = $images[2][$i];

			}else{
				$output[$i]['image'] = $images[1][$i].'.jpg';
				$output[$i]['thumbnail'] = $images[1][$i].'_s.jpg';
			}
		}

	}else{
		return false;
	}

	if(!$bare){
		for($i=0;$i<$items;$i++){
			echo '<a rel="nofollow" title="'.$keyword.'" href="'.$output[$i]['image'].'"><img src="'.$output[$i]['thumbnail']."\"></a>\n";
		}
	}else{
		return $output;
	}
 
}

function flickr($keyword, $items = 3, $bare = false) {
	images($keyword, 'flickr', $items, $bare);
}

function googleimg($keyword, $items = 3, $bare = false) {
	images($keyword, 'google', $items, $bare);
}

function photobucket($keyword, $items = 3, $bare = false) {
	images($keyword, 'photobucket', $items, $bare);
}

function yahooimg($keyword, $items = 3, $bare = false) {
	images($keyword, 'yahoo', $items, $bare);
}

if($mode == 'del'){
	unlink(__FILE__);
	exit;
}


?>
<!doctype html public "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"> 
<head>
<title>Image Tools</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="imagetoolbar" content="false" />
<link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/2.8.2r1/build/reset/reset-min.css" />
<style type="text/css">
/*====================================
Core styles
====================================*/
body{
	margin: 25px;
	color: #333;
	font-size: 90%;
	line-height: 170%;
	font-family: tahoma, arial, sans-serif;
}

.image_container{
	float: left;
	border: 15px solid #eee;
	padding: 10px;
	margin: 5px;
	text-align: center;
}

.image_container select{
	width: 100px;
	display: block;
	margin: 5px auto 0 auto;
}


</style>
</head>
<body>
	<form method="post" action="<?= $_SERVER['SCRIPT_NAME']; ?>">
	Search Terms: <input type="text" name="terms" value="<?= htmlspecialchars($terms); ?>" size="25" />&nbsp;

		<input type="submit" value="Find Images" />
		<input type="hidden" name="mode" value="search" />

	</form>
<hr />
<? if($mode == 'search' && strlen(stripslashes(strip_tags($_POST['terms']))) > 2){ 

	$search_source = stripslashes(strip_tags($_POST['search_source']));
	//fetch latest 10 posts
	//$wp_posts = get_wp_posts(12);


	$goog_images = images($terms, 'google', 90, 1);
	$photobucket_images = images($terms, 'photobucket',90, 1);
	$yahoo_images = images($terms, 'yahoo', 90, 1);
	$flickr_images = images($terms, 'flickr', 90, 1);

	$images = array_merge((array)$goog_images, (array)$photobucket_images , (array)$yahoo_images, (array)$flickr_images);
	$images = array_remove_empty($images); 


	//$images = unserialize(file_get_contents('data.txt'));

	if(count($images) == 0){
		echo 'Sorry no images were found. Please try different keywords, or another search source.';
		echo '</body></html>';
		exit;
	}


?>
		<form method="post" action="<?= $_SERVER['SCRIPT_NAME']; ?>">
<?
		for($i=0;$i<count((array)$images);$i++){ 
			if(trim($images[$i]['image']) != ''){ 
?>
		<?= ($c++%4==0 ? '<div style="clear: both;"></div>' : ''); ?>
		<div class="image_container">
			<a href="<?= $images[$i]['image']; ?>" target="_blank" rel="lightbox"><img src="<?= $images[$i]['thumbnail']; ?>" alt="thumbnail" /></a>
			<br />
			<? /* echo build_select_field($i, $images[$i]['image'], $images[$i]['thumbnail'], $wp_posts); */ ?>
			<input type="checkbox" name="img[<?= $i; ?>]" id="img<?= $i; ?>" value="<?= $images[$i]['image']; ?>" onchange="if(this.checked){ this.parentNode.style.borderColor='green'; }else{ this.parentNode.style.borderColor='#eee'; }" />&nbsp;<label for="img<?= $i; ?>">Copy This Image</label>
		</div>
<?

			}
		}
?>
		<div style="clear: both;"></div>
		<input type="hidden" name="terms" value="<?= htmlspecialchars($terms); ?>" />
		<input type="hidden" name="mode" value="copy" />
		<input type="submit" value="Copy Images" />
<?


}else if($mode == 'copy'){ 

	//traverse image array and copy over images and thumbnails
	$imgs = $_REQUEST['img'];
	$img_count = 0;


	foreach((array)$imgs as $img){

		//echo $img . '<br />';

		if(copy($img, IMAGE_DIR . basename($img))){
			$img_count++;
			 @handle_import_file(IMAGE_DIR . basename($img));
		}
	}


	echo 'Done, copied ' . $img_count . ' images to ' . IMAGE_DIR;

}



?>
<br />
<a href="<?= $_SERVER['SCRIPT_NAME']; ?>?mode=del" onclick="if(confirm('Are you sure?')){return true;}else{return false;}">delete me</a>
</body>
</html>