<?php

class Lead extends MX_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function add()
	{
		echo json_encode($this->platform->post('argall/lead/add',$this->input->post()));
	}
}