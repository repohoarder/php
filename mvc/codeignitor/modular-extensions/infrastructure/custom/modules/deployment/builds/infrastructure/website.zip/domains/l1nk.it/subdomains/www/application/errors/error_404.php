<?php

echo 'this is where we will set cookies and redirect your link - else, show actual 404 page';

exit;



<?php

// htaccess redirects all 404 requests here

$host   = str_replace('www.','',$_SERVER['HTTP_HOST']);

$uri    = $_SERVER['REQUEST_URI'];
$parts  = parse_url($uri);
$path   = $parts['path'];
$params = $parts['query'];

$cookie = isset($_COOKIE['urlnano']) ? $_COOKIE['urlnano'] : FALSE;

if ($cookie !== FALSE):

	$cookie = Encrypter::decrypt($cookie, $host);
	$cookie = json_decode($cookie, TRUE);

	if ( ! is_null($cookie) && is_array($cookie)):

		extract($cookie);

	endif;

endif;


if ( ! isset($visitor_id) || ! $visitor_id):

	#########################################
	## TODO
		// call platform to create visitor & get visitor_id back
		$visitor_id = 123;
	##
	#########################################

endif;


#########################################
## TODO
	// get link_id and url by platform call for $path & $host
	$link_id  = 987;
	$redirect = 'http://www.disney.com';
##
########################################


#########################################
## TODO
	// call platform to track link hit here
##
########################################


if ( ! isset($redirect) || ! $redirect):

	#########################################
	## TODO
		// show true 404 here
	##
	########################################

endif;


if ($params):
	$redirect = (strpos($redirect,'?') !== FALSE) ? $redirect.$params : $redirect.'?'.$params;
endif;


$cookie = array(
	'visitor_id' => $visitor_id,
	'link_id'    => $link_id
);

$cookie = json_encode($cookie);
$cookie = Encrypter::encrypt($cookie, $_SERVER['HTTP_HOST']);

setcookie('urlnano', $cookie, 2592000, '/', '.'.$host);




// 301 redirect to link_url + query params
header("HTTP/1.1 301 Moved Permanently");
header("Location: ".$redirect);
exit();


class Encrypter {
	
	function _get_ivs() {
	
		return mcrypt_get_iv_size( MCRYPT_RIJNDAEL_128, MCRYPT_MODE_ECB );
		
	}
	
	function _get_iv() {
		
		return mcrypt_create_iv( self::_get_ivs(), MCRYPT_DEV_URANDOM );
		
	}
	
	function encrypt($text, $salt) {
		
		$data = mcrypt_encrypt( MCRYPT_RIJNDAEL_128, $salt, $text, MCRYPT_MODE_ECB, self::_get_iv() );
        return base64_encode( $data );
		
	}
	
	function decrypt($text, $salt) {
		
		$text = base64_decode( $text );
        return trim(mcrypt_decrypt( MCRYPT_RIJNDAEL_128, $salt, $text, MCRYPT_MODE_ECB, self::_get_iv() ));
		
	}

}