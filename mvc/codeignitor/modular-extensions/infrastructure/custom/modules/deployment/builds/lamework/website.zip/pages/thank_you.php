<?php

global 	$session,
		$theme;

// include header
$theme->load('header');
?>


<h1>Thank You For Your Order.</h1>


<?php

//_debug($session->get_all());

// include footer
$theme->load('footer');



