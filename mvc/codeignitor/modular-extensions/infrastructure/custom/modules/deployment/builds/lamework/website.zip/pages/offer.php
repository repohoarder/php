<?php

// initialize classes needed for this page
global  $google,
		$params,
		$session,
		$theme;


// include header
//$theme->load('header');
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta http-equiv="pragma" content="no-cache" />
<meta name="googlebot" content="noarchive" />
<meta name="description" content="OHC University You Can Start Earning Real Money From Home Today. Visit OHCUniversity.com" />
<title>The Online Home Careers University Program is Available In Akron</title>
<meta name="keywords" content="OHC University, Melissa Mayer" />
<link rel="stylesheet" href="/theme/assets/ohn/files/main.css" charset="utf-8" />
<link href="/theme/assets/ohn/js/css/ui-lightness/jquery-ui-1.10.3.custom.min.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/theme/assets/ohn/files/jscripts-lib.js"></script>
<script type="text/javascript" src="/theme/assets/ohn/files/exitpop.js"></script>
<script type="text/javascript" >
                var param = "vid=";
    var internalLink = false;
    var eurl =  "offer";
    var vmsg = '*************************************************\nToday\'s Special 61% OFF Discount\n*************************************************\n\n\nWait... Before You Go:\n\n\nWe want to offer you a special discount that is normally restricted to only friends and family.\n\n\nYou can SAVE BIG by clicking the cancel button below.\n\n\nYou will get my entire system for only $77 That is $120 OFF the normal price of $197.\n\n\nTo get INSTANT ACCESS to the "friends and family" discount page where you can access this exclusive offer simply click on the CANCEL button below.\n\n\n*************************************************\nToday\'s Special 61% OFF Discount\n*************************************************';
    var userAgent = navigator.userAgent.toLowerCase();
    if(userAgent.search('firefox') != -1)
    {
        window.onbeforeunload = pageUnload;
    }
    else if (userAgent.search('safari') != -1)
    {
        window.onbeforeunload = function(ev) {
            var e = ev || window.event;
            window.focus();
            if (!internalLink){
              internalLink = true;
              var showstr = '*************************************************\nToday\'s Special 61% OFF Discount\n*************************************************\n\n\nWait... Before You Go:\n\n\nWe want to offer you a special discount that is normally restricted to only friends and family.\n\n\nYou can SAVE BIG by clicking the cancel button below.\n\n\nYou will get my entire system for only $77 That is $120 OFF the normal price of $197.\n\n\nTo get INSTANT ACCESS to the "friends and family" discount page where you can access this exclusive offer simply click on the CANCEL button below.\n\n\n*************************************************\nToday\'s Special 61% OFF Discount\n*************************************************';
              
              return showstr; //for safari and chrome
            }
        };
        
        window.onfocus = function (ev){
            if (internalLink){
              window.location.href = "offer";
            }
        }
        
    }
    else { /** ie or chrome **/
        window.onbeforeunload = areYouSure;	
    }

    function pageUnload() 
    {
        if (!internalLink){
            internalLink = true;
            alert('*************************************************\nToday\'s Special 61% OFF Discount\n*************************************************\n\n\nWait... Before You Go:\n\n\nWe want to offer you a special discount that is normally restricted to only friends and family.\n\n\nYou can SAVE BIG by clicking the cancel button below.\n\n\nYou will get my entire system for only $77  That is $120 OFF the normal price of $197.\n\n\nTo get INSTANT ACCESS to the "friends and family" discount page where you can access this exclusive offer, click on the CANCEL button below.\n\n\n*************************************************\nToday\'s Special 61% OFF Discount\n*************************************************');
            location.href= "special1";
            return '*************************************************\nToday\'s Special 61% OFF Discount\n*************************************************\n\n\nWait... Before You Go:\n\n\nWe want to offer you a special discount that is normally restricted to only friends and family.\n\n\nYou can SAVE BIG by clicking the cancel button below.\n\n\nYou will get my entire system for only $77  That is $120 OFF the normal price of $197.\n\n\nTo get INSTANT ACCESS to the "friends and family" discount page where you can access this exclusive offer, click on the CANCEL button below.\n\n\n*************************************************\nToday\'s Special 61% OFF Discount\n*************************************************';
        }
    }
                var dep = false;
    $(document).ready(function() {
        $('a').bind('click', function(event) {
            internalLink = true;
        });
        
        function populateCalculatorResults()
        {
            var postAday = $('#postAday').val();
            var avEarnPerLink = $('#avEarnPerLink').val().replace('$','');
            var daysOfWork = $('#daysOfWork').val(); //a week
            var dailyIncome = postAday * avEarnPerLink;
            var weeklyIncome = dailyIncome * daysOfWork;
            var monthlyIncome = weeklyIncome * 4;
            var yearlyIncome = weeklyIncome * 52;
            $('span#dailyIncome').html('$'+dailyIncome+'.00');
            $('span#weeklyIncome').html('$'+weeklyIncome+'.00');
            $('span#monthlyIncome').html('$'+monthlyIncome+'.00');
            $('span#yearlyIncome').html('$'+yearlyIncome+'.00');
        }
        
        //initialize the results
        populateCalculatorResults();

        //recompute when button was clicked
        $('#calculate').click(function(){
            populateCalculatorResults();
        })
    });
</script>
<style type="text/css">
.auto-style1 {
	background-image: url('/theme/assets/ohn/images/vidbg.png');
	background-position: 0 0;
	background-repeat: no-repeat;
	height: 380px;
	margin: 0px auto 30px auto;
	width: 580px;
}
.auto-style2 {
	margin: 0px auto 10px auto;
	max-width: 880px;
	text-align: center;
	background: #ffffcc;
	vertical-align: middle;
}
/* .cong-block .cong-flag-left {
	background: url('/theme/assets/ohn/images/flags/US.jpg');
}
.cong-block .cong-flag-right {
	background: url('/theme/assets/ohn/images/flags/US.jpg');
} */
.lktop {
	color: #605f5f;
	text-decoration: none;
	font-weight: bold;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	text-transform: uppercase;
	padding-left: 20px;
	padding-right: 20px;
	font-size: 12px;
	line-height: 30px;
}
.mlktop {
	background: url("/theme/assets/ohn/images/bg-link.jpg") no-repeat scroll top left transparent;
}
.cliktop {
	background: url("/theme/assets/ohn/images/bg-link.jpg") no-repeat scroll bottom left transparent;
}
.videoFrame {
	padding: 20px;
	background: #054151; /* Old browsers */
	background: -moz-linear-gradient(top,  #054151 0%, #0b556a 12%, #1b667b 62%, #054151 100%); /* FF3.6+ */
	background: -webkit-gradient(linear, left top, left bottom, color-stop(0%,#054151), color-stop(12%,#0b556a), color-stop(62%,#1b667b), color-stop(100%,#054151)); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(top,  #054151 0%,#0b556a 12%,#1b667b 62%,#054151 100%); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(top,  #054151 0%,#0b556a 12%,#1b667b 62%,#054151 100%); /* Opera 11.10+ */
	background: -ms-linear-gradient(top,  #054151 0%,#0b556a 12%,#1b667b 62%,#054151 100%); /* IE10+ */
	background: linear-gradient(to bottom,  #054151 0%,#0b556a 12%,#1b667b 62%,#054151 100%); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#054151', endColorstr='#054151',GradientType=0 ); /* IE6-9 */
	border-radius: 7px;
	-moz-border-radius: 7px;
	box-shadow: 4px 4px 4px #888888;
}
</style>
		</head>
		<body>
        <div id="main">
          <div id="wahuheader"> <!--<img src="/theme/assets/ohn/images/tvlogos.jpg" style="padding-top: 118px; padding-left: 345px;" alt="Loading..." />--> </div>
          <div id="content">
            <div class="fr" style="padding-right: 10px;"> <!--<a class="lktop mlktop" href="//ohcuniversity.com" target="_blank">MEMBERS LOGIN</a> <span class="lktop" style="padding-left: 0px;">|</span> <a class="lktop cliktop" href="/theme/assets/ohn/contact" target="_blank">CONTACT</a> --></div>
            <div class="clear"></div>
            <div id="maincontent2">
              <!--
              <div style="text-align:center;">                <div class="cong-block">
                  <div class="cong-block-top">
                    <div class="cong-flag-left"></div>
                    <div class="cong-flag-right"></div>
                    <div class="clr"></div>
                    <div class="cong-text"> There Are Currently <u class="numval"></u> Positions Left In Akron. </div>
                  </div>
                  <div class="cong-block-bot"></div>
                </div>
              </div>
            -->
              <div class="centerimg f21 automargin"> <strong>If you’re serious about securing your financial future and banking incredible profits ... keep reading.</strong> </div>
              <div class="centerimg"> <!--<img src="/theme/assets/ohn/images/if-you-can-spare.png" alt="Loading..." />-->

                <p style="font-weight:bold;color:red;font-size:250%;">"If You Don’t Take Advantage Of This Now,</p>
                <p style="font-weight:bold;color:red;font-size:250%;">You’ll Hate Yourself Later"</p>
              </div>

              <div class="centerimg automargin">

                <p>In just two years Chuck Hughes made over $460,000 in actual profits, using a simple trading system he developed – and now he’s practically <u>GIVING IT AWAY</u>!</p>

                <p style="font-weight:bold;">"Clear your schedule, lock yourself in a quiet room in your house, and dedicate the next 24 hours to getting the most out of what I’m about to tell you. It could be the 24 hours that will finally change the way you think about money."</p>
              </div>
              <!--
              <div class="centerimg f15 automargin" style="width: 815px;"> <span class="hilight"><strong>"Important: Read my full report now 
              because only 15 people are accepted into this program per city at any 
              given time... Due to the personal support given to each new member to 
              ensure everyone's quick financial success. Don't hesitate... this page 
              is taken down (literally) when the limit is reached, so read on..."</strong></span> </div>
              -->
              <div class="centerimg f18 automargin" style="width: 650px;"> <strong><span class="red">URGENT UPDATE:</span> I’m not sure how you got here or who recommended this site to you but I want you to pay attention because I will be offering you something <span class="hilight"><strong>FOR FREE</strong></span> that will <u>transform your life</u> <span class="hilight"><strong>IMMEDIATELY - OVER NIGHT!</strong></span></strong> </div>
              <div style="margin:auto; text-align:center;">
                  <!--
                  <iframe class="videoFrame" frameborder="0" allowfullscreen webkitallowfullscreen mozallowfullscreen msallowfullscreen width="480" height="360" name="vidly-frame" src="https://d132d9vcg4o0oh.cloudfront.net/embeded.html?link=5n7f8g&new=1&autoplay=true"><a target="_blank" href="https://vid.ly/5n7f8g"><img src="https://vid.ly/5n7f8g/poster" /></a></iframe>                </div>
                  -->
                  <center><img height="300" width="250" src="/theme/assets/ohn/images/chuck.jpg" /></center>
              <br />
              <div style="float: right; width: 290px;">
                <div class="testiheader1">
                  <h1>Have You Heard What<br />
                    Other People Are Saying?</h1>
                </div>
                <div class="testimonial">
                  <div class="toptesti"></div>
                  <div class="testicontainer">
                    <h1>Profitable Trades!</h1>
                    <img src="/theme/assets/ohn/images/kyleh.jpg" alt="Loading..." />
                    <p>I have been a subscriber for approximately seven months. What I lacked in computer literacy has been amply compensated by the help of your support staff. Together with your recommendations I have been able to compile a substantial record of very profitable trades.<br />
                      <br />
                      - <strong>Harry A.</strong></p>
                  </div>
                  <div class="bottomtesti"></div>
                </div>
                <div class="testimonial">
                  <div class="toptesti"></div>
                  <div class="testicontainer">
                    <h1>Proven Trading Pro</h1>
                    <img src="/theme/assets/ohn/images/testipic2.jpg" alt="Loading..." />
                    <p>I described you to my investment partner by telling him that you were like the Michael Jordan or Tiger Woods of Option Trading and Training.<br />
                      <br />
                      - <strong>Myra B.</strong></p>
                  </div>
                  <div class="bottomtesti"></div>
                </div>
                <div class="testimonial">
                  <div class="toptesti"></div>
                  <div class="testicontainer">
                    <h1>Complete Trust</h1>
                    <img src="/theme/assets/ohn/images/testipic3.jpg" alt="Loading..." />
                    <p>"Chuck is a man I feel I can trust with my family’s financial future. I use his methods now. And when I’m done trading for myself, he’s the one I want to do the trading for me and my family."<br />
                      <br />
                      - <strong>Don T.</strong></p>
                  </div>
                  <div class="bottomtesti"></div>
                </div>
                <div class="testimonial">
                  <div class="toptesti"></div>
                  <div class="testicontainer">
                    <h1>Massive Gains</h1>
                    <img src="/theme/assets/ohn/images/testipic4.jpg" alt="Loading..." />
                    <p>I'm a MVP member. I bought your rec'd option 0f EFUBT--Feb 100 call on 8/25 for $15.40/contract, I sold it today for $93.60 ( a 508% gain!!!!) on weakening MACD & ADX. I am hoping to roll it over to FEB 135 next week if the market has an up day, currently the EFUBG is $72. Would this be advisable, is it still a buy, or wait for one of your new rec'd? Thank you, especially for the 505% return.<br />
                      <br />
                      - <strong>Dr. Jack </strong></p>
                  </div>
                  <div class="bottomtesti"></div>
                </div>
                <!--
                <div class="testimonial">
                  <div class="toptesti"></div>
                  <div class="testicontainer">
                    <h1>Finally become financially independent!</h1>
                    <img src="/theme/assets/ohn/images/testipic5.jpg" alt="Loading..." />
                    <p>I'm excited about OHC University 
                      because I finally found an opportunity that provides step-by-step 
                      training and guidance to help someone start making money.  My goal is 
                      $10,000 a month now and I hope to buy a new car and home soon.  With the
                      mentor coach, and the training I believe I can eventually become 
                      financially independent.<br />
                      <br />
                      - <strong>Humberto R, CA </strong></p>
                  </div>
                  <div class="bottomtesti"></div>
                </div>
                -->
                <div class="noting"> *Testimonials are true and accurate. To protect our 
                  customer's privacy we replaced their picture with stock images. </div>
                <div style="margin-left: 25px; margin-top: 25px;"> <img class="sponsors" src="/theme/assets/ohn/images/search-partners.jpg" alt="Loading..." /> </div>
              </div>
              <div class="version3" style="text-align:left;">
                <p>FROM: Chuck Hughes</p>
                <p><strong>Dear Friend,</strong></p>
                <p>Let’s get real for a moment: Most people are struggling. </p>
              <p>It’s a fact.</p>
              <p>Unemployment is near the highest it’s ever been and many people are getting 2nd and even 3rd jobs to make up the difference.</p>
              <p>Most people are also relying on their 401K’s or other slow-growing bank accounts to keep them safe in their retirement.</p>
              <p>But let me ask you this: What’s your 401K done in the past 14 years? How about the past 20? </p>
              <p>It’s not very encouraging is it?</p>
              <p>...but since you’re here, this tells me that you are interested in changing that, getting out of your rut and making money online.</p>
              <p>My name is Chuck Hughes and I’m going to teach you today how you can easily reshape your financial future and <strong>start making a 6 or 7-figure income from home. </strong></p>
<p>Maybe you want to drive nice cars, live in a great house, get away for a few days on a nice vacation or simply make sure you don’t run out of money during your retirement. </p>
<p>If you don’t see “Walmart Greeter” on your resume in the future, I’m here to show you a different way. Everything you read above is possible and you can do all of that by investing your time and your money the right way. </p>
<p>Invest? That’s a scary word right? </p>

<p>And not just because most people have no idea what they’re doing. If you’re one of those people who’s been watching the stock markets rise and fall the past 5 years, it’s completely understandable that you’d be a little wary.</p>
<p>A thousand points in six months! Two hundred point drops! Booms and busts! Which are the best investments...</p>

<p>It gets confusing.</p>
 
<p>Or maybe, you just don’t think you’re smart enough. </p>

<p>But I don’t think that’s a valid argument.  Warren Buffet - arguably one of the most successful investors ever - said:</p>

<p style="font-weight:bold;font-size:200%">"You don’t need to be a rocket scientist. Investing is not a game where the guy with the 160 IQ beats the guy with 130 IQ"</p>
                

<p>It’s true – You don’t need to be the smartest guy in the room. There are lots of little guys out there making a killing each year. </p>

<p>And I’m one of them. </p>
<p>In the next few minutes I’m going to show you how I’ve helped create savvy, moneymaking individuals by showing them how to invest in stocks that provide the highest potential returns. </p>
<p>I’m going to teach you how to make the type of smart choices that could potentially change your life overnight and have you “working” as little as 5 hours per week.</p>
<p>I’m going to teach you <span class="hilight">MY system that is accurate 95.3% of the time</span> and how to make it work for you. </p>
<p>You don't need a fancy degree, an impressive work history, or even any previous experience. My system doesn’t work like that – it’s built to take advantage of the stock market and help you select winning trades.</p>
<p>I’m serious about your financial future and by being on this site, you’ve shown me that you’re serious about yours.</p>
<p>So, who am I?</p>



<center><p style="font-weight:bold;font-size:150%;color:red;">I’m A Guy That Made $4.4 Million In 4 Years</p></center>

<p>You can see it all right here:</p>

<table align="center" border=1>
  <tr style="background-color:gray;font-weight:bold;">
    <td>Total Profits</td>
    <td>Average Return</td>
    <td>Average Days in Trade</td>
    <td>Annualized Return</td>
    <td>Winning Trades</td>
    <td>Losing Trades</td>
    <td>Percent Wins</td>
  </tr>
  <tr>
    <td>$4,430,832.93</td>
    <td>58.6%</td>
    <td>76</td>
    <td>282.3%</td>
    <td>422</td>
    <td>21</td>
    <td>95.3%</td>
  </tr>
</table>

<br>

<p><strong><u>Even in an “off” year my system still made $240,000,</u></strong> but I’ll tell you more anout that in a minute.</p>

<p>As I said above, my name is Chuck Hughes. And I’m just like you. </p>
<p>I used to be a pilot that was looking for a way to create a financially stable future for my wife and my children. </p>
<p>I didn’t have any experience doing what I’m doing now...</p>
<p>...but I’m not an accidental success. I didn’t just stumble upon some good luck and make a few wild guesses on a handful of big trades. </p>

<p>If you’ve ever traded before, you know what I’m talking about. “Lucky guesses” don’t exist.</p>
<p>I decided to take ownership of my financial future and I worked hard to create a life where even in my off period I was bringing home nearly a quarter million in profit. </p>
<p>In fact, I’m an award-winning trader (I’ve got the trophies on my mantle to prove it) and I’ve won the World Trading Championship 7 times!</p>
<p>7 times I went up against the best and the brightest and I walked away with the top prize because of my investment knowledge and training. My years of hard work have paid off time and time again and have proven to me and to others that my strategies work.</p> 
<p>For over 25 years these strategies have proven themselves to be big moneymakers. The same system that helped me grow my money astronomically those first two years, even <span class="hilight">helped me make a staggering $1,026,174 in just 26 days.</span></p>
<p>Do you know what it feels like to <u>make $1,026,174 in just 26 days?</u></p>


<center><p style="font-weight:bold;font-size:150%;color:red;">FREEDOM</p></center>

<p>Freedom means having enough money to liberate, not incarcerate. And that’s exactly what my system provides – An expansion of your own potential.</p>
<p>That’s why you need to pay very close attention to this, because I am going to teach you exactly how I managed to become one of the top traders in the world.</p> 
<p>This is all about having the right tools and training and becoming financially secure - maybe more than you've ever been until now.</p>
<p>As I said before, I was looking for a way to create a stable financial future for my children. </p>
<p>Life is so uncertain and as a pilot, your income is only guaranteed as long as you have a job. I felt strongly that I needed to do something different and so I ventured into the world of trading. </p>

<p><span class="hilight">I started out with only a $4,600 trading account and in my first two years I made over $460,000 in profits.</span></p>

<p>Not bad for a newbie!</p>

<p>And I didn’t stop there. Over the years I developed a trading strategy and system that allowed me to secure my children a strong financial future and I was quickly growing my trading account just by basing all of my trading choices on my own easy trading system. </p>

<p>All I ever wanted was safety and security, but investing brought me so much more. I was able to retire from my job as a pilot in my 40’s, and I haven’t looked back since.</p>


<center><p style="font-weight:bold;font-size:150%;color:red;">I Said Goodbye To My "Real Job"</p></center>

<p>The bottom line is, deciding to step out of my comfort zone and go after something more for my family changed my life, just like it can do for you. It truly has been an extraordinary blessing.</p>
<p>But just like anything else, there is a downside, and it’s this…</p>
<p>Before we go any further, I do have to warn you, <u>this is NOT for everybody.</u> But if you are smart, determined to change your current situation, and would like to make more money this year than you ever have before – this is the PERFECT thing for you to be doing from the comfort of your own home.</p>
<p>So whatever you do, <span class="hilight">do NOT put this off</span> or come back to it later. By taking advantage of my system now, you can experience the same success that others have accomplished with my system as well!</p>


<center><p style="font-weight:bold;font-size:150%;color:red;">I’ve Created Multiple 6-Figure Earners With My System</p></center>


<p>Chances are, you haven’t had much success up to this point because you’ve been looking to the wrong people for the wrong information.</p>

<p>I’ve dealt with that many times and I can tell you that this information is for everybody. No matter the time or situation, it’s never too late to start incorporating winning strategies.</p>

<p>Here’s what some of my students have to say about their success:</p>

<p style="font-weight:bold">"Following his recommendations, the profits started rolling in right away. My percentage of winning trades is around 80% to 90%. My trading account is already up 50%. And growth is really starting to accelerate."</p>

<p style="font-weight:bold">- Dr. David V.</p>

<hr>

<p style="font-weight:bold">"I’m down here in Florida with my family enjoying our vacation home. I just wanted to thank you for helping me achieve my financial independence! I have gains of $1,646,616 thanks to you! Your recommendations take very little time to execute . . . I’ve been averaging over $45,700 a month in profits over the past three years. I’m sending a big thank you your way"</p>

<p style="font-weight:bold">- Dan J., Florida</p>

<hr>

<p style="font-weight:bold">"I knew I had to start investing but was unsure how to go about it. Everything out there seemed complicated and confusing. Then a friend introduced me to your strategies. The strategies are easy to use and best of all they really work! All thirteen of my trades are winners! I originally started with $16,300 and now my account has grown to more than $62,000. I currently have a $35,225 profit and an average return of 127% over the past 5 weeks. Not bad for a beginner! Thanks to you Chuck I am on my way!"</p>
<p style="font-weight:bold">- Anne, New Jersey</p>


<center><p style="font-weight:bold;font-size:150%;color:red;">Your Finances No Longer Have To Be  A Jail Sentence</p></center>

<p>Freedom means having enough money to liberate, not incarcerate. And that’s exactly what my system provides – An expansion of your own potential.</p>
<p>Whether you’re starting with $100 or $10,000 – <span class="hilight"><b>you have the potential to earn big this year...</b></span></p>
<p>But first, let me ask you an important question...</p>
<p>What would you really like to have out of life?</p>
<p>• Maybe it’s to have an “always stuffed full” bank account, or <b>to live a life of total freedom on YOUR terms.</b></p>
<p>• Or perhaps you’d like to <span class="hilight">work when and where you want</span> — and have time for the things you really love, like traveling to exotic places, enjoying your favorite hobby, or just hanging out with your kids.</p>
<p>• It could be as simple <u>as going to sleep each night knowing you own a beautiful home, a sleek new car, and you don’t owe a dime to anybody.</u></p>
<p>That’s powerful. And <span class="hilight">it’s all entirely possible.</span></p>
<p>Imagine for a moment your “work commute” is a short walk to your home office, with a view of your garden. You stroll in anytime you want, sit down at your computer, access the Internet, and begin.</p>
<p>You work as much or as little as you want. You never have to ask for permission from anybody—you can kick back and enjoy lunch with a friend, or go to your child’s soccer game.</p>
<p>Every once in a while you think about how life used to be—when you were frustrated working for a boss who seemed to get his kicks from making YOUR life miserable. Or the terrible times when you lost your job (or were barely getting by) and didn’t know how you were going to pay the electric bill, let alone feed your family.</p>
<p>Yes, life is definitely better now. And it doesn’t have to be a dream—this can be your everyday reality!</p>
<p>And my system will show you how – but first, I want to tell you</p>


<center><p style="font-weight:bold;font-size:150%;color:red;">7 Reasons Why You Should Invest</p></center>

<p>1.  Simply put, <span class="hilight">you want to invest in order to <b>create wealth</b></span>. It's relatively painless, and the rewards are plentiful. By investing in the stock market, you'll have a lot more money for things like retirement, education, recreation -- or you could pass on your riches to the next generation so that you become your family's Most Cherished Ancestor. Whether you're starting from scratch or have a few thousand dollars saved, Investing Basics will help get you going on the road to financial well-being.</p>

<p>2.  <span class="hilight">Stocks are poised for growth.</span> Historically, stocks have rebounded following a recession or a bear market. The rebound may have been swift or slow, but it has always happened. <span class="hilight">AND you can make money on the highs as well as the lows.</span></p>

<p>3.  <u>Stocks offer the potential for quick income and long-term growth.</u></p>

<p>4.  <b>Stock market investment can produce huge returns</b> that are otherwise impossible from any other type of investment provided you invest in the right stocks. Investors have realized massive gains by investing in the right stock.</p>

<p>5.  <span class="hilight">You don’t have to be a millionaire</span> – Even if you only have a small amount of money to invest in the stock market you can earn good returns by investing in stocks. Even with a small account you can realize huge profits with the right strategies.</p>

<p>6.  No need to commute to work ever again—You can work from the comfort of your home, and your “drive to work” can be a short walk to your computer.</p>

<p>7.  <b>Complete flexibility</b> — No need for rigid work hours. Work WHEN you want, from WHERE you want, as MUCH as you want. You have complete freedom to choose.</p>



<center><p style="font-weight:bold;font-size:150%;color:red;">Here’s What I’ve Got For You...</p></center>

<p>As you will soon see, I’ve created an incredibly valuable resource for you, with everything you need to assure your success.</p>
<p>Because not only do you need to know a few tricks of the trade that make this super fast and easy for you to do—you need to have access to my brain, my strategies and years and years of my work.</p>
<p>But that’s impossible…it would take you years to learn what I’ve spent the last 25 years learning...</p>
<p>But you don’t have to.</p>
<p>What if I said you could spy on America’s most successful Wealth Creation Alliance and ethically “steal” one of their most closely guarded secrets and use that secret to find stocks and ETFs poised to soar? </p>
<p>Then, like "shooting fish in a barrel" look to hit 94.5% winning trades? </p>
<p>Well, there’s no stealing needed because that’s exactly what I’ve put together for you...</p>

<center><p style="font-weight:bold;font-size:150%;color:red;">Access To America’s Most Successful Wealth Creation Alliance</p></center>


<p>With exclusive access to the WCA, you’re getting access to the same strategies and system that <b>gave me the tools I needed to win the World Trading Championship a record 7 times – more than any other trader in history.</b></p>
<p>You’ll learn the important secret to creating vast wealth in a short period of time. Things like timing, exit strategies and money management. </p>

<p>In WCA, I reveal the specifics for each, as they apply to each profit boosting strategy I use. </p>

<p>But none of this comes into play until <span class="hilight">AFTER the single MOST important secret to trading success is revealed.</span></p>

<p>That’s why I opened the WCA system with this one all-important secret.</p>

<p>And I’m giving it to you...</p>


<center><p style="font-weight:bold;font-size:150%;color:red;">Become Part Of The WCA Today!</p></center>

<p>Join us using the system that fuels my advisory service where I have shown trades <b>worth well over $7,000,000 in the past 14 years.</b> </p>
<p>And allowed my students to experience this:</p>

<p style="font-weight:bold">"Once I started using your strategies – boy, did my life change. It has been amazing! Your approach to wealth-building is easy to understand and simple to implement. My husband and I are now thinking of buying a retirement home in Santa Barbara with the proceeds."</p>

<p style="font-weight:bold">- Helen M.,California</p>

<p>Just like Helen, this will give anyone, even if you’re a novice trader, a solid base upon which you can grow, thrive and profit from. </p>

<center><p style="font-weight:bold;font-size:150%;color:red;">So How Much Does The WCA Cost?</p></center>

<p>How much do I require from you to have access to my trading methods and tactics that deliver <b>6 and 7 figure returns</b> in MUCH less time than any other investment vehicle out there?</p>

<p>I can tell you this much, for my advisory service, I require 5-figure fees for them to get in the front door. </p>

<p>This isn’t my advisory service though. This is something new. This is an answer to all the “regular” investors I talk to every day. It’s a simple invitation from me to you saying:</p>

<p>"Follow me. Learn what I do, how I do it and what it can deliver. Let’s change our lives for the better... Together."</p>

<p>It’s in a way a chance for me to give back. I’ve done so well in life, it’s time for me to take a leadership role and step up my efforts to improve the lives of those around me. </p>

<p>I don’t want you spending all your money on my system when it’s going to do more for you by being invested. I know that once you make money with my strategies, you’ll come back and join the WCA.</p>

<p>With that philosophy, I’m going to offer this now for only:</p>



<center><p style="font-weight:bold;font-size:150%;color:red;">Get Access Today For $39.95</p></center>

<p>This one secret has made the <span class="hilight">WCA one of the most successful and continuously profitable advisory services in the entire world</span> and is the powerful secret weapon I have been using for 25 years. </p>

<p>In all those years <u>I have never wavered</u>. And <u>it has never let me down</u>.</p>

<p>It’s how I won all those championship trophies… not to mention the millions of dollars in actual profits.</p>

<p>I call it <b>Prime Trade Select</b>. And it’s the surefire secret formula I use to select optimum stocks and ETFs to buy and sell. </p>

<p>Do you remember back in the late ‘90s, when they used to say you could throw a dart at the NASDAQ stock page... Buy whatever stock it landed on. . .And come out a winner?</p>

<p>Well, that “can’t lose” vision is completely accurate for the list of stocks and ETF’s identified by Prime Trade Select.</p>


<center><p style="font-weight:bold;font-size:150%;color:red;">Seek 6,083% Return the Easy Way!</p></center>

<p>The first 49 minutes of the WCA System was devoted entirely to my Prime Trade Select formula…</p>

<p>...and you can have this power-packed portion of the system for just $39.95.</p>

<p>And here’s the really interesting part. . .</p>

<p>The reason I spent so much time on Prime Trade Select was not because it’s hard. But because <span class="hilight"><b>it’s so easy!</b></span></p>

<p>I know that may seem like a ridiculous price for something this powerful - something that taps my own personal knowledge. </p>

<p>To be honest, this is something that would really anger my advisory service clients for “giving away the secrets”, but this is what I have settled on. I want to get to work quickly, and I figure at this price, you will be back in no time to join the WCA.</p>

<p>Unfortunately, that also poses a problem since I won’t be able to offer this to very many people at this insane price, because as we all know, it’s going to sell out fast. And once it’s gone, it’s gone. </p>

<p>It has to be that way because I take my student’s success VERY seriously. I’m only interested in mentoring individuals that are ready to take control of their financial future.</p>

<p>I truly want this to be something you can decide to do right now—without worry—so you can turn your life around starting TODAY.</p>

<p>That’s why this is so limited...</p>

<p>...but there’s another reason...</p>

<center><p style="font-weight:bold;font-size:150%;color:red;">You’ll Get A One-On-One Session With My Strategist </p></center>

<p>When it comes to earning a great income right from the start, working with a strategist really gets you going immediately – but I only have a few.</p>
<p>If you follow in the footsteps of those who are successful you tend to achieve the same results. I’ve literally trained hundreds of people to do what I do, and very successfully, too.</p>
<p>So I picked from the cream of the crop, to assemble a team of experienced experts as my strategists.</p>
<p>They’re ready to give you unprecedented access to their expertise—something practically unheard of anywhere. I mean, when was the last time anybody cared that much about you or how well you do?</p>
<p>It’s important to have a mentor who can assist you in putting together a “game plan” for your success.</p>
<p>They’ll be there to discuss your financial goals and help you achieve the type of income you are looking for.</p>
<p>And that’s not all...</p>




<center><p style="font-weight:bold;font-size:150%;color:red;">Bonus #1 – "Stock Market Magic"</p></center>

<p>The secrets revealed in “Stock Market Magic” are easily worth hundreds of dollars. . .or even millions, if you consider their profit-potential. </p>

<p>Yet, you will pay nothing for this valuable 127-page tell-all report. It is my gift to you when you say "yes".<p>

<p>"Stock Market Magic" shows you how to seek millions of dollars by simply buying and selling stocks. And that’s it. You don’t need to buy on margin and you don’t need to use options to enhance profits. Yet our test portfolio of 34 stocks grew 2,567%!</p>


<center><p style="font-weight:bold;font-size:150%;color:red;">Bonus #2 – FREE Report: Options Trading With High Accuracy</p></center>

<p>Anyone joining us will also receive a FREE report, Options Trading With High Accuracy. This report teaches you how to trade options and almost never lose!</p>

<center><p style="font-weight:bold;font-size:150%;color:red;">Once You Make Money Investing – You’ll Be Back</p></center>

<p>Once you’ve seen what this first part of the WCA System can do for you… and your curiosity turns into a burning desire...you won’t be able to resist joining the WCA and taking part in the whole 7-part system. </p>

<p>So, included in your fulfillment package you will find a <span class="hilight">bonus gift certificate worth $1,535.25!</span></p>

<p>Your bonus gift certificate will grant you. . . </p>

<p><span class="hilight"><b>75% DISCOUNT:</b></span> You’ll receive a whopping 75% discount off the regular price of $1,995, bringing your price for the full system. . .guaranteed to help you regain your financial bearing and restore the American Dream. . .down to just $498.75! </p>


<center><p style="font-weight:bold;font-size:150%;color:red;">I Want To Make Your Decision Easy</p></center>

<p>I don’t think I can be any fairer than this. I’m really doing my best to make this work for you.</p>
<p>Right about now you may be getting pretty excited about the possibilities—but perhaps there’s still a little doubt saying...</p>
<p>Is there a catch?</p>
<p>I hear you—I really do. And the answer is no, there’s no catch.</p>
<p>I’ve gone round and round deciding how I could break this up and still have you get some phenomenal strategies and money-making tools without going "all in".</p>
<p>The full $1,995 is much higher than what I’m offering today but I’m positive that once my award winning strategies help you make massive returns on your investments, you’ll join the WCA full time. </p>
<p>I mean, just look around you at what MOST other people are doing for a living! In almost every case they are working MUCH more for far LESS pay.</p>
<p>I wanted to make my system accessible to anyone who wanted it. I think back to when I was just a pilot looking for financial stability for my kids.</p>
<p>So my decision is final—get instant access to part 1 of the WCA System and my Prime Trade Select for only $39.95. No additional payments, no membership fees, no additional hidden costs.</p>
<p>This offer is extremely limited! There’s a lot of effort going into getting you started as quickly as possible, including the personal one-on-one call with my strategist.</p>
<p>Therefore, I can only admit a limited number of people into the program at this time.</p>
<p>So if you’re smart enough to know a good thing when you see it, apply now.</p>



<center><p style="font-weight:bold;font-size:150%;color:red;">There’s One More Question To Answer...</p></center>

<p>Do I guarantee your income? No. You may do absolutely nothing except sit around thinking about it—and obviously you DO have to put some effort into this.</p>
<p>So—if you’re expecting your fairy godmother to wave her magic wand over your head (and bank account) without you lifting a finger—this isn’t for you.</p>
<p>And actually, I don’t want those types of people even considering the WCA.</p>
<p>Fair enough?</p>
<p>However, if you are looking for proven and award winning investing strategies and are willing to commit to working at least 10 – 20 minutes per day at this, this is for you.</p>
<p>If you’re ready, I’ll also give you an absolute guarantee in writing, so you don’t risk even the modest investment of $39.95. You’re completely protected by my Zero Risk 2 Year Guarantee...</p>


<center><p style="font-weight:bold;font-size:150%;color:red;">Your Satisfaction Is Guaranteed For 2 Years!</p></center>

<p style="color:red;font-weight:bold;">My Guarantee To You:</p>

<p>Take up to 2 years to use my system and if you are not absolutely satisfied for ANY reason, just let me know. I’ll send you a prompt and courteous refund of your full $39.95 with no questions asked.</p>
<p>As you can see, I’ve completely removed all risk for you. So let’s get started!</p>


<center><p style="font-weight:bold;font-size:150%;color:red;">Here’s What To Do Next...</p></center>

<p>You’re now at the point of making a critical decision.</p>
<p>Remember, this system works. Don’t take my word for it. My awards speak for themselves as do my current students:</p>
<p>".....I’m trying to get where I can find my own trades and make at least 200% a year. I can already make 100% or so. We’ve been doing that for the past 3 or 4 years. But my goal is to make 200% or 300%. We only invest about 5% of our account in any one trade; so we need to win big and win often to compete with the trading master.” Myra: “Bob wants to be a champion trader like Chuck.” Bob: “Well, no one expects to compete with Chuck’s 7-win record. But, I’d like to win at least once."</p>

<p>- Bob & Myra B</p>

<p>"I made nearly $30,000 profit in just one day!"</p>

<p>- Dr. Jack</p>

<p>My heartfelt thank you for your time and your generous effort to help us at WCA workshop. My trip to your workshop has been very fruitful and worthwhile. I came home with a lot of learning from one-day workshop like your methods of deep ITM spreads, option income strategy and the ideal strategy for volatile markets. I will follow your proven winning strategies.</p>

<p>- Joe K.</p>

<p>I’m excited to have you as part of my system and I can’t wait to hear your winning trade stories!</p>

<p>To your success,</p>

<p><b>Chuck Hughes</b></p>


                <!--
                <p>If I could show you an <span class="hilight">easy proven and guaranteed way to make $ 379 a day</span> and more, working part-time from the comfort of your home... Would you be interested?</p>
                <div class="float-right marginimgrl"> <img src="/theme/assets/ohn/images/customerimg.png" alt="Loading..." /> </div>
                <p>If YES! Then <strong>this will be the most exciting message that you will ever read.</strong></p>
                <p>Let me tell you why:</p>
                <p>My name is Melissa Mayer and I have worked hard my whole 
                  life. Really, really hard. Like most other Americans, I still lived from
                  pay check to pay check.<br />
                </p>
                <p>When I had to raise my child on my own, I found myself
                  working multiple jobs to make ends meet. It seemed like that no matter 
                  what I did, I couldn't get ahead. I despised the time away from my 
                  child. I really hated my jobs, the debt I faced and my bosses.</p>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/chillingday.jpg" alt="Loading..." /> </div>
                <p>That day sticks out in my mind with crystal clarity. I was 
                  working all the time, trying to scratch out a living for myself and my 
                  small daughter and I was laid off from my full-time job. This was the 
                  one I relied on to pay most of the bills. My child needed things and I 
                  could no longer afford to buy them! I didn't know how we were going to 
                  get by.</p>
                <p>I cried for what felt like days. I felt lost, helpless,
                  sad and scared. Then I suddenly got mad and I focused myself on looking
                  for a better way and it started on the internet. I mean this is the new
                  wild west, anyone can go out and be the next multi-millionaire or start
                  a website that suddenly makes them quit their day job. I needed another
                  income immediately, something very quick. And I was thinking about it, I
                  asked myself: Before I make a sudden move that will tie me into another
                  job that I will hate, why don't I consider what it is I want... and do 
                  not want... in a job?</p>
                <p>So first, I began thinking about what I DON'T want in a job...</p>
         
                <div class="dontcont">
                  <ul>
                    <li><span class="hilight">I do not want a boss.</span></li>
                    <li>I do not want to be on anyone else's time.</li>
                    <li><span class="hilight">I do not want to have to wake up so early anymore, especially to that loud alarm clock.</span></li>
                    <li>I do not want to commute anymore and sit for hours ... frustrated ... in traffic.</li>
                    <li>I do not want to go and work in an office. </li>
                    <li>I do not want to be part of a business of any kind either, 
                      with troubles like a storefront, investment, inventory, employees, 
                      extensive record-keeping, or having to sell products to anybody.</li>
                    <li><span class="hilight">And I do not want anything that 
                      requires special training, education, or skills, because I do not have 
                      any and I don't have the time or finances to get any right now.</span></li>
                  </ul>
                </div>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/thenibegan.jpg" alt="Image" /> </div>
                <div class="docont">
                  <ul>
                    <li>I want to work from home or anywhere else I choose. I want a
                      job that will give me the free time I desire to spend with my daughter 
                      who has suffered from our situation the past few years.</li>
                    <li><span class="hilight">I want an income that will give me and
                      my daughter more then we need to pay the bills and reward us with a few
                      treats now and again.</span></li>
                    <li>I want to take time off whenever I want and I want to have plenty of time for other people including myself and my hobbies.</li>
                    <li>I want something that will be reasonably easy.</li>
                    <li>I want a job that I will enjoy 100% of the time.</li>
                    <li><span class="hilight">I want to only work a few hours a day, whenever I choose.</span></li>
                    <li>And I want and need to start making money immediately.</li>
                  </ul>
                </div>
                <p>And do you know what... to my surprise two weeks after this terrible day...</p>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/ifoundmy.jpg" alt="Image" /> </div>
                <p>And here is how it happened:</p>
                <p>After I knew what I wanted, I started talking to 
                  people about it. Most of people didn't take me too seriously. I didn't 
                  even know if my 'dream job" existed anywhere. Still, I made the decision
                  to look for it. Then I met a man who worked at home, part-time and had 
                  done so for years. He told me how he did it and shared with me how to 
                  get started.</p>
                <p>It only took about three months for me to be able to quit my 
                  other jobs. Thanks to that man, I now had an easy work at home job that 
                  involved no more than four hours a day of work and enabled me to make 
                  more than DOUBLE my prior earnings. I didn't have a boss and I could 
                  work as much or as little as I wanted. I began paying off my debt, and I
                  watched both my life and my daughters completely turn around.</p>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/mydebts2.jpg" alt="Image" /> </div>
                <p>Fast forward to today and I am now a millionaire. I still work 
                  at home but now, that home is my dream house. I am able to buy what I 
                  want, take long vacations, and give my daughter the life she deserves 
                  and more.</p>
                <p><span class="hilight">Financial worries are a thing of the past
                  for me now. I am happy, free and secure. This is the best feeling ever!
                  I want you to have that same feeling.</span></p>
                <p><strong>My entire life turned around so quickly, that I just 
                  felt like I had to share my experiences with others. Ever since then, 
                  I've been able to help thousands of others just like you realize their 
                  dreams and financial goals.</strong></p>
                <p>You may be familiar with me from the one day work at home 
                  seminars I used to present in New York City. Others know me from the 
                  numerous interviews, podcasts and teleseminars that I have done in the 
                  past. And there are so many people coming to me today for help and 
                  advice on getting started working from home that I've been called the 
                  number 1 work at home consultant in America.</p>
                <p><span class="hilight"><strong>And right here, right now, I am going 
                to tell you everything you need to know about making the money of your 
                dreams from home, starting today!</strong></span> I'm going to tell you 
                  about the best opportunity I have ever discovered... A legitimate, 
                  proven, and easy work at home job opportunity that can make your 
                  financial dreams come true, as it did for me and has done for thousands 
                  of other people worldwide!</p>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/theseworkfrom.jpg" alt="Image" /> </div>
                <p>There are some 24 million people that work from home! 
                  Did you know that? That's a huge chunk of the population and every year 
                  more and more people are fleeing the rat race to work from home.</p>
                <p>So why the boom in people working at home?</p>
                <p><strong>It's simply realistic and easy these days to make a great income from home. </strong>The
                  Internet has made it a snap for people to earn their living right at 
                  home. In fact, many companies ' big and small ' are working closely with
                  home-based employees and contractors.<br />
                  Perhaps one of the fastest rising opportunities involves Internet 
                  link posting. This means posting links on the Internet for others.</p>
                <p><span class="hilight"><strong>So, let me tell you about it:</strong></span></p>
                <p><strong>Chances are you've seen links offered with many products you've purchased before.</strong> Let's say, you're on the Internet and you see a link for an MP3 player 
                  you like for $100. The link will take you where you need to go to buy 
                  the player or see the company's website.</p>
                <p>Do you know why the link is there?</p>
                <p>It simply entices you to buy the player! Yes, the 
                  company makes a little less because it placed the link on the website 
                  you visited. But, it makes more money because more buyers have an 
                  opportunity to see the link and the products offered. The company ends 
                  up making more money than the link cost ' by a long shot ' because of 
                  the volume of business. A lot of companies, in fact, see their sales 
                  rise by 10-20% just because of linking. This amounts to millions and 
                  billions in increased sales.</p>
                <p><strong>Now, I bet it makes sense why tens of thousands of companies offer links for their products and services!</strong> Both small businesses and large corporations do this. And here's where 
                  the massive money-making opportunity knocks on your door because of 
                  it...</p>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/companiesaredesperate.jpg" alt="Image" /> </div>
                <div class="line11"></div>
                <div>
                  <p><span class="hilight"><strong>The truth is there are millions of links placed every year and companies need a whole lot of people to process them!</strong></span> Most companies do not post their own links. They would have to expand their operations and hire thousands to do so. </p>
                  <p><strong>Instead, they bring in people of any age and 
                    background from the outside to work in their own homes and post these 
                    links. This job can be performed from anywhere at any time. It just 
                    makes more sense for companies to contract out this job!</strong><br />
                    <br />
                    While this opportunity is simple, and I will explain the how-to 
                    in a bit ' it is great because of the massive volume that can come from 
                    just ONE single link.</p>
                </div>
                <div class="clear"></div>
                <p><b>Look at it this way ' it takes about 4 minutes to post a 
                  link. This works out to about 15 links in an hour. The average amount 
                  people make a link is $15. That's a whole lot of money for not much 
                  work! In fact, it's about $225 for an hour. Do the math! That adds up to
                  more than $58,000 a year for an hour a day!</b></p>
                <p><strong><span class="hilight">The best part is, you can work as little or as much as you want</span></strong>. It really doesn't matter. I put in about four hours a day. That's because I like it and I love the income.</p>
                <p>It's clear to see that it's possible to earn a serious income 
                  with this opportunity. The choice is yours! The above examples are just a
                  few of the successes this opportunity has produced. You can earn less 
                  by doing less, or you can earn more. I really have to say, people are 
                  shocked when they see how much I make posting links from my own home!</p>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/heresacalculator.jpg" alt="Image" /> </div>
                
                <!-- calculator app--
                <div class="line14"> <span class="line15"></span>
                  <div class="clear"><br />
                  </div>
                  <div class="line16">
                    <ul>
                      <li> <span class="line16-lft">How many links will you post a day?</span>
                        <select class="line16-rght" id="postAday">
                          <option value="5">5</option>
                          <option value="10">10</option>
                          <option value="15" selected="selected">15</option>
                          <option value="25">25</option>
                          <option value="35">35</option>
                        </select>
                        <div class="clear"></div>
                      </li>
                      <li> <span class="line16-lft">Average money earned for each Link?</span>
                        <select class="line16-rght" id="avEarnPerLink">
                          <option selected="selected" value="$10">$10</option>
                          <option value="$20">$20</option>
                          <option value="$25">$25</option>
                          <option value="$30">$30</option>
                        </select>
                        <div class="clear"></div>
                      </li>
                      <li> <span class="line16-lft">How many days a week will you work?</span>
                        <select class="line16-rght" id="daysOfWork">
                          <option selected="selected" value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                          <option value="4">4</option>
                          <option value="5">5</option>
                          <option value="6">6</option>
                          <option value="7">7</option>
                        </select>
                        <div class="clear"></div>
                      </li>
                    </ul>
                  </div>
                  <div class="clear"></div>
                  <span>
                  <button class="line17" id="calculate"></button>
                  </span>
                  <ul class="line18">
                    <li>Daily Income: <span id="dailyIncome">$150.00</span></li>
                    <li>Weekly Income: <span id="weeklyIncome">$150.00</span></li>
                    <li>Monthly Income: <span id="monthlyIncome">$600.00</span></li>
                    <li>Yearly Income: <span id="yearlyIncome">$7800.00</span></li>
                  </ul>
                   </div>
                <!-- end calculator --
                <br />
                <p>As you can see, you can make a part-time income with this or a 
                  full-time income with it. Since you're the boss, the choice is up to 
                  you. The above are just a few examples. You can do less and you can do 
                  more. And I got to tell you, people are often shocked the first time I 
                  show them the amount of money to be made positing links from home. It is
                  really remarkable...</p>
                <p><span class="hilight"><strong>It's amazing! And there are, however, 3 main reasons why posting links is so profitable:</strong></span></p>
                <p><span class="hilight"><strong>Reason #1:</strong></span> Companies are seriously desperate to find more people to post links. 
                  When demand beats out supply, wages rise. The old Law of Supply and 
                  Demand works here ' in your favor!</p>
                <p><span class="hilight"><strong>Reason #2:</strong></span> The 
                  cost of hiring employees to do this would be outrageous. By having 
                  independent at-home workers, companies save on salaries, management 
                  costs, office space, benefits and a whole lot more.</p>
                <p><span class="hilight"><strong>Reason #3:</strong></span> Companies see real results in their sales when links are posted. They're
                  making millions more every month. This is great money because it works.</p>
                <p>To sum it all up...</p>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/itsanethical.jpg" alt="Image" /> </div>
                <div class="line21"></div>
                <p>I still can't believe I've become a millionaire just from posting links, but it's true! In fact, <strong><span class="hilight">I've been doing this for more than five years</span></strong> and most likely know more about this type of work than anyone else in 
                  the world. I've become a pioneer of sorts. This is why I've been so 
                  successful in teaching others the skills they need to succeed!</p>
                <p>The companies I work with have been so happy with my spreading 
                  the word, one suggested I created a certification program. So, I did. It
                  offers an easy-to-follow, step-by-step approach.</p>
                <p><strong><span class="hilight">This is the only certification program you'll find for search engine link posting.</span></strong> So far, more than 1,000 people worldwide have been certified and are making their own financial dreams come true.</p>
                <p>This program has received rave reviews by many people in the at-home work industry. <strong><span class="hilight">In fact, my website is rated No. 1 by some of the leading work-at-home review sites.</span></strong></p>
                <p>To see why this program is so popular, consider the benefits 
                  and remember you can start right away and make the money you need, want 
                  and desire!</p>
                <p>First off, you'll get to access to our training center that will offer you everything you need to know, step by step.</p>
                <p><span class="hilight">Plus, I will offer insights on the best places to start out with.</span> Don't worry about being overwhelmed with the choices! I will help you pick the very best ones to pursue.</p>
                <p>To make sure you get off to a good start, I'll give you a master <strong><span class="hilight">list of companies that pay the most for link posting.</span></strong> I'll also provide you with real-time updates of the highest paying 
                  companies. This way you will always know who will pay the most for your 
                  time!</p>
                <p>When you enroll in the certification program, <strong><span class="hilight">you will be GUARANTEED an immediate opening!</span></strong></p>
                <p>Here's another reason why the program is great: Even though you're posting links for a reputable company...</p>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/youdonteven.jpg" alt="Image" /> </div>
                <p>Really! <strong><span class="hilight">There's no one watching over your time when you do this. You don't report to anyone.</span></strong> While you'll post links on a company's behalf, you won't work for that company. You'll retain your independence.</p>
                <p>What it all boils down to is that by signing up with a company,
                  you'll get access around the clock, seven days a week to links that 
                  need posting. <strong><span class="hilight">You won't have any obligations to work though.</span></strong> You can choose your times. You can work when you want. You retain the control.</p>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/customerimg2.jpg" alt="Image" /> </div>
                <p>And as I told you, posting links is very simple and easy! You're given access to your own personal account and all you do is...</p>
                <div class="clear"></div>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/justfollowthese.jpg" alt="Image" /> </div>
                <div class="simplestep">
                  <p><span class="hilight"><strong>Simple Step #1:</strong></span> Log into your account and copy the link coding the system gives you. Here's an illustration:</p>
                </div>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/wah-members-login.jpg" alt="Image" /> </div>
                <div class="simplestep">
                  <p><span class="hilight"><strong>Simple Step #2:</strong></span> Enter your section of your account when you're given customer records 
                    for you to post links for. New customer names are added to your personal
                    account around the clock. This means you'll always have work when 
                    you're ready. Here's an illustration:</p>
                </div>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/sc1wahu.jpg" alt="Image" /> </div>
                <div class="simplestep">
                  <p><span class="hilight"><strong>Simple Step #3:</strong></span> Just fill out a few simple details and submit to create your links. Sit
                    back and enjoy your financial success!  Just keep working a few hours 
                    each day or whenever you want and the cash just keeps flowing in.</p>
                </div>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/ipad.jpg" alt="Image" /> <br />
                  <br />
                  <img src="/theme/assets/ohn/images/its-that-simple-all-you-need-to-do-is-complete-those-three-s.png" alt="Image" /> </div>
                <p>That's it! Follow these three easy steps and you're done! To 
                  fill out one link took you 1 to 2 minutes and, you just made $15 
                  dollars! Do this over and over again, as much as you want, to make all 
                  the money you want!</p>
                <p>Process 5 links for $75 a day... 15 links for $225 a day... 30 links for $450 day...or more! To put it another way... </p>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/makingthemoney.jpg" alt="Image" /> </div>
                <p><strong>Perhaps the best part is you can actually see how much 
                  money you're making just by clicking on the earnings section of your 
                  personal online accounts. <i class="txt-lght">Here's a look at it:</i></strong></p>
                
 
                <div class="tabularCon">
                  <table>
                    <tbody>
                      <tr>
                        <td></td>
                        <td class="caption"> Last 1 Hour </td>
                        <td class="caption"> Yesterday </td>
                        <td class="caption"> This Week </td>
                      </tr>
                      <tr>
                        <td class="caption strong"> Amount Attempted: </td>
                        <td> $161.89 </td>
                        <td> $956.52 </td>
                        <td> $6,445.31 </td>
                      </tr>
                      <tr>
                        <td class="caption strong"> Amount Declined: </td>
                        <td> $0.00 </td>
                        <td> $0.00 </td>
                        <td> $0.00 </td>
                      </tr>
                      <tr>
                        <td class="caption strong"> Pre-Authorized: </td>
                        <td> $112.18 </td>
                        <td> $632.01 </td>
                        <td> $5,324.94 </td>
                      </tr>
                      <tr>
                        <td class="caption strong"> Total Amount Settled: </td>
                        <td class="highlight"> $112.18 </td>
                        <td class="highlight"> $632.01 </td>
                        <td class="highlight"> $5,324.94 </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div class="clear"></div>
                <p style="line-height:normal; margin-top:30px;"> This is sort of like a bank statement that shows your income for 
                  every link posted. It's updated every 30 minutes, too, so you can see 
                  your earnings in real time.</p>
                <p>I personally love to click on my earnings report more than 
                  anything in the world and, I check it all throughout the day! It's 
                  really motivating to instantly see the money you're making. You don't 
                  have to wait to see your pay... you can see it verified anytime you want
                  in your personal account. It's a really amazing, comforting, and 
                  uplifting feeling you have to experience for yourself!</p>
                <div class="centerimg red f17"> <img src="/theme/assets/ohn/images/with-the-internet.png" alt="Image" />
                  <p>Sure, everything in life requires effort.  However we are living proof that the<br />
                    Internet can bring you earnings like these:</p>
                </div>
                <div class="centerimg1"> <img src="/theme/assets/ohn/images/transaction-activity.jpg" alt="Image" /> </div>
                <br />
                <br />
                <div class="centerimg1"> <img src="/theme/assets/ohn/images/hereswhats.jpg" alt="Image" /> </div>
                <div class="line25">
                  <p><span class="line26">With this work-at-home job, you won't have to wait weeks or even a month to get paid. <strong><span class="hilight">About 75 percent of companies will pay you weekly</span></strong>.
                    The rest only take 2-4 weeks to transfer money right into your bank 
                    account. The companies I work with are all reputable and I have never 
                    had a problem getting payments on time. This is simply a great 
                    opportunity for anyone who needs to make real money, real fast!</span></p>
                  <p><span class="line26">You will find your personal account is super easy to use. <strong><span class="hilight">It was created for people with no computer experience and was designed to be easy to learn how to use.</span></strong> If you can check email, you can run your account. Plus, with the instruction provided, everything will be super easy.</span></p>
                  <div class="clear"></div>
                </div>
                <br />
                <br />
                <div class="centerimg1"> <img src="/theme/assets/ohn/images/andyoucanpost.jpg" alt="Image" /> </div>
                <p>If you want, there are many companies that allow you to post 
                  links offline, so you don't even need a computer! I demonstrated how 
                  it's done online simply because that's what most people choose to do 
                  these days, but you can post links offline too.</p>
                <p>Let me tell you something. Come a little closer. Posting links 
                  from home is so easy, and the benefits so incredible, I am sure you'll 
                  never want to do anything else ever again... but this. Just imagine</p>
                <div class="line27">
                  <div class="ponterbullet">
                    <ul>
                      <li><span class="hilight"><strong>You can work as little or as much as you want, anytime you want!</strong></span></li>
                      <li>Not having to go in for training! You can start almost immediately!</li>
                      <li>Seeing earnings rack up almost right way. Remember, most companies pay the very same week. The rest only take up to four!</li>
                      <li>Yourself enjoying financial freedom.</li>
                      <li>Yourself having extra time!</li>
                      <li><span class="hilight">Having the ability to buy what you want, take the vacations you want and more.</span></li>
                      <li>Not having to walk up to an alarm clock.</li>
                      <li>Working part time and earning more than you did at a full-time job!</li>
                      <li><span class="hilight">Working anywhere you want!</span></li>
                      <li>Not having to get dressed to go into work.</li>
                      <li>Saying goodbye to the daily commuter!</li>
                      <li>Not having to listen to a boss!</li>
                      <li>Actually earning the amount of money you want.</li>
                      <li><strong>Not having to deal with office politics or co-workers.</strong></li>
                      <li>Giving yourself a raise any time you want. Just post more links!</li>
                      <li><strong>Having an immediate position.</strong> The 
                        certification program guarantees this for you. It only takes a few 
                        minutes to get going with a company and you don't even have to talk to 
                        anyone to do so.</li>
                      <li>As soon as you sign up, you'll get a welcome letter and a link so you can get started.</li>
                      <li>The link will arrive within about five minutes. This means you can read it and get started right away. </li>
                    </ul>
                  </div>
                </div>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/youcanstart.jpg" alt="Image" /> </div>
                <p><span class="hilight">This certification program guarantees you immediate position of your choice as a Search Engine Agent.</span> It takes only a few minutes to sign up with the company you want and, 
                  you can do so online without EVER having to talk to anyone in the 
                  company! You can also have multiple placements with different companies 
                  if you choose.</p>
                <p>As soon as you sign up for our OHC University Program,
                  you're immediately emailed your Welcome Letter with the link to our 
                  OHC University.</p>
                <p>OHC University link will be emailed within five 
                  minutes of signing up to get you started immediately. It's very clear, 
                  easy-to-read, and walks you through everything in detail, step-by-step. 
                  You can read it in an afternoon and be on your way to success...</p>
                <p>But that's not all...</p>
                <div class="ponterbullet">
                  <ul>
                    <li>You'll get full access to the new and constantly updated OHC University Website.</li>
                    <li>You'll be able to see what companies pay the most and you'll stay up to date.</li>
                    <li>You'll get access to lots of insider tools to make link posting faster and easier.</li>
                    <li>You'll receive instant access to the knowledge you need to succeed.</li>
                    <li>And Finally... You'll be provided with all the resources you need you realize your goals.</li>
                  </ul>
                </div>
                <p>Plus, by signing up today, you'll get...</p>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/free-one-on-one-consultation-with-an-internet-expert.png" alt="Image" /> </div>
                <img class="float-left marginimgfl" src="/theme/assets/ohn/images/flright.jpg" alt="Image" />
                <p>I know the huge difference it makes to talk to a real live advisor. <span class="hilight"><strong>So I've put together a Highly-trained staff of success advisers to give you some guidance.</strong></span>.
                  You'll get a free one-on-one phone consultation with a Success Advisor
                  to discuss your individual goals and map out and ensure your quick path
                  to financial success.</p>
                <p>What's more, <strong>you'll get the email address to a success 
                  adviser who you can contact anytime you want with any questions, and 
                  you'll get a quick response back with whatever you need.</strong> This is one of the privilege you receive a member of this certification program.</p>
                <p>In fact, if you sign up today, I will also give you my personal
                  email address! That's right, my personal email address. So you can 
                  email me directly if you wish with any questions or comments. I know 
                  it's what I would want if I were you, and that's why I give it to you.</p>
                <p><span class="hilight">You see, this certification program is 
                  designed to provide you with your dream income from home and, you 
                  receive a lot of personal support to ensure your success.</span></p>
                <p>All this makes it a reality for people to transform their lives by posting links from home.</p>
                <p>That's why we receive so many remarkable testimonials, a sample
                  of which we've posted throughout this website to share with you. And 
                  that's why I'm 100% confident that by registering for this certification
                  program, you'll have a testimonial of your own to share as well.</p>
                <p>On top of that, it could not be any easier to get started right now because this whole program is backed up by a <strong>100%... 2-Month... You Succeed or it's FREE - Satisfaction Guarantee!</strong></p>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/2monthguarantee.jpg" alt="Image" /> </div>
                <p><strong>You are guaranteed immediate placement</strong> as a search engine agent by joining this certification program, or you'll get your money back! </p>
                <p>After you have signed up, take up to 2-Month to try working 
                  from home with this program. If you aren't making money and aren't 
                  satisfied, just ask for a full refund anytime within the 2-Month.  
                  You'll get your entire membership fee back immediately with no questions
                  and no hassles whatsoever. (You can ask for a full refund by phone or 
                  email, full contact details are below.)  In other words, you make money 
                  with this, or it's free.</p>
                <p>Plus, even if you ask for a refund, we want you to keep all the
                  special gifts you're going to receive as a member.  That means you have
                  nothing to lose! I know my program won't be for everybody, so if it's 
                  not for you, I understand and want you to accept these free gifts as a 
                  token of my appreciation for giving the program a try.</p>
                <p>I give you this guarantee because I know that by giving this an
                  honest try, you'll make all the money you desire, just like thousands 
                  of other people all over the world are doing.</p>
                <p>So, how much does it cost?  Let's first consider the value of all that you receive when you register for the <strong>Search Engine Agent Program...</strong></p>
                <div class="costingcont">
                  <div class="costing">
                    <ul>
                      <li>Guaranteed immediate placement! (Value: PRICELESS)...</li>
                      <li>Access to the OHC University with dozens of resources, and more added all the time (Value: $997)...</li>
                      <li>The official quick-start guide, "How To Make A Fortune posting links From Home" (Value: $97)...</li>
                      <li>Your free one-on-one consultation with a success advisor (Value: $149)...</li>
                      <li>Free phone and email customer support (Value: $497)...</li>
                      <li>And a lot more as described earlier (Value: Hundreds of dollars)...</li>
                    </ul>
                  </div>
                  <div class="clear"></div>
                </div>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/theimmediatevalue.jpg" alt="Image" /> </div>
                <p>But of course, that is NOT what it costs!</p>
                <p>With the assistance of a financial strategist, we have found a 
                  way of covering costs for support and constant updates and still bring 
                  the price down by over 90%... yours for $197.00.</p>
                <p>But, even though $197.00 is more than worth it compared to the 
                  value you receive, we realize that this amount is a lot of money for 
                  someone not yet working from home.  $197.00 is also a lot to spend on an
                  educational system.  So we wanted to make sure this opportunity was 
                  affordable to everyone who wanted to give it a try.</p>
                <p>After a few more financial consultations, we are pleased to 
                  tell you that we have been successful in finding a way to temporarily 
                  give an insider's deal that's just too good to pass up!</p>
                <p>You can register today for a membership in our educational program for:</p>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/a-special-one-time-investment-of-only-97.png" alt="Image" /> </div>
                <p>That's right, for only <span class="hilight"><strong>$97.00</strong></span>,
                  you will receive everything I mentioned!  If you Sign Up today, within 
                  the next few minutes you'll receive your link to the OHC University and full access to the student members area... unlimited personal 
                  support and all the other benefits and resources we have discussed.  
                  You'll have access in 5 minutes so you can start making money right 
                  away!</p>
                <p>And you can have your investment back in just One Day! By 
                  posting 15 links in 60 minutes, you can make $225. So, that means in 
                  your first 60 minutes you can make back your one-time investment of $97,
                  and already be $126 ahead!</p>
                <p>More so, by posting 15 links in 60 minutes a day...5 days a 
                  week...you can put $58,500 year-after-year into your bank account, so 
                  the financial value you're receiving is enormous! Think about it, you 
                  invest $97 once, and you receive back $58,500 over and over again!</p>
                <p>In addition, you are backed by our 100% rock solid 2-Month "Make Money Or It's Free" Triple Satisfaction Guarantee! <span class="hilight"><strong>This program makes you money or it's free</strong></span>. That's it PERIOD! So you have absolutely nothing to lose by trying it out...rather...you have absolutely everything to gain!</p>
                <p>All you have to do to get started is click the button below:</p>
                <div class="addtocart"> <a href="/billing"><img src="/theme/assets/ohn/images/getstarted-g.png" alt="Image" /></a> </div>
                <div class="centernote red">
                  <p>Please Be Advised: <br />
                    This Special Offer May Expire <br />
                    At Any Time</p>
                </div>
                <p>I mentioned before that I was able to make this incredible 
                  offer at this price only on a temporary basis.  This is because I'm 
                  trying to limit membership because I and my current staff can only 
                  handle so many students without driving our costs higher.  So, to keep 
                  providing our certification program, and to expand to handle more 
                  students, we will soon have to add an additional monthly fee of $29.00 
                  in addition to the $97.00 membership fee or we would have to raise the 
                  cost of the program to $500.</p>
                <p>But, if you sign up to become a member today, we will lock this
                  low entry price of $97.00 in for you and give full access with support 
                  for no additional costs... EVER! Even if the fee goes up and we go to a 
                  monthly fee, your one-time only investment right now gets you full 
                  certification and a membership with no ongoing or additional charges.</p>
                <div class="addtocart"> <a href="/billing"><img src="/theme/assets/ohn/images/getstarted-g.png" alt="Image" /></a> </div>
                <p>Also, my staff and I can only handle giving personal support to
                  115 new members at any given time in this program. That's why if you 
                  want to get in, I advise you to sign up now, today, before spots become 
                  unavailable again.</p>
                <p>To view our current availability, we have added a quick reference:</p>
                <div class="centerimg"> <img src="/theme/assets/ohn/images/animatedpositions.gif" alt="Image" /> </div>
                <p>Now, when all these spots are filled, this website will be shut down and instead you will see the following notice:</p>
                <p>"We're sorry, but we cannot accept any new members into our program at this time. Please check back in the future for openings."</p>
                <p>Don't let this happen to you.  Click below to sign up now before all the spots get filled:</p>
                <div class="addtocart"> <a href="/billing"><img src="/theme/assets/ohn/images/getstarted-g.png" alt="Image" /></a> </div>
                <p>The minute you click the button to join, you're taken to our 
                  Risk-Free Certification Enrollment Form which will give you access to a 
                  secure processing page where you can safely enter your contact and 
                  payment information without worry.  It's very quick and easy to 
                  complete.</p>
                <p>As soon as you complete that, you will be emailed your link to 
                  the Startup Freedom Center within minutes and all the other things we 
                  discussed so you can immediately login and start making money as soon as
                  possible.</p>
                <p>So don't delay.  So don't hesitate. Get started today posting 
                  links and making the money you desire from home right away! You'll be 
                  forever grateful you did. Click the button below to get started now:</p>
                <div class="addtocart"> <a href="/billing"><img src="/theme/assets/ohn/images/getstarted-g.png" alt="Image" /></a> </div>
                <p>To your financial success,</p>
                <p><img src="/theme/assets/ohn/images/michellesig.jpg" alt="Image" /></p>
                <div class="addtocart"> <a href="/billing"><img src="/theme/assets/ohn/images/getstarted-g.png" alt="Image" /></a> </div>
                <p><span class="red">P.S.</span> Remember Friend, with a <span class="hilight"><strong>2-Month "You Make Money or its Free" guarantee,</strong></span> there is nothing you can lose by trying this out... rather... you have only financial freedom from home to gain!</p>
                <p><span class="red">P.P.S.</span> Sign up (it's risk-free) now, today, before the price goes up or availability closes down.</p>
                <p><span class="red">P.P.P.S.</span> If you join today, you'll 
                  also immediately be sent a special free bonus gift that will open the 
                  doors for you to ten other remarkable ways of making money from home!  
                  Becoming financially independent could not be any easier and faster than
                  by having this "cash machine" in your hands as well.  This bonus gift 
                  itself is valued at $97, and it's yours today for FREE as a fast-action 
                  bonus!  Claim it while it's still available:</p>
              </div>
-->


              <div class="certEnrolForm">
                <div class="top"></div>
                <div class="body"> <img src="/theme/assets/ohn/images/certFormHeading.png" alt="Image" class="heading" />
                  
                  <!--<div class="text">
                    <p> I'm ready to check everything out with 
                      absolutely No Risk, thanks to the no questions asked money back 
                      guarantee. </p>
                    <p> I know there's no time to lose as spaces 
                      in my area are limited.  I really appreciate the 2-Month 'Make Money or 
                      its Free' guarantee - that allows me to see everything for free if I 
                      want, and I'm really excited! </p>
                  </div>
                  <img src="/theme/assets/ohn/images/wahu-p2.jpg" alt="Image" />
                  <div class="text">
                    <p>I can't wait to see my earnings starting to build up before my very eyes!</p>
                    <p>I want to get instant access to your 
                      certification program....start training with you today ... and get 
                      everything I need to succeed on a massive scale and potentially generate
                      HUGE profits...</p>
                    <p>On that basis, I'm taking a positive step 
                      towards my financial future with my one-time investment today of only 
                      $97.00.  Thank you for making this special reduced price available to me
                      today!</p>
                  </div>
                -->
                  <div class="addToCart">
                    <div class="top2"></div>
                    <div class="body2" style="height:150px;"> <a href="/billing"><img src="/theme/assets/ohn/images/getstarted-s.png" alt="Image" /></a>
                      <div class="linkToOrder"> <a href="/billing">Click Here To Order Online Using Our Secure Payment System</a> </div>
                      <img src="/theme/assets/ohn/images/payment.jpg" alt="Image" /> </div>
                    <div class="bot2"></div>
                  </div>
                  <div class="notice">
                    <p>INSTANT ACCESS<br />
                      Purchase with a Credit Card By Secure Server </p>
                    <p>THIS IS A SECURE TRANSACTION. YOUR DATA IS SAFELY ENCRYPTED AND IS SAFE FROM UNAUTHORIZED ACCESS.</p>
                  </div>
                </div>
                <div class="bot"></div>
              </div>
            </div>
            <div id="wahuclosingwrap"></div>
          </div>
          <div id="footer">
            <div class="paddside80">
              		<ul class="footermenu">
                    <!--
        <li><a href="/terms" class="jdialog" title="OHCU Disclaimer">DISCLAIMER</a></li>
        <li>|</li>
        <li><a href="/terms" class="jdialog" title="OHCU Terms">TERMS</a></li>
        <li>|</li>
        <li><a href="/refund" class="jdialog" title="OHCU Refund Policy">REFUND POLICY</a></li>
        <li>|</li>
        <li><a href="/privacy" class="jdialog" title="OHCU Privacy Policy">PRIVACY</a></li>
        <li>|</li>
        <li><a href="/" target="login">MEMBERS LOGIN</a></li>
        <li>|</li>
        <li><a href="/contact" class="jdialog" title="OHCU Contact Info">CONTACT</a></li>
		
-->
    </ul>              <div class="line"></div>
              <p></p>
              <center>
                <strong>IMPORTANT NOTICE!</strong>
              </center>
              <p></p>
              <p>Stock and option trading has large potential rewards, but also large potential risks.  You must be aware of the risks and willing to accept them in order to invest in the futures equity or options markets.  Don’t trade with money you can’t afford to lose.  This is neither a solicitation nor an offer to buy/sell securities, or listed options.</p>
              <div class="line"></div>
            </div>
          </div>
        </div>
<div id="dialog" style="display: none;"></div>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js" type="text/javascript"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js" type="text/javascript"></script>
<script type="text/javascript" >
	$(".jdialog").click(function() {
		var myUrl = $(this).attr("href");
		var myTitle = $(this).attr("title");
		$("#dialog").load(myUrl).dialog({
             draggable: true,
			 position: "top",
			 width:'70%',
             title: myTitle,
			 modal:true
		}); 
		return false;
	});	function populateCalculatorResults()
	{
		var postAday = $('#postAday').val();
		var avEarnPerLink = $('#avEarnPerLink').val().replace('$','');
		var daysOfWork = $('#daysOfWork').val(); //a week
		var dailyIncome = postAday * avEarnPerLink;
		var weeklyIncome = dailyIncome * daysOfWork;
		var monthlyIncome = weeklyIncome * 4;
		var yearlyIncome = weeklyIncome * 52;
		$('span#dailyIncome').html('$'+dailyIncome+'.00');
		$('span#weeklyIncome').html('$'+weeklyIncome+'.00');
		$('span#monthlyIncome').html('$'+monthlyIncome+'.00');
		$('span#yearlyIncome').html('$'+yearlyIncome+'.00');
	}
	
	//initialize the results
	populateCalculatorResults();

	//recompute when button was clicked
	$('#calculate').click(function(){
		populateCalculatorResults();
	})
</script>
</body>
</html>


<?php
// include footer
//$theme->load('footer');
