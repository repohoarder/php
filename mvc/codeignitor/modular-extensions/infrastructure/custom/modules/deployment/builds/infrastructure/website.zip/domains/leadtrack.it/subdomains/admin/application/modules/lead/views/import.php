

<div class="panel-wrapper fixed"> 

	<div class="panel ">  

		<div class="title"> 

			<h4>Import Leads</h4> 

			<div class="collapse">collapse</div> 

		</div>  

		<div class="content"> <!-- ## Panel Content  -->  

			<form method="post" action="">

				<div class="group fixed"> 
					<label>Import Lead CSV</label> 
					<input type="file" value="" name="leads" /> <br><br>
				<!--<p class="note">NOTE: Importing leads will count against your monthly usage.</p>-->
				</div>  

				<a href="#" class="button-blue">Import Leads <!-- <img src="http://quickadmin.weblumps.com/weblumps/quickadmin/images/icon-star-white.png" alt=""> --></a>

			</form>  <!-- ## / Panel Content  --> 

		</div> 

	</div>  

	<div class="shadow"></div> 
</div>