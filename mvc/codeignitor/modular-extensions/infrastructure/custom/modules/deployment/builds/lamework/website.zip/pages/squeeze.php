<?php

// initialize classes needed for this page
global  $amazon,
		$database,
		$infusionsoft,
		$params,
		$session,
		$theme;

// initialize variables
$email 		= (isset($params[0]))? $params[0]: '';
$error 		= (isset($params[1]))? $params[1]: FALSE;
$submitted 	= (isset($_REQUEST['submit']))? TRUE: FALSE;

// if data was submitted
if ($submitted):

	// initialize variables
	$name 		= @$_REQUEST['name'];
	$first 		= @$_REQUEST['first'];
	$last 		= @$_REQUEST['last'];
	$phone 		= @$_REQUEST['phone'];
	$email 		= $_REQUEST['email'];
	$ip 		= $session->get('ip');

	// validation

	// create INSERT array
	$insert 	= array(
		'visitor_id'	=> $session->get('visitor_id'),
		'name'			=> $name,
		'first'			=> $first,
		'last'			=> $last,
		'phone'			=> $phone,
		'email' 		=> $email,
		'ip'			=> $ip
	);

	// add data to partials
	$id 		= $database->insert('partials',$insert);

	// add data to Infusionsoft
	$cid 		= $infusionsoft->contact($email,array('FirstName' => $first));

	// create session array
	$sessions 	= array(
		'partial_id'	=> $id,
		'name'			=> $name,
		'first'			=> $first,
		'last'			=> $last,
		'email'			=> $email,
		'infusionsoft'	=> array(
			'cid' 		=> $cid,
			'email' 	=> $email
		)
	);

	// set needed sessions
	$session->set($sessions);

	// send email of new lead to product owner: ike@epicmediasolutions.net

	// redirect
	//_header_redirect('http://www.tradewins.com/Promo%20Emails/WCA%20Affiliate%20Series/FreeReportThankYou.html');	
	_header_redirect('/searching');
	
endif;

// include header
//$theme->load('header');
?>


<!--
						<form class="apply-form form-group" action="<?php echo '/'.$page; ?>" method="POST">
                        	<input name="name" type="text" class="inputbg"  onfocus="if (this.value == 'Your Name') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Your Name';}" value="Your Name" />
                        	<input name="email" type="text" class="inputbg"  onfocus="if (this.value == 'Your Email') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Your Email';}" value="Your Email" />
                        	<input type="submit" class="submit" name="submit"  value="Download now!" />
                        </form>
-->


<!doctype html>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="description" content="Online Home Careers University You Can Start Earning Real Money From Home Today. Visit OHCUniversity.com">
<meta name="keywords" content="Online Home Careers University">
<title>Online Home Careers University - OHCUniversity.com</title>
<link rel="stylesheet" href="/theme/assets/ohn/files/main.css">
<link href="/theme/assets/ohn/js/css/ui-lightness/jquery-ui-1.10.3.custom.min.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="/theme/assets/ohn/files/jscripts-lib.js"></script>
<script type="text/javascript" src="/theme/assets/ohn/files/exitpop.js"></script>
<script type="text/javascript" >
			var param = "vid=3699011";
			var internalLink = false;
			var eurl = "/searching"
			var vmsg = '************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n\n Wait... Before You Go:\n\n\n We want to offer you a special discount that is normally restricted to only friends and family.\n\n\n You can SAVE BIG by clicking the cancel button below.\n\n\n You will get my entire system for only $97.00. That is $100 OFF the normal price of $197.00.\n\n\n To take advantage of this special offer and get INSTANT ACCESS, click on the CANCEL button below.\n\n ************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n';
			var userAgent = navigator.userAgent.toLowerCase();
			if(userAgent.search('firefox') != -1)
			{
				window.onbeforeunload = pageUnload;
			} else if (userAgent.search('safari') != -1)
			{
				window.onbeforeunload = function (ev) {
				    var e = ev || window.event;
				    window.focus();
				    if (!internalLink){
				      internalLink = true;
				      var showstr = '************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n\n Wait... Before You Go:\n\n\n We want to offer you a special discount that is normally restricted to only friends and family.\n\n\n You can SAVE BIG by clicking the cancel button below.\n\n\n You will get my entire system for only $97.00. That is $100 OFF the normal price of $197.00.\n\n\n To take advantage of this special offer and get INSTANT ACCESS, click on the CANCEL button below.\n\n ************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n';
				      
				      return showstr; //for safari and chrome
				    }
				};
				
				window.onfocus = function (ev){
				    if (internalLink){
				      window.location.href = "/searching";
				    }
				}
				
			} else { /** ie or chrome **/
				window.onbeforeunload = areYouSure;
			}
			
			function pageUnload() 
			{
				if (!internalLink){
					internalLink = true;
					alert('************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n\n Wait... Before You Go:\n\n\n We want to offer you a special discount that is normally restricted to only friends and family.\n\n\n You can SAVE BIG by clicking the cancel button below.\n\n\n You will get my entire system for only $97.00. That is $100 OFF the normal price of $197.00.\n\n\n To take advantage of this special offer and get INSTANT ACCESS, click on the CANCEL button below.\n\n ************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n');
					location.href= "/searching";
					return '************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n\n Wait... Before You Go:\n\n\n We want to offer you a special discount that is normally restricted to only friends and family.\n\n\n You can SAVE BIG by clicking the cancel button below.\n\n\n You will get my entire system for only $97.00. That is $100 OFF the normal price of $197.00.\n\n\n To take advantage of this special offer and get INSTANT ACCESS, click on the CANCEL button below.\n\n ************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n';
				}
			}

			var dep = false;
			
	$(document).ready(function() {
		$('a').bind('click', function(event) {
			internalLink = true;
		});
	});
	</script>
<style type="text/css">
.auto-style1 {
	margin-top: 0px;
}
.lktop {
	color: #605f5f;
	text-decoration: none;
	font-weight: bold;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	text-transform: uppercase;
	padding-left: 20px;
	padding-right: 20px;
	font-size: 12px;
	line-height: 30px;
}
.mlktop {
	background: url("/theme/assets/ohn/images/bg-link.jpg") no-repeat scroll top left transparent;
}
.cliktop {
	background: url("/theme/assets/ohn/images/bg-link.jpg") no-repeat scroll bottom left transparent;
}
</style>
</head>
<body>
<div id="main">
  <div id="wahuheader"> <!--<img src="/theme/assets/ohn/images/tvlogos.jpg" style="padding-top: 118px; padding-left: 345px;" alt="Loading...">--> </div>
  <div id="content">
    <div class="fr" style="padding-right: 10px;">  </div>
    <div class="clear"></div>
    <div id="maincontent">
      <p style="font-family:Arial, Helvetica, sans-serif; font-size:16px; text-align:center" class="auto-style1"> <strong>Immediate Release on Monday, April 21, 2014</strong><br>
      </p>
      <div class="aligncenter redheadingmain"> 
        <!--
						<img src="https://d28w3k25s5vkfe.cloudfront.net/sahr-images/homemain.jpg" />
						--> 
        <!-- <img src="/theme/assets/ohn/images/homemaink.jpg" alt="Loading...">-->

        <h1 style="color:red;font-weight:bold;">In The Next 90 Seconds - Gain Access To A System That Is Responsible For Generating $4.4 Million in Actual Profits Over The Past 4 Years</h1>

         </div>

<center><p>Click below to gain access to trade records and tax returns that PROVE how effective this system is.</p></center>

      <ul class="check" style="font-family:Arial, Helvetica, sans-serif; font-size:16px;">
        <li><strong>Advisory Service 12 Year Profit Record</strong></li>
        <li><strong>$1,023,174 in Actual Profits in 26 Days</strong></li>
        <li><strong>$5.7 Million in Actual Income Over Past 3 Years</strong></li>
        <li><strong>Dan's Tax Returns with $1.5 Million in Profits Following This System</strong></li>
      </ul>
      
      <!--OptInForm-->
      <form class="apply-form form-group register" action="<?php echo '/'.$page; ?>" method="POST">
        
        <!--<form onsubmit="return validatefrm(this); " action="index.php" method="post" class="register" name="checkavailfrm">-->
        
        <div class="reghead">
          <div class="regheadtxt"></div>
        </div>
        <div class="centertxtbox">
                  <input name="first" id="first" type="text" value="Your First Name" placeholder="Your First Name" title="First Name" class="textbox" style="width:154px;">          <input name="last" id="last" type="text" value="Your Last Name" placeholder="Your Last Name" title="Last Name" class="textbox" style="width:154px;">          <input title="Phone Number" class="textbox" name="phone" value="Your Phone Number" placeholder="Your Phone Number" type="text" style="width:154px;">                    <input title="Email" class="textbox" name="email" id="email" type="text" value="Primary Email" placeholder="Primary Email" style="width:154px;">        </div>
        <div class="buttonbox">
          <input name="submit" class="submit" value="" onclick="internalLink = true;" type="submit">
        </div>
      </form>
    </div>
    
    <div style="text-align:center;margin-bottom:15px;;">
<a href="925052223.html#" onClick="window.open('http://www.security-guaranteed.com/verify/ohcuniversity/com','mywindow','menubar=1,resizable=1,width=530px,height=800px'); return false">
<img src="/theme/assets/ohn/badge/ecommerce" alt="Security Guaranteed" /></a>

<a href="925052223.html#" onClick="window.open('http://www.security-guaranteed.com/verify/ohcuniversity/com','mywindow','menubar=1,resizable=1,width=530px,height=800px'); return false">
<img src="/theme/assets/ohn/badge/business" alt="Security Guaranteed" /></a>

    <a href="925052223.html#" onClick="window.open('http://www.security-guaranteed.com/verify/ohcuniversity/com','mywindow','menubar=1,resizable=1,width=530px,height=800px'); return false">
<img src="/theme/assets/ohn/badge/security" alt="Security Guaranteed" /></a>

<a href="925052223.html#" onClick="window.open('http://www.security-guaranteed.com/verify/ohcuniversity/com','mywindow','menubar=1,resizable=1,width=530px,height=800px'); return false">
<img src="/theme/assets/ohn/badge/privacy" alt="Security Guaranteed" /></a> 


</div>


    <div id="wahuclosingwrap"></div>
  </div>
  <div id="footer">
    <div class="paddside80">
      		<ul class="footermenu">
      			<!--
        <li><a href="/theme/assets/ohn/ohcu-disclaimer.html" class="jdialog" title="OHCU Disclaimer">DISCLAIMER</a></li>
        <li>|</li>
        <li><a href="/theme/assets/ohn/ohcu-terms.html" class="jdialog" title="OHCU Terms">TERMS</a></li>
        <li>|</li>
        <li><a href="/theme/assets/ohn/ohcu-refund-policy.html" class="jdialog" title="OHCU Refund Policy">REFUND POLICY</a></li>
        <li>|</li>
        <li><a href="/theme/assets/ohn/ohcu-privacy.html" class="jdialog" title="OHCU Privacy Policy">PRIVACY</a></li>
        <li>|</li>
        <li><a href="/theme/assets/ohn/../index.php/login.html" target="login">MEMBERS LOGIN</a></li>
        <li>|</li>
        <li><a href="/theme/assets/ohn/ohcu-contact.html" class="jdialog" title="OHCU Contact Info">CONTACT</a></li>
		-->
		</ul>    

<div class="line"></div>
              <p></p>
              <center>
                <strong>IMPORTANT NOTICE</strong>
              </center>
              <p></p>
              <p>Stock and option trading has large potential rewards, but also large potential risks.  You must be aware of the risks and willing to accept them in order to invest in the futures equity or options markets.  Don’t trade with money you can’t afford to lose.  This is neither a solicitation nor an offer to buy/sell securities, or listed options.</p>
              <div class="line"></div>
            </div>

  </div>
</div>
<div id="dialog" style="display: none;"></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>

<script type="text/javascript" >
	$('.textbox').each(function() {
		var default_value = this.value;
		$(this).focus(function() {
			if(this.value == default_value) {
				this.value = '';
			}
		});
	
		$(this).blur(function() {
			if(this.value == '' || this.value=='') {
					this.value = default_value;
				}
			});
	});
	
	$(".jdialog").click(function() {
		var myUrl = $(this).attr("href");
		var myTitle = $(this).attr("title");
		$("#dialog").load(myUrl).dialog({
             draggable: true,
			 position: "top",
			 width:'70%',
             title: myTitle,
			 modal:true
		}); 
		return false;
	});	
	</script>
</body>
</html>


<?php
// include footer
//$theme->load('footer');



