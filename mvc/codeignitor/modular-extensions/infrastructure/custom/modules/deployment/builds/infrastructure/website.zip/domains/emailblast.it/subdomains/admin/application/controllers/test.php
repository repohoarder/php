<?php 
class Test extends CI_Controller
{
	function index()
	{
		echo 'test';//$this->api->error_code($this, __DIR__,__LINE__);
	}
}
?>