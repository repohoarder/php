<?php

// initialize variables
$submitted    = (isset($_REQUEST['charge']))? TRUE: FALSE;

// if we need to charge this upsell
if ($submitted):

  // initialize variables
  $dropoff_id   = $session->get('dropoff_id');
  $product_id   = 3;//$_REQUEST['product_id'];

  // create insert array for dropoffs_products
  $insert   = array(
    'dropoff_id'  => $dropoff_id,
    'product_id'  => $product_id
  );

  // add product to dropoffs_products
  $database->insert('dropoffs_products',$insert);

  // add product to session

  // redirect ot processing
  _redirect('processing');

endif;

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Chuck Hughes | Wealth Creation Alliance</title>
<style type="text/css">
<!--
body {
	background-color: #DBEEF7;
}
.style1 {
	font-family: Georgia, "Times New Roman", Times, serif;
	font-weight: bold;
	color: #000099;
	font-size: 24px;
}
.style2 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 9px;
}
.style3 {font-size: 12px}
.style4 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	color: #C41010;
}
.style5 {
	color: #C71A1A;
	font-weight: bold;
	font-size: 24px;
}
-->
</style></head>

<body>
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><div align="center"><a href="/processing"><img src="/theme/assets/images/Page5Banner.png" alt="Trade Recommendations" width="1012" height="170" border="0" /></a></div></td>
  </tr>
</table>
<table width="1000" height="308" border="3" align="center" cellpadding="15" cellspacing="0" bordercolor="#FFFFFF" bgcolor="#000066">
  <tr>
    <td valign="top" bordercolor="#000099" bgcolor="#FFFFFF"><p align="center"><object classid="clsid:D27CDB6E-AE6D-11CF-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=9,0,115,0" id="i_828b2ce3774649de83d342de707907e7" width="776" height="524"><param name="movie" value="http://applications.fliqz.com/20eb8a0b674a4dda842f8113534277fa.swf"/><param name="allowfullscreen" value="true" /><param name="menu" value="false" /><param name="bgcolor" value="#FFFFFF"/><param name="allowscriptaccess" value="always"/><param name="flashvars" value="at=c8f252af60b44fe0906109afc249465f&autoPlayback=true"/><embed name="i_a036e283dee6435884c1b762cb33cfb7" src="http://applications.fliqz.com/20eb8a0b674a4dda842f8113534277fa.swf" flashvars="at=c8f252af60b44fe0906109afc249465f&autoPlayback=true" width="776" height="524" pluginspage="http://www.macromedia.com/go/getflashplayer" allowfullscreen="true" menu="false" bgcolor="#FFFFFF" allowscriptaccess="always" type="application/x-shockwave-flash"/></object>&nbsp;</p>
    <p align="center" class="style4"><span class="style5"><br />
        Webinar  attendees will receive a 33% discount<br />
        AND <br />
        FREE Welcome  Gift, which sells for $1,995… <br />
        And it’s  yours to keep even if you ask for a refund!<br />
        Click the  ‘Join Now’ button to learn more.</span></p>
    <p align="center"><a href="/discount/?charge"><img src="/theme/assets/images/JoinNow.png" alt="Join Now!" width="651" height="98" border="0" /></a></p>
    <p align="center">&nbsp;</p>
    <p align="center" class="style1"><a href="https://tradewinspublish.infusionsoft.com/saleform/nathnis">Read What Members Are Saying</a></p>
    <p class="style2">Option and stock investing involves risk and is not suitable for all investors. Only invest money you can afford to lose in stocks and options. Past performance does not guarantee future results. The trade entry and exit prices represent the price of the security at the time the recommendation was made. The record does not represent actual investment results. Trade examples are simulated and have certain limitations. Simulated results do not represent actual trading. Since the trades have not been executed, the results may have under or over compensated for the impact, if any, of certain market factors such as lack of liquidity. No representation is being made that any account will or is likely to achieve profit or losses similar to those shown.</p>
    <p class="style2">NOTICE: This testimonial was provided by subscribers to Chuck's  various products without compensation. Chuck Hughes believes they are true  based on the representations of the subscribers but has not independently  verified them, nor have photos been authenticated, nor has any attempt been  made to determine the experience of the individuals after the testimonials were  given. They may have been given in reference to one of Chuck's products or  services - not necessarily Wealth Creation Alliance. Past results are not necessarily  indicative of future results. People can and do lose money trading options.</p>    
    </td>
  </tr>
</table>
<p>&nbsp;</p>
<!-- Start of ExitSplash.com Code -->
<script language="javascript">
var exitsplashmessage = '***************************************\n\n W A I T   B E F O R E   Y O U   G O !\n\n  CLICK THE *CANCEL* BUTTON RIGHT NOW\n TO VIEW MORE ABOUT THIS AMAZING OFFER.\n\n I HAVE SOMETHING VERY SPECIAL FOR YOU!\n\n***************************************';
var exitsplashpage = '/processing';
</script>
<script language="javascript" src="http://www.tradewins.com/exitsplash.php?tc=3399cc&uh=none&ad=none&sh=no&hv=no&bh=22&fs=12&lf=Arial&at=Powered%20by%20ExitSplash"></script>
<!-- End of ExitSplash.com Code -->
</body>
</html>
