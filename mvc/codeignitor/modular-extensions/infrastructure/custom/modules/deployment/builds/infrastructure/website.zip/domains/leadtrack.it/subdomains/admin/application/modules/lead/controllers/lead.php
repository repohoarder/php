<?php

class Lead extends MX_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		redirect('lead/import');
	}

	public function import()
	{
		$data 	= array();

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: Lead Import');
		// load view
		$this->template->build('lead/import', $data);
	}

	public function export($campaign='all')
	{
		$data 	= array();

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: Lead Export');

		// set data variables
		$data['leads']		= array(array('id' => 1, 'domain' => 'http://l1nk.it/alias', 'url' => 'http://www.google.com', 'active' => TRUE), array('id' => 5, 'domain' => 'http://l1nk.it/v5Hyz', 'url' => 'http://www.brainhost.com', 'active' => FALSE));
		$data['campaign']	= $campaign;

		// load view
		$this->template->build('lead/export', $data);
	}

}