<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('WP_CACHE', true); //Added by WP-Cache Manager
define('DB_NAME', 'rncolumb_wpb');

/** MySQL database username */
define('DB_USER', 'rncolumb_wpb');

/** MySQL database password */
define('DB_PASSWORD', 'dWhvQ3VvVX');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '>6O.3=5BS7IB%9-t^WMYH]e-m2_*b{Kcm:v(-&^Bg|2MO5I;u&bOhUO}<p9#eybc');
define('SECURE_AUTH_KEY',  'rz(VL=te- X3h!&g#- RFL~0Hb6]-Cd&SG|T>!)%#tfhvPJ.$_[_ABP%L4ZM#KUv');
define('LOGGED_IN_KEY',    '_E wEZ:d{z+Yv{i39y$7Dsns|[]|uV(Ab7Olar~50h^%cj(in+;&eFiFAe<2Ho[R');
define('NONCE_KEY',        'g!rZ,|YkgW#xeyP=jIB9BWP<>AAQRzV^|A>L)y<$Q#JCoHe%MmEOSpI[+JFM(/6i');
define('AUTH_SALT',        'CaDV%zq!rVxkmF!<TzKa+&+r;U`OntN^m(`~qI*Sdj>gI;aCN]`<lJGkj:+zK*R|');
define('SECURE_AUTH_SALT', '(=GHEyIp?KxF)Ja|L6;8!&|B;}D>kT 6f5,MCd?m{OF-oR]5-%&:xY#]!C+9+ra;');
define('LOGGED_IN_SALT',   'd Yk04:||#Oe#?Kq[)7S&v`CmvL3#q7ki9(qsT,<L-%|:>Mm!g!w,iu)9Nh:p{g ');
define('NONCE_SALT',       '|GMU<5`P.XhT@/APs+ )-dFq`i1=4v$yi&AGJD5mtw0L^&P>Jy>^8cg{.0+[X#L7');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress.  A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de.mo to wp-content/languages and set WPLANG to 'de' to enable German
 * language support.
 */
define ('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
