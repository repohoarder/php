<?php

class Clicks extends MX_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$data 	= array();

        $this->template->set_theme('quick_admin');

		// set template layout to use
		$this->template->set_layout('default');

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: Link Clicks');

		// load view
		$this->template->build('statistics/clicks', $data);
	}

}