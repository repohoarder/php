<?php

$route['integration/(:any)']	= 'integration/index/$1';