<?php

class Tracking
{
	public function __construct()
	{

	}

	public function visitor()
	{
		global 	$session,
				$database;

		// if no visitor_id is set, then we need to also add a new visitor		
		$insert 	= array(
			'session_id'		=> $session->get('session_id'),
			'browser' 			=> 'Google',
			'browser_version' 	=> '3.0',
			'operating_system' 	=> 'Windows',
			'ip'				=> $session->get('ip')
		);

		// insert into database
		$id = $database->insert('visitors',$insert);

		// add visitor_id to session
		$session->set(array('visitor_id' => $id));

		return $id;
	}

	public function hit($page,$params=array())
	{
		global 	$session,
				$database;

		// initialize variables
		$visitor_id 	= $session->get('visitor_id');

		// if no visitor_id is set, then we need to also add a new visitor
		if ( ! $visitor_id)
			$visitor_id 	= $this->visitor();

		$insert 		= array(
			'visitor_id'		=> $visitor_id,
			'title'				=> '',
			'url'				=> $session->get('HTTP_HOST').$session->get('REQUEST_URI'),
			'page'				=> $page,
			'params'			=> json_encode($params)			
		);

		$id = $database->insert('visitors_hits',$insert);

		// return visitor hit id
		return 	$id;
	}
}