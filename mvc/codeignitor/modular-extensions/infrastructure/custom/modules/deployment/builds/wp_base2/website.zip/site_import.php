<?php
ini_set('memory_limit', '600M');
ini_set('set_time_limit', 6000);
ini_set('max_execution_time', 5000);

// Example usage:
// http://domain.com/site_import.php
// 	?category=footwear
// 	&site_title=Super%20Cool%20Website
// 	&site_tagline=This%20is%20a%20site%20slogan

$docroot     = $_SERVER['DOCUMENT_ROOT'];
$httphost    = $_SERVER['HTTP_HOST'];

$uploads_dir = $docroot . '/wp-content/uploads';

$header_dir  = $uploads_dir . '/2012/08';
$header_file = 'textimage.png';

$api_url     = 'http://setup.brainhost.com/site_content';

require_once($docroot . '/wp-blog-header.php');
require_once($docroot . '/wp-admin/includes/image.php');

class Curler {

	public function post($url = FALSE, $post = array())
	{
		// error handling
		if ( ! $url)
			throw new Exception('Valid URL not supplied.');
		
		// generate query string from post_data
		$query_string = http_build_query($post);
		
		// initialize curl
		$ch = curl_init();
		
		// set parameters
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0); 
		curl_setopt($ch, CURLOPT_TIMEOUT, 1000); //timeout in seconds		

		// run cUrl
		$response	= curl_exec ($ch);

		curl_close($ch);

		// return the response
		return $response;
	}	

	public function get($url = FALSE, $get = '')
	{
		// error handling
		if ( ! $url)
			throw new Exception('Valid URL not supplied.');
		
		// initialize curl
		$ch = curl_init();

		if (is_array($get)):

			$get = http_build_query($get);

		endif;

		// set cUrl url
		curl_setopt($ch, CURLOPT_URL, $url.'?'.$get);

		// set parameters
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

		// run cUrl
		$response = curl_exec($ch);

		curl_close($ch);

		// return the response
		return $response;
	}

}

class Autobuilder {

	function insert_cat($cat, $cat_ids = array())
	{

		$parent = ($cat['parent'] && array_key_exists($cat['parent'], $cat_ids)) ? $cat_ids[$cat['parent']] : '';

		$exists = get_category_by_slug($cat['slug']);

		if ($exists):

			return $exists->term_id;

		endif; 


		$cat_array = array(
			'description' => $cat['title'], 
			'slug'        => $cat['slug'],
			'parent'      => $parent
		);

		$term = wp_insert_term($cat['title'], 'category', $cat_array);

		if ( ! isset($term['term_id'])):

			return FALSE;

		endif;

		return $term['term_id'];

	}

	function create_post_excerpt($string, $max_words = 55, $ellipsis = '...')
	{

		$words = explode(' ', $string);

		if (count($words) <= $max_words):
			
			return $string;

		endif;

		return implode(' ', array_slice($words, 0, $max_words)) . $ellipsis;
	}

}


#######################################
// begin script
#######################################

if (isset($_REQUEST['category']) && $_REQUEST['category']):

	// hit API to get content for given category
	$url    = $api_url.'/get';
	$params = array(
		'category'     => $_REQUEST['category'],
		'site_title'   => stripslashes($_REQUEST['site_title']),
		'site_tagline' => stripslashes($_REQUEST['site_tagline'])
	);

	$resp    = Curler::post($url, $params);
	$decoded = json_decode($resp, TRUE);

	if (is_null($decoded)):

		$response = array(
			'success' => 0,
			'error'   => array('Unable to decode response'),
			'data'    => array(
				'resp' => $resp
			)
		);

		echo json_encode($response);
		exit();

	endif;

	$resp = $decoded;
	unset($decoded);

	if ( ! $resp['success']):

		echo json_encode($resp);
		exit();

	endif;



	// API success! need to do stuff with cats, articles, and other data now
	$categories   = $resp['data']['categories'];
	$articles     = $resp['data']['articles'];
	$header       = $resp['data']['header'];
	$site_title   = $resp['data']['site_title'];
	$site_tagline = $resp['data']['site_tagline'];

	unset($resp);

	// set site title to the domain if not provided
	if ( ! $site_title):

		$site_title = ucwords($httphost);

		if(substr($site_title, 0, 4) == 'www.'):

			$site_title = strtolower(substr($site_title, 4));

		endif;

	endif;



	// overwrite below; $response will be output as json at end of script
	$response   = array(
		'success' => 1,
		'error'   => array(),
		'data'    => array()
	);

	$cur_title = get_option('blogname');

	if ($cur_title !== $site_title && ($cur_title || $site_title)):

		// update site title
		$updated = update_option('blogname', $site_title);

		if ( ! $updated):

			$response['success'] = 0;
			$response['error'][] = 'Unable to update site title';

		endif;

	endif;

	$cur_tagline = get_option('blogdescription');

	if ($cur_tagline !== $site_tagline && ($cur_tagline || $site_tagline)):

		// update website tagline (slogan)
		$updated = update_option('blogdescription', $site_tagline);

		if ( ! $updated):

			$response['success'] = 0;
			$response['error'][] = 'Unable to update site tagline';

		endif;

	endif;

	// copy headline to specific file location -- held over from old script
	if ($header):

		$has_dir = TRUE;

		if ( ! is_dir($header_dir)):

			$has_dir = mkdir($header_dir, 0777, TRUE); // make directories recursively

		endif;

		if ( ! $has_dir):

			$response['success'] = 0;
			$response['error'][] = 'Unable to create header directory';

		else:

			$copied = @copy($header, $header_dir . '/' . $header_file); // guess path is hardcoded?
			
			if ( ! $copied):

				$response['success'] = 0;
				$response['error'][] = 'Unable to copy header file';

			endif;

		endif;

	endif;


	// CATEGORIES
	$cat_ids   = array();
	$cat_names = array();

	// loop parent cats and insert, skip children
	foreach ($categories as $key => $cat):

		// category has a parent - skip until all parents have been added
		if ($cat['parent']):

			continue;

		endif;

		unset($categories[$key]);

		$term_id = Autobuilder::insert_cat($cat, $cat_ids);

		if ( ! $term_id):

			$response['success'] = 0;
			$response['error'][] = 'Unable to insert category: '.$cat['slug'];

			continue;

		endif;

		$cat_ids[$cat['slug']]   = $term_id;
		$cat_names[$cat['slug']] = $cat['cat_name'];

	endforeach;

	// loop remaining children, add with parent IDs from above loop
	foreach ($categories as $key => $cat):

		unset($categories[$key]);

		$term_id = Autobuilder::insert_cat($cat, $cat_ids);

		if ( ! $term_id):

			$response['success'] = 0;
			$response['error'][] = 'Unable to insert child category: '.$cat['slug'];

			continue;

		endif;

		$cat_ids[$cat['slug']] = $term_id;

	endforeach;

	unset($categories);



	// ARTICLES
	$posts_info = array();

	// loop articles and insert as posts
	foreach ($articles as $akey => $article):

		unset($articles[$akey]);

		$clean_post = trim(strip_tags($article['content'], '<br><b><p><i><em><u><strong>')); // remove formatting

		$excerpt    = trim(strip_tags($clean_post));
		$excerpt    = Autobuilder::create_post_excerpt($clean_post, 180);

		$cat_slug   = ($article['child_cat_slug']) ? $article['child_cat_slug'] : $article['cat_slug'];
		$cat_id     = $cat_ids[$cat_slug];		

		$post_array = array(
			'post_title'    => $article['title'],
			'post_name'     => $article['slug'], 
			'post_content'  => $clean_post,
			'post_exceprt'  => $excerpt, 
			'tags_input'    => $article['keywords'], 
			'post_category' => array($cat_id), 
			'post_date'     => date('Y-m-d H:i:s', strtotime('- '.rand(0, 345600).' seconds')),
			'post_status'   => 'publish',
			'post_author'   => 1,
			'post_type'     => 'post',
			'ping_status'   => get_option('default_ping_status'),
		);	

		$post_id = wp_insert_post($post_array);

		if(is_wp_error($post_id)):

			$response['success'] = 0;
			$response['error'][] = $post_id->get_error_message();

			continue;

		endif;

		$posts_info[$article['slug']]['id'] = $post_id;

		// loop post images and insert
		foreach ($article['images'] as $img_cat => $images):

			foreach ($images['img_types'] as $itkey => $img_type):

				$is_featured = $img_type['featured'];
				$is_wide     = $img_type['wide'];
				$is_thumb    = $img_type['thumb'];

				// begin shuffling the imgs 
				$keys = array_keys($img_type['imgs']);
				shuffle($keys);

				$new_arr = array();

				foreach ($keys as $new_key):

					$new_arr[$new_key] = $img_type['imgs'][$new_key];

				endforeach;

				$img_type['imgs'] = $new_arr;

				unset($new_arr);
				unset($keys);
				// end shuffling images

				foreach ($img_type['imgs'] as $ifkey => $img_file):

					$prefix    = 'f_'; // previously only if ($is_featured), but all images featured now

					$img_fpath = $prefix . $akey . basename($img_file);
					$copied    = @copy($img_file, $uploads_dir . '/' . $img_fpath); // guess path is hardcoded?
		
					if ( ! $copied):

						$response['success'] = 0;
						$response['error'][] = 'Unable to copy image: '.$img_file;

						continue;

					endif;

					## Lifted from http://codex.wordpress.org/Function_Reference/wp_insert_attachment
					// $filename should be the path to a file in the upload directory.
					$filename        = $uploads_dir . '/' . $img_fpath;

					// The ID of the post this attachment is for.
					$parent_post_id  = $post_id;

					// Check the type of tile. We'll use this as the 'post_mime_type'.
					$filetype        = wp_check_filetype(basename($filename), NULL);

					// Get the path to the upload directory.
					$wp_upload_dir   = wp_upload_dir();

					// Prepare an array of post data for the attachment.
					$attachment      = array(
						'guid'           => $wp_upload_dir['url'] . '/' . basename($filename), 
						'post_mime_type' => $filetype['type'],
						'post_title'     => preg_replace( '/\.[^.]+$/', '', basename($filename)),
						'post_content'   => '',
						'post_status'    => 'inherit'
					);

					// Insert the attachment.
					$attach_id       = wp_insert_attachment($attachment, $filename, $parent_post_id);

					if(is_wp_error($attach_id)):

						$response['success'] = 0;
						$response['error'][] = $attach_id->get_error_message();

						continue;

					endif;

					// Generate the metadata for the attachment, and update the database record.
					$attach_data = wp_generate_attachment_metadata($attach_id, $filename);
					wp_update_attachment_metadata($attach_id, $attach_data);

					## End insert attachment code from codex

					if ($is_featured):

						$feat_info = wp_get_attachment_image_src($attach_id, 'full');

						if ($feat_info):

							// add img tag to original post content

							$is_featured = FALSE; // only one featured image 

							$img_tag     = '<img class="alignleft size-full" src="' . $feat_info[0] . '" alt="" />';

							$upd_post    = $img_tag . "\n<br/>" . $clean_post;

							$updated     = wp_update_post(array('ID' => $post_id, 'post_content' => $upd_post));

							set_post_thumbnail($post_id, $attach_id);

						endif;

					endif;

				endforeach;

			endforeach;

		endforeach;


		wp_set_post_tags($post_id, array('featured'), TRUE);

	endforeach;


	// update dfcg_plugin_settings (Dynamic content gallery)

	$dfcg                = get_option('dfcg_plugin_settings');
	$featured_posts      = get_option('widget_featured-post');
	$counter             = 0;
	$dfcg['cat-display'] = 3;

	foreach ($cat_ids as $slug => $id):

		$counter++;

		if ($counter > 3):

			break;

		endif;

		$featured_posts[$counter + 2]['title']     = $cat_names[$slug];
		$featured_posts[$counter + 2]['posts_cat'] = $id;

		if ($counter === 1):

			for($i = 1; $i<10; $i++):

				//$dfcg['cat01']       = $import['categories'][0]['cat_id'];
				$dfcg['cat'.str_pad($i, 2, '0', STR_PAD_LEFT)] = $id;

			endfor;

		endif;

	endforeach;

	$update = update_option('dfcg_plugin_settings', $dfcg);
	$update = update_option('widget_featured-post', $featured_posts);




	$response['data'] = array(
		'categories' => $cat_ids,
		'articles'   => $posts_info
	);

	echo json_encode($response);
	exit();

endif;



$cat_list = Curler::get($api_url.'/get_category_list');
$cat_list = json_decode($cat_list, TRUE);

if (is_array($cat_list) && $cat_list['success']):

	$cat_list = $cat_list['data']['category_list'];
	sort($cat_list);

endif;

?>


<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Import Site Content</title>
	<style type="text/css">
		body {background:#F1F1F1;font-family:arial,helvetica,sans-serif;}
		form {display:block;width:100%;max-width:980px;margin:20px auto 0;background:#fff;padding:20px 10px;border-radius:10px;box-shadow: 5px 5px 5px #ccc;}
		label {display:block;width:98%;font-weight:800;margin:0 auto;}
		label input, label select {width:100%;display:block;margin-bottom:20px;}
		button {width:98%;display:block;margin:0 auto;font-size:1.4em;border:none;background:#060;color:#fff;border-radius:10px;padding:10px 0;}
		button:hover, button:active {background:#336633;}
		h1 {margin:0 0 20px;padding:0;display:block;text-align:center;}
	</style>
</head>
<body>

	<form action="" method="GET">
		<h1>Import Site Content</h1>
	
		<label for="category">Category:

		<?php if ( ! $cat_list): ?>
		
			<input type="text" name="category" id="category" value=""></label>
		
		<?php else: ?>

			<select name="category" id="category">

				<?php foreach($cat_list as $cat): ?>

					<option value="<?php echo $cat; ?>"><?php echo $cat;?></option>

				<?php endforeach; ?>

			</select>

		<?php endif; ?>

		</label>

		<label for="site_title">Site Title: <input type="text" name="site_title" id="site_title" value=""></label>
		<label for="site_tagline">Site Tagline: <input type="text" name="site_tagline" id="site_tagline" value=""></label>

		<button type="submit">Import</button>
	</form>
	
</body>
</html>