<?php

class Integration extends MX_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index($campaign_id=FALSE)
	{
		$data 	= array();

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: Integration');

		// set data variables
		$data['campaign_id'] 	= $campaign_id;

		// load view
		$this->template->build('integration/integration', $data);
	}

}