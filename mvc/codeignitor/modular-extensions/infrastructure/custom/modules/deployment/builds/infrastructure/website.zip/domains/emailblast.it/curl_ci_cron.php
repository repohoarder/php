<?php

parse_str(implode('&', array_slice($argv, 1)), $_GET);

$debug_email = 'travis.loudin@brainhost.com';

if ( ! isset($_GET['url']) || ! $_GET['url']):

	@mail($debug_email, 'cron ran without url',json_encode($_GET));
	exit();

endif;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $_GET['url']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array("Expect:"));

$response = curl_exec($ch);

curl_close($ch);

if (TRUE || (isset($_GET['debug']) && $_GET['debug'])):

	if (isset($_GET['email']) && strpos($_GET['email'],'@') !== FALSE):

		$debug_email = $_GET['email'];

	endif;

	@mail($debug_email,'eblast cron: '.$_GET['url'], json_encode($_GET)."\n\n".$response);

endif;