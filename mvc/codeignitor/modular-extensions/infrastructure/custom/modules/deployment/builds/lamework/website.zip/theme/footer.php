</div>


    <div id="wahuclosingwrap"></div>
  </div>
  <div id="footer">
    <div class="paddside80">
      		<ul class="footermenu">
        <li><a href="/terms" class="jdialog" title="OHCU Disclaimer">DISCLAIMER</a></li>
        <li>|</li>
        <li><a href="/terms" class="jdialog" title="OHCU Terms">TERMS</a></li>
        <li>|</li>
        <li><a href="/privacy" class="jdialog" title="OHCU Refund Policy">REFUND POLICY</a></li>
        <li>|</li>
        <li><a href="/privacy" class="jdialog" title="OHCU Privacy Policy">PRIVACY</a></li>
        <li>|</li>
        <li><a href="/processing" target="login">MEMBERS LOGIN</a></li>
        <li>|</li>
        <li><a href="/processing" class="jdialog" title="OHCU Contact Info">CONTACT</a></li>
		</ul>    </div>
  </div>
</div>
<div id="dialog" style="display: none;"></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>

<script type="text/javascript" >
	$('.textbox').each(function() {
		var default_value = this.value;
		$(this).focus(function() {
			if(this.value == default_value) {
				this.value = '';
			}
		});
	
		$(this).blur(function() {
			if(this.value == '' || this.value=='') {
					this.value = default_value;
				}
			});
	});
	
	$(".jdialog").click(function() {
		var myUrl = $(this).attr("href");
		var myTitle = $(this).attr("title");
		$("#dialog").load(myUrl).dialog({
             draggable: true,
			 position: "top",
			 width:'70%',
             title: myTitle,
			 modal:true
		}); 
		return false;
	});	
	</script>
</body>
</html>