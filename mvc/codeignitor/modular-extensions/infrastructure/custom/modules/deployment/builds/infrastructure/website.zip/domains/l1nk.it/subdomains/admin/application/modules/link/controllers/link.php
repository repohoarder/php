<?php

class Link extends MX_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		redirect('link/create');
	}

	public function create()
	{
		$data 	= array();

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: Create Link');

		// set data array
		$data['domains']	= array(array('id' => 1, 'domain' => 'l1nk.it'),array('id' => 3, 'domain' => 'urlnano.com'));
		$data['success']	= array('New link was successfully created.');
		$data['errors']		= array('There was an error creating new link.');

		// load view
		$this->template->build('link/create', $data);
	}

	public function view()
	{
		$data 	= array();

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: View Links');

		// set data variables
		$data['links']		= array(array('id' => 1, 'domain' => 'http://l1nk.it/alias', 'url' => 'http://www.google.com', 'active' => TRUE), array('id' => 5, 'domain' => 'http://l1nk.it/v5Hyz', 'url' => 'http://www.brainhost.com', 'active' => FALSE));

		// load view
		$this->template->build('link/view', $data);
	}

}