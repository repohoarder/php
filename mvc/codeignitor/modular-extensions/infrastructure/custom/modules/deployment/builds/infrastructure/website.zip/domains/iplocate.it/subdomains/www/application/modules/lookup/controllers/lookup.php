<?php

class Lookup extends MX_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		redirect('lookup/location');
	}

	public function location()
	{
		// initialize variables
		$data 	= array(
			'location'	=> array()
		);

		// if data was POSTed, then we need to run query
		if ($this->input->post('ip')):

			// grab ip location
			$location 	= $this->platform->post('ip/locate/get_record',array('ip_address' => $this->input->post('ip')));

			// if we got data, set data variable
			if ($location['success'] AND is_array($location['data']['record'])):

				// set data variables
				$data['location']	= $location['data']['record'];
				$data['ip']			= $location['data']['ip_address'];

			endif;

		endif;

		// set theme
		$this->template->set_theme('whois');

		// set default layout
		$this->template->set_layout('default');

		// set the page's title
		$this->template->title('IPLocate.it: IP Location');

		// load view
		$this->template->build('lookup/location', $data);
	}

	public function reputation()
	{
		// initialize variables
		$data 	= array(
			'reputation'	=> array()
		);

		// if data was POSTed, then we need to run query
		if ($this->input->post('ip')):

			// grab ip reputation

		endif;

		// set theme
		$this->template->set_theme('whois');

		// set default layout
		$this->template->set_layout('default');

		// set the page's title
		$this->template->title('IPLocate.it: IP Reputation');

		// load view
		$this->template->build('lookup/reputation', $data);
	}



}