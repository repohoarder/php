<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


require_once(CUSTOM_PATH.'config/constants.php');

define('SITE', 			'iplocate.it');
define('SITE_DIR',		'iplocate');
define('SITE_ADMIN',	'admin.iplocate.it');
define('SITE_TITLE',	'IPLocate It');
define('SITE_CDN',		'http://iplocate.weblumps.com/iplocate/');