	<!-- Footer Content -->
	<footer>
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<ul class="list-inline cinfo-social-buttons pull-center">
						<li><a href="#" class="btn btn-default btn-lg"><i class="fa fa-twitter fa-fw"></i></a></li>
						<li><a href="#" class="btn btn-default btn-lg"><i class="fa fa-dribbble fa-fw"></i></a></li>
						<li><a href="#" class="btn btn-default btn-lg"><i class="fa fa-linkedin fa-fw"></i></a></li>
					</ul>
					<p class="copyright text-center medium">Copyright &copy; <a href="http://www.dkpixels.com">Sparks</a> 2013. All Rights Reserved</p>
				</div>
			</div>
		</div>
	</footer>
	<!-- Footer Content -->
</div>

<!-- JavaScript -->
<script src="/theme/assets/js/jquery.js"></script>
<script src="/theme/assets/js/bootstrap.js"></script>
<script src="/theme/assets/js/owl-carousel/owl.carousel.js"></script>
<script src='/theme/assets/js/jquery.easing.1.3.js'></script> 
<script src="/theme/assets/js/jquery.flexslider.js"></script>
<script src="/theme/assets/js/jquery.html5-placeholder-shim.js"></script>
<script src="/theme/assets/js/main.js"></script>

</body>
</html>