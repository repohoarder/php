<?php

class Session
{
	public function __construct()
	{
		
	}

	public function set($session=array())
	{
		// iterate session array
		foreach ($session AS $key => $value):

			// set session
			$_SESSION[$key]	= $value;

		endforeach;

		return TRUE;
	}

	public function get($key)
	{
		// return session
		return (isset($_SESSION[$key]))? $_SESSION[$key]: FALSE;
	}

	public function get_all()
	{
		return $_SESSION;
	}

	public function set_globals()
	{
		// grab globals
		$globals 		= $this->get('globals');

		// make sure globals aren't already set
		if ( ! $globals):

			// set all SERVER variables to session
			$sessions 	= $_SERVER;

			// create array of new sessions to set
			$sessions['globals']	= TRUE;
			$sessions['ip']			= $_SERVER['REMOTE_ADDR'];
			$sessions['session_id']	= uniqid();

			// set globals variable (so we don't reset these sessions)
			$this->set($sessions);

		endif;
	}
}
