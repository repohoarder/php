<?php

class Campaign extends MX_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		redirect('campaign/create');
	}

	public function create()
	{
		$data 	= array();

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: Create Campaign');

		// load view
		$this->template->build('campaign/create', $data);
	}

	public function view()
	{
		$data 	= array();

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: View Campaign(s)');

		// load view
		$this->template->build('campaign/view', $data);	
	}

}