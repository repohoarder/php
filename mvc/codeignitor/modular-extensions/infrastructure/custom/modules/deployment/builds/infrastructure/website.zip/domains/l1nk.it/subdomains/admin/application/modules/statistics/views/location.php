<?php

echo 'this is where we will show link location statistics.';