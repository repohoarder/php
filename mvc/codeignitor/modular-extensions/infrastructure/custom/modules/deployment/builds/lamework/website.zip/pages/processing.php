<?php

// initialize classes needed for this page
global  $infusionsoft,
		$database,
		$session;

// initialize variables
$amount 		= 0;
$redirect 		= 'declined';
$dropoff_id 	= $session->get('dropoff_id');
$bill_date 		= (date('d') > 28)? 28: date('d');	// set next bill date to 28th if we're past the 28th
$infusionsoft_products 	= array();	// array we will build of infusionsoft products

// grab dropoff information
$dropoff		= $database->select('*','dropoffs',array('id' => $dropoff_id),TRUE);

// query to grab products
$sql 			= '
SELECT 
	* 
FROM 
	dropoffs_products
INNER JOIN 
	products 
		ON 
			dropoffs_products.product_id = products.id 
WHERE 
	dropoffs_products.dropoff_id = "'.$dropoff_id.'"
';

// grab products 
$products 		= $database->sql($sql);

// iterate products (to get amount)
foreach ($products AS $key => $value):

	// add to amount
	$amount 	+= $value['price'];

	// add item to infusionsoft_products array
	$infusionsoft_products[] 	= array(
		'id' 			=> $value['infusionsoft'],	// test product infusionsoft id
		'type' 			=> ($value['type'] == 'initial')? 4: 5,	// Product Type (Initial Sale or Upsell)
		'price' 		=> number_format($value['price'],2),
		'description' 	=> $value['name'],
		'quantity'		=> 1
	);

endforeach;

// format amount
$amount 				= number_format($amount,2);

// grab infusionsoft sessions
$infusionsoft_sessions 	= $session->get('infusionsoft');

// process sale
$sale 			= $infusionsoft->sale($infusionsoft_sessions['cid'],$infusionsoft_sessions['ccid'],$infusionsoft_products,0);

// set success boolean
$success 		= ($sale['Successful'])? TRUE: FALSE;

// create transaction insert array
$insert 		= array(
	'dropoff_id' 		=> $dropoff_id,
	'account'			=> 'infusionsoft',
	'amount' 			=> $amount,
	'response_code' 	=> $sale['Code'],
	'response_text' 	=> $sale['Message'],
	'order_id' 			=> $sale['RefNum'],
	'transaction_id'	=> $sale['RefNum'],
	'type'				=> 'initial',
	'success'			=> $success
);

// store response in transaction table
$database->insert('transactions',$insert);

// if charge was successful
if ($success):

	// set redirect to thank you page
	$redirect 	= 'thank_you';

	// create customer insert array
	$insert 	= array(
		'dropoff_id' 	=> $dropoff_id,
		'bill_date'	 	=> $bill_date,
		'last_billed'	=> 'NOW()'
	);

	// add to customer database
	$customer 	= $database->insert('customers',$insert);

	// create sessions array
	$sessions 	= array(
		'customer_id'	=> $customer,
	);

	// set sessions
	$session->set($sessions);

endif;

// create sessions array
$sessions 	= array(
	'products'		=> $products,
	'response'		=> $sale,
	'amount'		=> $amount
);

// set sessions
$session->set($sessions);

// redirect
_redirect($redirect);