<?php

$autoload 	= array(
	'classes'	=> array(
		'database',
		'infusionsoft',
		'session',
		'theme',
		'tracking'
	)
);
