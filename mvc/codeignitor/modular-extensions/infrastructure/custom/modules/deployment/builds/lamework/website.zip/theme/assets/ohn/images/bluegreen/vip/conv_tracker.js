if (typeof doclix_adv_id != 'undefined') {
	scr = document.createElement('script');
	scr.setAttribute('type','text/javascript');
	var doclix_track_params = '?';
	if (typeof doclix_adv_id != 'undefined')
		doclix_track_params += 'adv_id='+doclix_adv_id;
	if (typeof doclix_cmp_id != 'undefined')
		doclix_track_params += '&cmp_id='+doclix_cmp_id;		
	scr.setAttribute('src', document.location.protocol + '//track.doclix.com/adserver/conversion/conv_tracker.jsp' + doclix_track_params);
	document.getElementsByTagName('head')[0].appendChild(scr);
	//do--cument.write('<img height="1" width="1" border="0" src="'+document.location.protocol+'//track.doclix.com/TrackConv'+doclix_track_params+'" />');
}
