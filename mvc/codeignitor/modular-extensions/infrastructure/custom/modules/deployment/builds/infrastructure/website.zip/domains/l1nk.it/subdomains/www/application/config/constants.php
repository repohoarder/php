<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


require_once(CUSTOM_PATH.'config/constants.php');

define('SITE', 			'l1nk.it');
define('SITE_ADMIN',	'admin.l1nk.it');
define('SITE_TITLE',	'L1nk It');
define('SITE_LOGO',		'http://l1nk.weblumps.com/l1nk/images/logo.png');