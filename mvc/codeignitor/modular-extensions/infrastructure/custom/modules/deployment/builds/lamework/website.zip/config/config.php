<?php

// require the autoload
require_once('autoload.php');

// initialize global config
$config 	= array(

	## Debug Boolean
	'debug'		=> TRUE,

	## DB Settings

	## Timezone Settings
	'timezone'	=> 'America/New_York',

	## autoload
	'autoload'	=> $autoload,

);
