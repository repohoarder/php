
<?php

// testing
$campaign 	= array(
	array(
		'id'	=> 1,
		'name'	=> 'MaxLeanX Landing Page'
	),
	array(
		'id'	=> 3,
		'name'	=> 'Auto Warranty Landing Page'
	),
);

?>


		<div class="group fixed"> 
			
			<div id="uniform-undefined">
				<select name="domain" style="opacity: 0;"> 
					<?php
					// iterate all domains
					foreach ($campaign AS $key => $value):

						// determine whether we need to auto-select this option
						$select 	= ($campaign_id == $value['id'])? 'selected': '';
					?>
						<option value="<?php echo $value['id']; ?>" <?php echo $select; ?>><?php echo $value['name']; ?></option>
					<?php
					endforeach;
					?>
				</select>
	
			</div> 
		</div>
	


<br><br>


<div class="panel-wrapper"> 

	<div class="panel"> 

		<div class="tabs"> 

			<ul> 
				<li class="active"><a href="#" rel="tab-01-content">HTML</a></li>
				<li class="last"><a href="#" rel="tab-02-content">PHP</a></li>
			</ul> 

			<div class="collapse">collapse</div> 

		</div>  

		<div class="tabs-content"> <!-- ## Panel Content  -->  

			<div id="tab-01-content" class="active"> 

				<p>All you need to do is paste the below code into the place of your form and your leads will auomatically insert into the LeadTrack.it System.</p>

				<p style="background-color:#CCCCCC;margin: 10px 10px 10px 10px;color:#FFF;">
					<?php 
					highlight_string('
	<form name="" action="" method="POST">

		<!-- These are your fields to add -->
		<input type="text" name="name" />
		<input type="text" name="email" />
		<input type="text" name="meta[phone]" />

		<!-- Define hidden fields here -->
		<input type="hidden" name="vertical_id" value="6" />
		<input type="hidden" name="site_id" value="3" />
		<input type="hidden" name="ip" value="<?php echo $_SERVER[\'REMOTE_ADDR\']; ?>" />
	</form>
					'); 
					?>
				</p>

			</div>  

			<div id="tab-02-content">

				<p>Please copy the below code and add it to the top of your page collecting the data.</p>

				<p style="background-color:#CCCCCC;margin: 10px 10px 10px 10px;color:#FFF;">
					<?php 
					highlight_string('
	<?php 

	$submitted 	= (isset($_REQUEST[\'email\']))? TRUE: FALSE;

	if ($submitted):

		// initialize variables 
		$email 	= $_REQUEST[\'email\'];
		$meta 	= $_REQUEST[\'meta\'];


		// set POST array 
		$post 	= array(
			\'apikey\'		=> \'adsfsdfgsdfsa3r4423wreds\',
			\'vertical_id\'	=> \'6\',
			\'site_id\'		=> \'3\'
			\'email\'		=> $email,
			\'ip\' 			=> $_SERVER[\'REMOTE_ADDR\'],
			\'meta\'		=> $_REQUEST[\'meta\']
		);

		// POST data to LeadTrack.it
		curl(\'http://app.weblumps.com/lead/add\',$post);

	endif;

					'); 
					?>
				</p>

			</div>

		</div> 

	</div>  

	<div class="shadow"></div> 

</div>