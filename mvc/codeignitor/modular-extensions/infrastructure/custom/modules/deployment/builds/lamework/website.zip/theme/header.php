
<!doctype html>
<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="description" content="Online Home Careers University You Can Start Earning Real Money From Home Today. Visit OHCUniversity.com">
<meta name="keywords" content="Online Home Careers University">
<title>Online Home Careers University - OHCUniversity.com</title>
<link rel="stylesheet" href="../../../../../../files/main.css">
<link href="../../../../../../js/css/ui-lightness/jquery-ui-1.10.3.custom.min.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="../../../../../../files/jscripts-lib.js"></script>
<script type="text/javascript" src="../../../../../../files/exitpop.js"></script>
<script type="text/javascript" >
			var param = "vid=3699011";
			var internalLink = false;
			var eurl = "/processing"
			var vmsg = '************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n\n Wait... Before You Go:\n\n\n We want to offer you a special discount that is normally restricted to only friends and family.\n\n\n You can SAVE BIG by clicking the cancel button below.\n\n\n You will get my entire system for only $97.00. That is $100 OFF the normal price of $197.00.\n\n\n To take advantage of this special offer and get INSTANT ACCESS, click on the CANCEL button below.\n\n ************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n';
			var userAgent = navigator.userAgent.toLowerCase();
			if(userAgent.search('firefox') != -1)
			{
				window.onbeforeunload = pageUnload;
			} else if (userAgent.search('safari') != -1)
			{
				window.onbeforeunload = function (ev) {
				    var e = ev || window.event;
				    window.focus();
				    if (!internalLink){
				      internalLink = true;
				      var showstr = '************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n\n Wait... Before You Go:\n\n\n We want to offer you a special discount that is normally restricted to only friends and family.\n\n\n You can SAVE BIG by clicking the cancel button below.\n\n\n You will get my entire system for only $97.00. That is $100 OFF the normal price of $197.00.\n\n\n To take advantage of this special offer and get INSTANT ACCESS, click on the CANCEL button below.\n\n ************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n';
				      
				      return showstr; //for safari and chrome
				    }
				};
				
				window.onfocus = function (ev){
				    if (internalLink){
				      window.location.href = "/processing";
				    }
				}
				
			} else { /** ie or chrome **/
				window.onbeforeunload = areYouSure;
			}
			
			function pageUnload() 
			{
				if (!internalLink){
					internalLink = true;
					alert('************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n\n Wait... Before You Go:\n\n\n We want to offer you a special discount that is normally restricted to only friends and family.\n\n\n You can SAVE BIG by clicking the cancel button below.\n\n\n You will get my entire system for only $97.00. That is $100 OFF the normal price of $197.00.\n\n\n To take advantage of this special offer and get INSTANT ACCESS, click on the CANCEL button below.\n\n ************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n');
					location.href= "/processing";
					return '************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n\n Wait... Before You Go:\n\n\n We want to offer you a special discount that is normally restricted to only friends and family.\n\n\n You can SAVE BIG by clicking the cancel button below.\n\n\n You will get my entire system for only $97.00. That is $100 OFF the normal price of $197.00.\n\n\n To take advantage of this special offer and get INSTANT ACCESS, click on the CANCEL button below.\n\n ************************************************\n Today\'s Special 50% OFF Discount\n ************************************************\n\n';
				}
			}

			var dep = false;
			
	$(document).ready(function() {
		$('a').bind('click', function(event) {
			internalLink = true;
		});
	});
	</script>
<style type="text/css">
.auto-style1 {
	margin-top: 0px;
}
.lktop {
	color: #605f5f;
	text-decoration: none;
	font-weight: bold;
	font-family: Verdana, Arial, Helvetica, sans-serif;
	text-transform: uppercase;
	padding-left: 20px;
	padding-right: 20px;
	font-size: 12px;
	line-height: 30px;
}
.mlktop {
	background: url("../../../../../../images/bg-link.jpg") no-repeat scroll top left transparent;
}
.cliktop {
	background: url("../../../../../../images/bg-link.jpg") no-repeat scroll bottom left transparent;
}
</style>
</head>
<body>