<?php

echo 'this is where we will show statistics on lead location(s).';