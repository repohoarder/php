<?php

echo 'this is where we will show lead statistics';