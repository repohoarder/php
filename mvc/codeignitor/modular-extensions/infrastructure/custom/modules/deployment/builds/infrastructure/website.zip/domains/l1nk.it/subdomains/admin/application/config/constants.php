<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


require_once(CUSTOM_PATH.'config/constants.php');

define('SITE', 			'l1nk.it');
define('SITE_DIR',		'l1nkit');
define('SITE_ADMIN',	'admin.l1nk.it');
define('SITE_TITLE',	'L1nk It');
define('SITE_CDN',		'http://l1nk.weblumps.com/l1nk/');