
<div class="panel-wrapper"> 

	<div class="panel"> 

		<div class="title"> 
			
			<h4>Table sample</h4> 

			<div class="collapse">collapse</div> 
		</div>  

		<div class="content"> 
			<!-- ## Panel Content  -->  
			<table id="sample-table" class=""> 
				<thead> 
					<tr> 
						<th>Last Name</th> 
						<th>First Name</th> 
						<th>Email</th> 
						<th>Due</th> 
						<th>Web Site</th> 
					</tr> 
				</thead> 

				<tbody> 
					<tr> 
						<td>Smith</td> 
						<td>John</td> 
						<td>jsmith@gmail.com</td>
						<td>$50.00</td> 
						<td>http://www.jsmith.com</td> 
					</tr> 

					<tr> 
						<td>Bach</td> 
						<td>Frank</td> 
						<td>fbach@yahoo.com</td> 
						<td>$50.00</td> 
						<td>http://www.frank.com</td> 
					</tr> 

					<tr>
						<td>Doe</td> 
						<td>Jason</td>
						<td>jdoe@hotmail.com</td> 
						<td>$100.00</td> 
						<td>http://www.jdoe.com</td> 
					</tr> 
				</tbody> 
			</table>  
			<!-- ## / Panel Content  --> 

		</div> 
		
	</div>  

	<!-- <div class="shadow"></div> -->

</div>

