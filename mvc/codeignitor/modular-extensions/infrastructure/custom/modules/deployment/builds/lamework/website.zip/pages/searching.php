
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>OHC University- Checking Availability</title>
<!-- Jquery and Validate -->

<script type="text/javascript" src="/theme/assets/ohn/js/jquery.min.js"></script>
<script type="text/javascript"> 
var qs = window.location.search.substring(1);
function Found()
{
	$('#searching').slideUp();
	$('#found').slideDown();
	$('#linktext').attr("href", "/offer")
	setTimeout("Redirect();",2000);
}
function Redirect()
{
	window.location = '/offer';
}
/* var city = geoip_city(); */
$(document).ready(function() {
	setTimeout("Found();",1500);
});
</script>
<link rel="stylesheet" href="//ohcuniversity.com/careers/files/main.css">
</head>
<body>
<div id="main">
  <div id="wahuheader"> <img src="/theme/assets/ohn/images/tvlogos.jpg" style="padding-top: 118px; padding-left: 345px;" alt="TV"> </div>
  <div id="content">
    <div class="fr" style="padding-right: 10px;"> <a class="lktop mlktop" href="/" target="page">MEMBERS LOGIN</a> <span class="lktop" style="padding-left: 0px;">|</span> <a href="/contact" class="lktop cliktop jdialog" title="OHCU Contact Info">CONTACT</a> </div>
    <div class="clear"></div>
<div id="searching">
  <div style="text-align:center; font-size:24px; margin:50px 0 20px;">Searching For Work At Home Jobs In <span class="dynamic">
    Akron</span>.<br />
    <img src="/theme/assets/ohn/images/loader2.gif" alt="searching" title="searching" class="" />
    <p style="text-align: center;font-size:14px;">Please wait...</p>
  </div>
</div>
<div id="found" style="display:none;">
  <div style="text-align:center; font-size:30px; margin:50px 0 20px;"><strong style="color:red;font-size:35px;border-bottom:2px solid red;"></strong> Positions Available!...</div>
  <p style="text-align: center;font-size:14px;"><a id="linktext" href="/offer">Click here if you are not automatically redirected.</a></p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</div>

<div id="wahuclosingwrap"></div>
  </div>
  <div id="footer">
    <div class="paddside80">
      		<ul class="footermenu">
        <li><a href="/disclaimer" class="jdialog" title="OHCU Disclaimer">DISCLAIMER</a></li>
        <li>|</li>
        <li><a href="/terms" class="jdialog" title="OHCU Terms">TERMS</a></li>
        <li>|</li>
        <li><a href="/privacy" class="jdialog" title="OHCU Refund Policy">REFUND POLICY</a></li>
        <li>|</li>
        <li><a href="/privacy" class="jdialog" title="OHCU Privacy Policy">PRIVACY</a></li>
        <li>|</li>
        <li><a href="/squeeze" target="login">MEMBERS LOGIN</a></li>
        <li>|</li>
        <!--
        <li><a href="/theme/assets/ohn/ohcu-contact" class="jdialog" title="OHCU Contact Info">CONTACT</a></li>-->
		</ul>    </div>
  </div>
</div>
</body>
</html>