

<div class="panel-wrapper fixed"> 

	<div class="panel ">  

		<div class="title"> 

			<h4>Link - Create New</h4> 

			<div class="collapse">collapse</div> 

		</div>  

		<div class="content"> <!-- ## Panel Content  -->  

			<form method="post" action="">

				<div class="group fixed"> 
					<label>Redirect URL</label> 
					<input type="text" value="" placeholder="http://www.google.com" /> 
					<p class="note">This is the URL that the link will redirect to.</p>
				</div>  

				<div class="group fixed"> 
					<label>Domain</label> 
					<div id="uniform-undefined">
						<select name="domain" style="opacity: 0;"> 
							<?php
							// iterate all domains
							foreach ($domains AS $key => $value):
							?>
								<option value="<?php echo $value['id']; ?>"><?php echo $value['domain']; ?></option>
							<?php
							endforeach;
							?>
						</select>
					</div> 
				</div>

				<div class="group fixed"> 
					<label>Domain Alias (optional)</label> 
					<input type="text" value="" placeholder="landing_page" /> 
					<p class="note">If no alias is specified, one will be automatically generated for you.</p>
				</div>  

				<a href="#" class="button-blue">Create New Link <!-- <img src="http://quickadmin.weblumps.com/weblumps/quickadmin/images/icon-star-white.png" alt=""> --></a>

			</form>  <!-- ## / Panel Content  --> 

		</div> 

	</div>  

	<div class="shadow"></div> 
</div>