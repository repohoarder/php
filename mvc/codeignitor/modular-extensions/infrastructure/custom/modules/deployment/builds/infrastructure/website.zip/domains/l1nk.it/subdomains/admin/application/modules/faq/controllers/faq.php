<?php

class Faq extends MX_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$data 	= array();

		// set template layout to use
		$this->template->set_layout('default');

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: Frequently Asked Questions');

		// load view
		$this->template->build('faq/faq', $data);
	}

}