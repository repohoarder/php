<?php

echo 'this is where we will show link click statistics.';