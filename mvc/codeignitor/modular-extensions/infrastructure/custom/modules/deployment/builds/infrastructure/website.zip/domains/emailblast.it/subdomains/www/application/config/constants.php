<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


require_once(CUSTOM_PATH.'config/constants.php');

define('SITE', 			'emailblast.it');
define('SITE_ADMIN',	'admin.emailblast.it');
define('SITE_TITLE',	'Email Blast It');
define('SITE_LOGO',		'http://emailblast.weblumps.com/emailblast/images/logo.png');