<?php

class Statistics extends MX_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		redirect('statistics/leads');
	}

	public function campaigns()
	{
		$data 	= array();

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: Campaign Statistics');

		// load view
		$this->template->build('statistics/campaigns', $data);
	}

	public function leads()
	{
		$data 	= array();

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: Lead Statistics');

		// load view
		$this->template->build('statistics/leads', $data);
	}

	public function location()
	{
		$data 	= array();

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: Location Statistics');

		// load view
		$this->template->build('statistics/location', $data);
	}

	public function referrer()
	{
		$data 	= array();

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: Referrer Statistics');

		// load view
		$this->template->build('statistics/referrer', $data);
	}

	public function usage()
	{
		$data 	= array();

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: Usage Statistics');

		// load view
		$this->template->build('statistics/usage', $data);
	}
}