<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


require_once(CUSTOM_PATH.'config/constants.php');

define('SITE', 			'leadtrack.it');
define('SITE_DIR',		'leadtrack');
define('SITE_ADMIN',	'admin.leadtrack.it');
define('SITE_TITLE',	'Lead Track It');
define('SITE_CDN',		'http://leadtrack.weblumps.com/leadtrack/');