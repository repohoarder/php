
<div class="panel-wrapper"> 

	<div class="panel"> 

		<div class="title"> 
			
			<h4>Real-Time Leads</h4> 

			<div class="collapse"><a href="/lead/export">View All</a></div> 
		</div>  

		<div class="content"> 
			<!-- ## Panel Content  -->  
			<table id="sample-table" class=""> 
				<thead> 
					<tr> 
						<th>Campaign</th>
						<th>Email</th> 
						<th>IP</th> 
						<th>Website</th>
					</tr> 
				</thead> 

				<tbody> 
					<tr> 
						<td>MaxLeanX Buyer</td> 
						<td>jsmith@gmail.com</td>
						<td>98.129.100.23</td> 
						<td>maxleanx.com</td> 
					</tr> 

					<tr> 
						<td>Auto Landing Page</td> 
						<td>jhowley@yahoo.com</td>
						<td>89.202.12.45</td> 
						<td>auto-warranty-experts.com</td> 
					</tr> 

					<tr>
						<td>MaxLeanX Buyer</td> 
						<td>thom45@aol.com</td>
						<td>64.57.123.204</td> 
						<td>maxleanx.com</td> 
					</tr> 

					<tr>
						<td>MaxLeanX Buyer</td> 
						<td>thom45@aol.com</td>
						<td>64.57.123.204</td> 
						<td>maxleanx.com</td> 
					</tr> 

					<tr>
						<td>MaxLeanX Buyer</td> 
						<td>thom45@aol.com</td>
						<td>64.57.123.204</td> 
						<td>maxleanx.com</td> 
					</tr> 

					<tr>
						<td>MaxLeanX Buyer</td> 
						<td>thom45@aol.com</td>
						<td>64.57.123.204</td> 
						<td>maxleanx.com</td> 
					</tr> 

					<tr>
						<td>MaxLeanX Buyer</td> 
						<td>thom45@aol.com</td>
						<td>64.57.123.204</td> 
						<td>maxleanx.com</td> 
					</tr> 

					<tr>
						<td>MaxLeanX Buyer</td> 
						<td>thom45@aol.com</td>
						<td>64.57.123.204</td> 
						<td>maxleanx.com</td> 
					</tr> 

					<tr>
						<td>MaxLeanX Buyer</td> 
						<td>thom45@aol.com</td>
						<td>64.57.123.204</td> 
						<td>maxleanx.com</td> 
					</tr> 

					<tr>
						<td>MaxLeanX Buyer</td> 
						<td>thom45@aol.com</td>
						<td>64.57.123.204</td> 
						<td>maxleanx.com</td> 
					</tr> 
				</tbody> 
			</table>  
			<!-- ## / Panel Content  --> 

		</div> 
		
	</div>  

	<!-- <div class="shadow"></div> -->

</div>

