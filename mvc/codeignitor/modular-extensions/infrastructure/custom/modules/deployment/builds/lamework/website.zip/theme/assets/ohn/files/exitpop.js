var areYouReallySure = false;
var internalLink = false;

function downsell() 
{
    location.href = eurl;
}

function areYouSure() {
    if (typeof (dep) != 'undefined') {if (dep) areYouReallySure = true;}
    if (!areYouReallySure && !internalLink) 
    {
    	areYouReallySure = true;
        if (navigator.userAgent.indexOf("Chrome") != -1) 
        {
            setTimeout(downsell, 1);
        } 
        else 
        {
            downsell();
        }
        return vmsg;
    }
}
window.onbeforeunload = areYouSure;