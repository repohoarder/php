<?php

// if we're in tet mode, then display errors
if ($config['debug'])
	ini_set('display_errors','On');


// initialize global variables
global 	$page,
		$params;

// create global variables for each autoload
foreach ($config['autoload'] AS $type => $values):

	// iterate all types
	foreach ($config['autoload'][$type] AS $class):

		// set as global variable
		global $$class;

		// if not already, set as empty object
		if ( ! isset($$class))
			$$class 	= new stdclass;

	endforeach;

endforeach;

// autoload classes
_autoload($config);

// set global sessions
$session->set_globals();

// initialize
_initialize($config);




function _initialize($config)
{
	// use the global params variable
	global 	$theme,
			$tracking,
			$page,
			$params,
			$session;

	// grab REQUEST URI
	$uri 	= REQUEST_URI;

	// split into array
	$params = explode('/',$uri);

	// get page
	$page 	= $params[1];

	// set PARAMS (remove 1st 2 items from array)
	array_shift($params);
	array_shift($params);

	// urldecode all parameters
	foreach ($params AS $key => $value):
		$params[$key]	= urldecode($value);
	endforeach;

	// make sure page exists
	_404($page);

	// track visitor/hit
	$tracking->hit($page,$params);

	// load the page
	$theme->page($page);

	// destruct
}

function _autoload($config)
{
	// initialize variables
	$filepath 	= array(	// the types of files that can be autoloaded
		'classes'	=> BASE_PATH.'classes'.SEPARATOR
	);

	// iterate all autoload items
	foreach ($config['autoload'] AS $type => $value):

		// iterate all $type that need loaded
		foreach ($config['autoload'][$type] AS $class):

			// make sure class exists
			if (file_exists(BASE_PATH.$type.SEPARATOR.$class.'.php')):

				// require and load class
				require_once(BASE_PATH.$type.SEPARATOR.$class.'.php');

				// set as global variable
				global $$class;

				// initialize
				$$class 	= new $class();

			endif;

		endforeach;

	endforeach;
}

function _404($page)
{
	// make sure file (page) exists
	if ( ! file_exists(BASE_PATH.'pages/'.$page.'.php')):

		// load global theme variable
		global $theme;

		// log 404 (ip, uri, etc..)
		_log();

		return $theme->error('404: File does not exist');

	endif;

	// made it here, do nothing
	return;
}

function _debug($data=array(),$exit=FALSE)
{
	// neatly display array
	print "<pre>";
	print_r($data);
	print "</pre>";

	if ($exit)
		exit;

	return;
}

function _log()
{
	// log to file
}

// redirect 
function _redirect($uri)
{
	// initialize variables
	$redirect 	= BASE_URL.$uri;

	// header redirect
	//header("HTTP/1.1 301 Moved Permanently"); 
	header("Location: $redirect");
}

function _header_redirect($url)
{
	header("Location: $url");
}

function _cc_type($cc)
{
	return 'Visa';
}

function _curl($url,$post,$proxy=FALSE)
{
	// generate query string from post_data
	$query_string = http_build_query($post);
	
	// initialize curl
	$ch = curl_init();
	
	// set parameters
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

	// run cUrl
	$response = curl_exec ($ch);

	// grab cUrl response headers and code
	$headers 	= curl_getinfo($ch, CURLINFO_HEADER_OUT);
	$code    	= curl_getinfo($ch, CURLINFO_HTTP_CODE);

	// close connection
	curl_close($ch);

	// return the result
	return $result;
}



