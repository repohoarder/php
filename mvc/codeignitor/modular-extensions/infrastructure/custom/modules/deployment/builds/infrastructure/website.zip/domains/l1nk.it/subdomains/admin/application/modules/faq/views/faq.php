



<div class="panel-wrapper panel-chart-dashboard fixed"> 

	<div class="panel ">  

		<div class="title"> 

			<h4>Frequently Asked Questions</h4> 
			<div class="collapse">collapse</div> 

		</div>  

		<div class="content"> <!-- ## Panel Content  -->  

			<div id="faq-list">

				<div> 
					<input class="search" type="text" placeholder="Type your question"> 
				</div>  

				<ul class="list">
					<li><strong>1.</strong> <a href="#topic-01" class="name">Where can I put my newly created Web pages?</a></li>
					<li><strong>2.</strong> <a href="#topic-02" class="name">How can I put my newly created Web pages?</a></li>
				</ul> 
			</div>  

			<div class="hr"></div>  

			<div id="faq-details"> 

				<h2 id="topic-01">
					<strong>1.</strong> Where can I put my newly created Web pages?
				</h2> 

				<p>Donec mauris tortor.</p>

				<h2 id="topic-02">
					<strong>1.</strong> How can I put my newly created Web pages?
				</h2> 

				<p>Donec mauris tortor.</p>  

			</div> <!-- ## / Panel Content  --> 

		</div> 

	</div>  

	<div class="shadow"></div> 

</div>