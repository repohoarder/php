<?php

// initialize classes needed for this page
global  $amazon,
		$database,
		$infusionsoft,
		$params,
		$session,
		$theme;

// initialize variables
$error 		= (isset($params[0]))? $params[0]: FALSE;
$submitted 	= (isset($_REQUEST['submit']))? TRUE: FALSE;

// if data was submitted
if ($submitted):

	// initialize variables
	$product_id = 2;//$_REQUEST['product_id'];
	$first 		= $_REQUEST['first'];
	$last	 	= $_REQUEST['last'];
	$address 	= $_REQUEST['address'];
	$city 		= $_REQUEST['city'];
	$state 		= $_REQUEST['state'];
	$zip 		= $_REQUEST['zip'];
	$country	= $_REQUEST['country'];
	$phone 		= $_REQUEST['phone'];
	$cc 		= $_REQUEST['cc'];

	// validation

	// create insert array for dropoffs
	$insert 	= array(
		'partials_id'	=> $session->get('partial_id'),
		'first'			=> $first,
		'last' 			=> $last,
		'address' 		=> $address,
		'city' 			=> $city,
		'state' 		=> $state,
		'zip' 			=> $zip,
		'country' 		=> $country,
		'phone' 		=> $phone,
		'cc_number' 	=> $cc['number'],
		'cc_exp_month' 	=> $cc['month'],
		'cc_exp_year' 	=> $cc['year'],
		'cc_cvv' 		=> $cc['cvv'],
	);

	// insert lead into dropoffs table
	$dropoff_id = $database->insert('dropoffs',$insert);

	// create insert array for dropoffs_products
	$insert 	= array(
		'dropoff_id' 	=> $dropoff_id,
		'product_id'	=> $product_id
	);

	// add product to dropoffs_products
	$database->insert('dropoffs_products',$insert);

	########################################################
	## INFUSIONSOFT

	// get infusionsoft session array
	$infusionsoft_array 		= $session->get('infusionsoft');

	// crete infusionsoft update array
	$update 					= array(
		'FirstName'			=> $first,
		'LastName'			=> $last,
		'StreetAddress1'	=> $address,
		'StreetAddress2'	=> '',
		'City' 				=> $city,
		'PostalCode' 		=> $zip,
		'State'				=> $state,
		'Country'			=> $country,
		'Phone1'			=> $phone	
	);

	// update user in Infusionsoft
	$infusionsoft->update($infusionsoft_array['cid'],$update);

	// create array to insert new infusionsoft cc#
	$card 	= array(
		"ContactId" 		=> $infusionsoft_array['cid'],
		"NameOnCard" 		=> $first.' '.$last,
		"CardNumber"		=> $cc['number'],
		"CardType"			=> _cc_type($cc['number']),
		"CVV2"				=> $cc['cvv'],
		"ExpirationMonth"	=> $cc['month'],
		"ExpirationYear"	=> $cc['year']
	);

	// add credit card
	$ccid 	= $infusionsoft->credit_card($card);

	// append to infusionsoft session array
	$infusionsoft_array['ccid']	= $ccid;

	## END INFUSIONSOFT
	########################################################


	// create sessions array
	$sessions 	= array(
		'dropoff_id'	=> $dropoff_id,
		'first'			=> $first,
		'last' 			=> $last,
		'address' 		=> $address,
		'city' 			=> $city,
		'state' 		=> $state,
		'zip' 			=> $zip,
		'country' 		=> $country,
		'phone' 		=> $phone,
		'infusionsoft'	=> $infusionsoft_array
	);

	// set sessions
	$session->set($sessions);

	// redirect
	_redirect('discount');
	
endif;

// include header
//$theme->load('header');
?>


<!--
<h1>This is the Billing Page</h1>

<?php
// show error
if ($error)
	echo '<p style="font-weight:bold;color:red;">'.$error.'</p>';
?>

<form action="<?php echo '/'.$page; ?>" method="POST">
	<table>
		<tr>
			<td>First Name</td>
			<td><input type="text" name="first" value="" /></td>
		</tr>
		<tr>
			<td>Last Name</td>
			<td><input type="text" name="last" value="" /></td>
		</tr>
		<tr>
			<td>Address</td>
			<td><input type="text" name="address" value="<?php echo $email; ?>" /></td>
		</tr>
		<tr>
			<td>City</td>
			<td><input type="text" name="city" value="" /></td>
		</tr>
		<tr>
			<td>State</td>
			<td><input type="text" name="state" value="" /></td>
		</tr>
		<tr>
			<td>Zip Code</td>
			<td><input type="text" name="zip" value="" /></td>
		</tr>
		<tr>
			<td>Country</td>
			<td><input type="text" name="country" value="" /></td>
		</tr>
		<tr>
			<td>Phone</td>
			<td><input type="text" name="phone" value="" /></td>
		</tr>
		<tr>
			<td colspan=2><hr></td>
		</tr>
		<tr>
			<td>Credit Card Number</td>
			<td><input type="text" name="cc[number]" value="" /></td>
		</tr>
		<tr>
			<td>Exp. Month</td>
			<td><input type="text" name="cc[month]" value="" /></td>
		</tr>
		<tr>
			<td>Exp. Year</td>
			<td><input type="text" name="cc[year]" value="" /></td>
		</tr>
		<tr>
			<td>CVV</td>
			<td><input type="text" name="cc[cvv]" value="" /></td>
		</tr>
		<tr>
			<td colspan=2><input type="submit" name="submit" value="Register My Business" /></td>
		</tr>
	</table>

	<input type="hidden" name="product_id" value="1" />

</form>
-->


<!DOCTYPE html>
<html xml:lang="en" lang="en" xmlns="http://www.w3.org/1999/xhtml">
		<head>
		<title>Secure Checkout for theOnline Home Careers UniversityProgram</title>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta name="robots" CONTENT="noindex, nofollow" />
		<meta name="author" content="SSL Secure Payments" />
		<link rel="shortcut icon" href="https://ohcuniversity.com/favicon.ico" />
		<link href="/theme/assets/ohn/files/style.css" media="all" type="text/css" rel="stylesheet" />
<link href="/theme/assets/ohn/js/css/ui-lightness/jquery-ui-1.10.3.custom.min.css" rel="stylesheet" type="text/css" />
		<!--[if IE]>
	<link href="/theme/assets/ohn/ie.css" media="all" type="text/css" rel="stylesheet" />
	<![endif]-->

				<script src="/theme/assets/ohn/files/jscripts-lib.js" type="text/javascript"></script>
		<script src="/theme/assets/ohn/files/exitpop.js" type="text/javascript"></script>
		<script>
			var param = "vid=3699011";
			var internalLink = false;
			var eurl = "/discount"
			var vmsg = '************************************************\n Today\'s Special 61% OFF Discount\n ************************************************\n\n\n Wait... Before You Go:\n\n\n We want to offer you a special discount that is normally restricted to only friends and family.\n\n\n You can SAVE BIG by clicking the cancel button below.\n\n\n You will get my entire system for only $-120.00. That is $120.00 OFF the normal price of $0.00.\n\n\n To take advantage of this special offer and get INSTANT ACCESS, click on the CANCEL button below.\n\n ************************************************\n Today\'s Special 61% OFF Discount\n ************************************************\n\n';
			var userAgent = navigator.userAgent.toLowerCase();
			if(userAgent.search('firefox') != -1)
			{
				window.onbeforeunload = pageUnload;
			} else if (userAgent.search('safari') != -1)
			{
				window.onbeforeunload = function (ev) {
				    var e = ev || window.event;
				    window.focus();
				    if (!internalLink){
				      internalLink = true;
				      var showstr = '************************************************\n Today\'s Special 61% OFF Discount\n ************************************************\n\n\n Wait... Before You Go:\n\n\n We want to offer you a special discount that is normally restricted to only friends and family.\n\n\n You can SAVE BIG by clicking the cancel button below.\n\n\n You will get my entire system for only $-120.00. That is $120.00 OFF the normal price of $0.00.\n\n\n To take advantage of this special offer and get INSTANT ACCESS, click on the CANCEL button below.\n\n ************************************************\n Today\'s Special 61% OFF Discount\n ************************************************\n\n';
				      
				      return showstr; //for safari and chrome
				    }
				};
				
				window.onfocus = function (ev){
				    if (internalLink){
				      window.location.href = "/discount";
				    }
				}
				
			} else { /** ie or chrome **/
				window.onbeforeunload = areYouSure;
			}
			
			function pageUnload() 
			{
				if (!internalLink){
					internalLink = true;
					alert('************************************************\n Today\'s Special 61% OFF Discount\n ************************************************\n\n\n Wait... Before You Go:\n\n\n We want to offer you a special discount that is normally restricted to only friends and family.\n\n\n You can SAVE BIG by clicking the cancel button below.\n\n\n You will get my entire system for only $-120.00. That is $120.00 OFF the normal price of $0.00.\n\n\n To take advantage of this special offer and get INSTANT ACCESS, click on the CANCEL button below.\n\n ************************************************\n Today\'s Special 61% OFF Discount\n ************************************************\n\n');
					location.href= "/discount";
					return '************************************************\n Today\'s Special 61% OFF Discount\n ************************************************\n\n\n Wait... Before You Go:\n\n\n We want to offer you a special discount that is normally restricted to only friends and family.\n\n\n You can SAVE BIG by clicking the cancel button below.\n\n\n You will get my entire system for only $-120.00. That is $120.00 OFF the normal price of $0.00.\n\n\n To take advantage of this special offer and get INSTANT ACCESS, click on the CANCEL button below.\n\n ************************************************\n Today\'s Special 61% OFF Discount\n ************************************************\n\n';
				}
			}

			var dep = false;
		</script>
                
		<script type="text/javascript">
function updateStatesMenu(ctry) {if (ctry == "GB" || ctry == "EN") {document.getElementById('stateOptions').innerHTML = '<select name="state" id="state" class="formtb FormField"><option value="GB-ABE">Aberdeen City</option><option value="GB-ABD">Aberdeenshire</option><option value="GB-ANS">Angus</option><option value="GB-ANT">Antrim</option><option value="GB-ARD">Ards</option><option value="GB-AGB">Argyll and Bute</option><option value="GB-ARM">Armagh</option><option value="GB-BLA">Ballymena</option><option value="GB-BLY">Ballymoney</option><option value="GB-BNB">Banbridge</option><option value="GB-BDG">Barking and Dagenham</option><option value="GB-BNE">Barnet</option><option value="GB-BNS">Barnsley</option><option value="GB-BAS">Bath and North East Somerset</option><option value="GB-BBO">Bedford Borough</option><option value="GB-BDF">Bedfordshire</option><option value="GB-BFS">Belfast</option><option value="GB-BEX">Bexley</option><option value="GB-BIR">Birmingham</option><option value="GB-BBD">Blackburn with Darwen</option><option value="GB-BPL">Blackpool</option><option value="GB-BGW">Blaenau Gwent</option><option value="GB-BOL">Bolton</option><option value="GB-BMH">Bournemouth</option><option value="GB-BRC">Bracknell Forest</option><option value="GB-BRD">Bradford</option><option value="GB-BEN">Brent</option><option value="GB-BGE">Bridgend</option><option value="GB-BNH">Brighton and Hove</option><option value="GB-BST">Bristol, City of</option><option value="GB-BRY">Bromley</option><option value="GB-BUC">Buckingham</option><option value="GB-BKM">Buckinghamshire</option><option value="GB-BUR">Bury</option><option value="GB-CAY">Caerphilly</option><option value="GB-CLD">Calderdale</option><option value="GB-CAM">Cambridgeshire</option><option value="GB-CMD">Camden</option><option value="GB-CRF">Cardiff</option><option value="GB-CMN">Carmarthenshire</option><option value="GB-CKF">Carrickfergus</option><option value="GB-CSR">Castlereagh</option><option value="GB-CGN">Ceredigion</option><option value="GB-CHS">Cheshire</option><option value="GB-CHE">Cheshire East</option><option value="GB-CWC">Cheshire West and Chester</option><option value="GB-CLK">Clackmannanshire</option><option value="GB-CLR">Coleraine</option><option value="GB-CWY">Conwy</option><option value="GB-CKT">Cookstown</option><option value="GB-CON">Cornwall</option><option value="GB-COV">Coventry</option><option value="GB-CGV">Craigavon</option><option value="GB-CRY">Croydon</option><option value="GB-CMA">Cumbria</option><option value="GB-DAL">Darlington</option><option value="GB-DEN">DenbighshireD</option><option value="GB-DER">Derby</option><option value="GB-DBY">Derbyshire</option><option value="GB-DRY">Derry</option><option value="GB-DEV">Devon</option><option value="GB-DNC">Doncaster</option><option value="GB-DOR">Dorset</option><option value="GB-DOW">Down</option><option value="GB-DUD">Dudley</option><option value="GB-DGY">Dumfries and Galloway</option><option value="GB-DND">Dundee City</option><option value="GB-DGN">Dungannon</option><option value="GB-DUR">Durham</option><option value="GB-EAL">Ealing</option><option value="GB-EAY">East Ayrshire</option><option value="GB-EDU">East Dunbartonshire</option><option value="GB-ELN">East Lothian</option><option value="GB-ERW">East Renfrewshire</option><option value="GB-ERY">East Riding of Yorkshire</option><option value="GB-ESX">East Sussex</option><option value="GB-EDH">Edinburgh, City of</option><option value="GB-ELS">Eilean Siar</option><option value="GB-ENF">Enfield</option><option value="GB-ESS">Essex</option><option value="GB-FAL">Falkirk</option><option value="GB-FER">Fermanagh</option><option value="GB-FIF">Fife</option><option value="GB-FLN">Flintshire</option><option value="GB-GAT">Gateshead</option><option value="GB-GLG">Glasgow City</option><option value="GB-GLS">Gloucestershire</option><option value="GB-GLO">Greater London</option><option value="GB-GRE">Greenwich</option><option value="GB-GGY">Guernsey</option><option value="GB-GWN">Gwynedd</option><option value="GB-HCK">Hackney</option><option value="GB-HAL">Halton</option><option value="GB-HMF">Hammersmith and Fulham</option><option value="GB-HAM">Hampshire</option><option value="GB-HRY">Haringey</option><option value="GB-HRW">Harrow</option><option value="GB-HPL">Hartlepool</option><option value="GB-HAV">Havering</option><option value="GB-HEF">Herefordshire, County of</option><option value="GB-HRT">Hertfordshire</option><option value="GB-HLD">Highland</option><option value="GB-HIL">Hillingdon</option><option value="GB-HNS">Hounslow</option><option value="GB-IVC">Inverclyde</option><option value="GB-AGY">Isle of Anglesey</option><option value="GB-IOM">Isle of Man</option><option value="GB-IOW">Isle of Wight</option><option value="GB-IOS">Isles of Scilly</option><option value="GB-ISL">Islington</option><option value="GB-JEY">Jersey</option><option value="GB-KEC">Kensington and Chelsea</option><option value="GB-KEN">Kent</option><option value="GB-KHL">Kingston upon Hull, City of</option><option value="GB-KTT">Kingston upon Thames</option><option value="GB-KIR">Kirklees</option><option value="GB-KWL">Knowsley</option><option value="GB-LBH">Lambeth</option><option value="GB-LAN">Lancashire</option><option value="GB-LRN">Larne</option><option value="GB-LDS">Leeds</option><option value="GB-LCE">Leicester</option><option value="GB-LEC">Leicestershire</option><option value="GB-LEW">Lewisham</option><option value="GB-LMV">Limavady</option><option value="GB-LIN">Lincolnshire</option><option value="GB-LSB">Lisburn</option><option value="GB-LIV">Liverpool</option><option value="GB-LND">London, City of</option><option value="GB-LUT">Luton</option><option value="GB-MFT">Magherafelt</option><option value="GB-MAN">Manchester</option><option value="GB-MDW">Medway</option><option value="GB-MTY">Merthyr Tydfil</option><option value="GB-MRT">Merton</option><option value="GB-MDB">Middlesbrough</option><option value="GB-MLN">Midlothian</option><option value="GB-MIK">Milton Keynes</option><option value="GB-MON">Monmouthshire</option><option value="GB-MRY">Moray</option><option value="GB-MYL">Moyle</option><option value="GB-NTL">Neath Port Talbot</option><option value="GB-NET">Newcastle upon Tyne</option><option value="GB-NWM">Newham</option><option value="GB-NWP">Newport</option><option value="GB-NYM">Newry and Mourne</option><option value="GB-NTA">Newtownabbey</option><option value="GB-NFK">Norfolk</option><option value="GB-NAY">North Ayrshire</option><option value="GB-NDN">North Down</option><option value="GB-NEL">North East Lincolnshire</option><option value="GB-NLK">North Lanarkshire</option><option value="GB-NLN">North Lincolnshire</option><option value="GB-NSM">North Somerset</option><option value="GB-NTY">North Tyneside</option><option value="GB-NYK">North Yorkshire</option><option value="GB-NTH">Northamptonshire</option><option value="GB-NBL">Northumberland</option><option value="GB-NGM">Nottingham</option><option value="GB-NTT">Nottinghamshire</option><option value="GB-OLD">Oldham</option><option value="GB-OMH">Omagh</option><option value="GB-ORK">Orkney Islands</option><option value="GB-OXF">Oxfordshire</option><option value="GB-PEM">Pembrokeshire</option><option value="GB-PKN">Perth and Kinross</option><option value="GB-PTE">Peterborough</option><option value="GB-PLY">Plymouth</option><option value="GB-POL">Poole</option><option value="GB-POR">Portsmouth</option><option value="GB-POW">Powys</option><option value="GB-RDG">Reading</option><option value="GB-RDB">Redbridge</option><option value="GB-RCC">Redcar and Cleveland</option><option value="GB-RFW">Renfrewshire</option><option value="GB-RCT">Rhondda, Cynon, Ta</option><option value="GB-RIC">Richmond upon Thames</option><option value="GB-RCH">Rochdale</option><option value="GB-ROT">Rotherham</option><option value="GB-RUT">Rutland</option><option value="GB-SLF">Salford</option><option value="GB-SAW">Sandwell</option><option value="GB-SCB">Scottish Borders, The</option><option value="GB-SFT">Sefton</option><option value="GB-SHF">Sheffield</option><option value="GB-ZET">Shetland Islands</option><option value="GB-SHR">Shropshire</option><option value="GB-SLG">Slough</option><option value="GB-SOL">Solihull</option><option value="GB-SOM">Somerset</option><option value="GB-SAY">South Ayrshire</option><option value="GB-SGC">South Gloucestershire</option><option value="GB-SLK">South Lanarkshire</option><option value="GB-STY">South Tyneside</option><option value="GB-SYK">South Yorkshire</option><option value="GB-STH">Southampton</option><option value="GB-SOS">Southend-on-Sea</option><option value="GB-SWK">Southwark</option><option value="GB-SHN">St. Helens</option><option value="GB-STS">Staffordshire</option><option value="GB-STG">Stirling</option><option value="GB-SKP">Stockport</option><option value="GB-STT">Stockton-on-Tees</option><option value="GB-STE">Stoke-on-Trent</option><option value="GB-STB">Strabane</option><option value="GB-SFK">Suffolk</option><option value="GB-SND">Sunderland</option><option value="GB-SRY">Surrey</option><option value="GB-STN">Sutton</option><option value="GB-SWA">Swansea</option><option value="GB-SWD">Swindon</option><option value="GB-TAM">Tameside</option><option value="GB-TFW">Telford and Wrekin</option><option value="GB-THR">Thurrock</option><option value="GB-TOB">Torbay</option><option value="GB-TOF">Torfaen</option><option value="GB-TWH">Tower Hamlets</option><option value="GB-TRF">Trafford</option><option value="GB-VGL">Vale of Glamorgan, T</option><option value="GB-WKF">Wakefield</option><option value="GB-WLL">Walsall</option><option value="GB-WFT">Waltham Forest</option><option value="GB-WND">Wandsworth</option><option value="GB-WRT">Warrington</option><option value="GB-WAR">Warwickshire</option><option value="GB-WBK">West Berkshire</option><option value="GB-WDU">West Dunbartonshire</option><option value="GB-WLN">West Lothian</option><option value="GB-WMD">West Midlands</option><option value="GB-WSX">West Sussex</option><option value="GB-WYK">West Yorkshire</option><option value="GB-WSM">Westminster</option><option value="GB-WGN">Wigan</option><option value="GB-WIL">Wiltshire</option><option value="GB-WNM">Windsor and Maidenhead</option><option value="GB-WRL">Wirral</option><option value="GB-WOK">Wokingham</option><option value="GB-WLV">Wolverhampton</option><option value="GB-WOC">Worcester</option><option value="GB-WOR">Worcestershire</option><option value="GB-WRX">Wrexham</option><option value="GB-YOR">York</option></select>';
	document.getElementById('provinceTag').innerHTML ="";} else if (ctry == "CA") { document.getElementById('stateOptions').innerHTML = '<select name="state" id="state" class="formtb FormField"><option value="AB">Alberta</option><option value="BC">British Columbia</option><option value="MB">Manitoba</option><option value="NB">New Brunswick</option><option value="NL">Newfoundland and Labrador</option><option value="NT">Northwest Territories</option><option value="NS">Nova Scotia</option><option value="NU">Nunavut</option><option value="ON">Ontario</option><option value="PE">Prince Edward Island</option><option value="QC">Quebec</option><option value="SK">Saskatchewan</option><option value="YT">Yukon</option></select>';
	document.getElementById('provinceTag').innerHTML ="(Province/Region)";} else if (ctry == "US") {document.getElementById('stateOptions').innerHTML = '<select name="state" id="state" class="formtb FormField"><option value="AL">Alabama</option><option value="AK">Alaska</option><option value="AS">American Samoa</option><option value="AZ">Arizona</option><option value="AR">Arkansas</option><option value="AE-A">Armed Forces Africa</option><option value="AA">Armed Forces Americas</option><option value="AE-C">Armed Forces Canada</option><option value="AE-E">Armed Forces Europe</option><option value="AE-M">Armed Forces Middle East</option><option value="AP">Armed Forces Pacific</option><option value="CA">California</option><option value="CO">Colorado</option><option value="CT">Connecticut</option><option value="DE">Delaware</option><option value="DC">District of Columbia</option><option value="FM">Federated States of Micronesia</option><option value="FL">Florida</option><option value="GA">Georgia</option><option value="GU">Guam</option><option value="HI">Hawaii</option><option value="ID">Idaho</option><option value="IL">Illinois</option><option value="IN">Indiana</option><option value="IA">Iowa</option><option value="KS">Kansas</option><option value="KY">Kentucky</option><option value="LA">Louisiana</option><option value="ME">Maine</option><option value="MD">Maryland</option><option value="MA">Massachusetts</option><option value="MI">Michigan</option><option value="MN">Minnesota</option><option value="MS">Mississippi</option><option value="MO">Missouri</option><option value="MT">Montana</option><option value="NE">Nebraska</option><option value="NV">Nevada</option><option value="NH">New Hampshire</option><option value="NJ">New Jersey</option><option value="NM">New Mexico</option><option value="NY">New York</option><option value="NC">North Carolina</option><option value="ND">North Dakota</option><option value="MP">Northern Mariana Islands</option><option value="OH">Ohio</option><option value="OK">Oklahoma</option><option value="OR">Oregon</option><option value="PA">Pennsylvania</option><option value="PR">Puerto Rico</option><option value="MH">Republic of Marshall Islands</option><option value="RI">Rhode Island</option><option value="SC">South Carolina</option><option value="SD">South Dakota</option><option value="TN">Tennessee</option><option value="TX">Texas</option><option value="UT">Utah</option><option value="VT">Vermont</option><option value="VI">Virgin Islands of the U.S.</option><option value="VA">Virginia</option><option value="WA">Washington</option><option value="WV">West Virginia</option><option value="WI">Wisconsin</option><option value="WY">Wyoming</option></select>';
	document.getElementById('provinceTag').innerHTML ="";} else {document.getElementById('stateOptions').innerHTML = '<input type="text" class="formtb FormField" id="state" name="state" value="" />';
	document.getElementById('provinceTag').innerHTML ="";}}
</script>
		</head>

		<body>
<div class="header2">
          <div id="AjaxLoading"><img src="/theme/assets/ohn/images/bluegreen/ajax-loader.gif" alt="Loading..." />&nbsp;Loading... Please wait...</div>
          <div class="siteinfo">
    <p>OHC University</p>
    <p>OHC University</p>
  </div>
        </div>
<div class="center" style="margin-top:-65px;">
          <div class="container">
    <div class="content2">
              <div class="left">
        <div class="introleft" style="background-image: url(/theme/assets/ohn/images/bluegreen/100.jpg);">
                  <div id="cart">
            <div style="background: #efefef;" class="tblcont">
                      <div class="desccol">
                <p style="margin: 0px;">Immediate Access Upon Payment</p>
                <p style="color: #ff0000; margin: 0px; text-align=:center">One Time Charge Only</p>
              </div>
                      <div class="pricingcol"> ONE PAYMENT (US DOLLAR)<br />
                Tax: <span id="taxrate">$0.00</span> </div>
                      <div class="clear"></div>
                    </div>
            <div style="background: #e9e9e9;" class="tblcont">
                      <div class="desccol" style="font-size: 15px; font-style: italic; color:gray">$100.00 Discount From $197.95, Now at $97.95</div>
                      <div class="pricingcol">
                <p style="margin: 0px;">Product Price: $97.95</p>
              </div>
                      <div class="clear"></div>
                    </div>
            <div style="background: #e9e9e9;" class="tblcont">
                      <div class="desccol">Total Payment</div>
                      <div class="pricingcol">
                <p style="margin: 0px;" id="totaltopay">$97.95</p>
              </div>
                      <div class="clear"></div>
                    </div>
          </div>
                  <div> <img src="/theme/assets/ohn/images/bluegreen/claim.png" alt="claim" /> </div>
                </div>
        <div class="testi">
                  <div class="testividholder"> <img src="/theme/assets/ohn/images/bluegreen/roger.png" style="float:left" alt="Loading..." /> </div>
                  <div class="testitext">
            <p> <em>"I can sleep in whenever I want. Be financially stable...buy my own house, an engagement ring, a new truck for my dad!"</em><br />
                      <strong>- Kyle H, Nebraska</strong> </p>
          </div>
                </div>
        <div class="testi">
                  <div class="testividholder"> <img src="/theme/assets/ohn/images/bluegreen/gale.png" style="float:left" alt="gale" /> </div>
                  <div class="testitext">
            <p> <em>&quot;Enjoy dining out more. Giving my 11 grandchildren gifts... able to give us a little more available cash to do things for our family.&quot;</em> <strong> - Regina S, North Carolina </strong> </p>
          </div>
                </div>
      </div>
              <div class="right">
        <div class="formtop"></div>
      </div>
              <form id="checkoutForm-" action="/discount" name="checkoutForm" class="form" onSubmit="return false">
        <div class="formcontentholder">
                  <div class="formcontent">
            <div id="processloader" style="display: none"> <img src="/theme/assets/ohn/images/bluegreen/loader.gif" alt="loading..." />
                      <p>Please wait while we are processing your request.</p>
                    </div>
            <div id="inps"> 
                      <!-- BILLING INFORMATION -->
                      <div class="inpcontainer">
                <div class="formlabel">
                          <p id="first_label" >First Name</p>
                        </div>
                <dd class="forminput" id="_label">
                          <input type="text" class="formtb FormField" id="first" name="first" value="" />
                        </dd>
                <div class="clear"></div>
              </div>
                      <div class="inpcontainer">
                <div class="formlabel">
                          <p id="last_label">Last Name</p>
                        </div>
                <dd class="forminput">
                          <input type="text" class="formtb FormField" id="last" name="last" value="" />
                        </dd>
                <div class="clear"></div>
              </div>
                      <div class="inpcontainer">
                <div class="formlabel">
                          <p id="address_label">Billing Address</p>
                        </div>
                <dd class="forminput">
                          <input type="text" class="formtb FormField" id="address" name="address" value="" />
                        </dd>
                <div class="clear"></div>
              </div>
                      <div class="inpcontainer">
                <div class="formlabel">
                          <p id="city_label">City/Suburb</p>
                        </div>
                <dd class="forminput">
                          <input type="text" class="formtb FormField" id="city" name="city" value="" />
                        </dd>
                <div class="clear"></div>
              </div>
                      <div class="inpcontainer">
                <div class="formlabel">
                          <p id="country_label">Country</p>
                        </div>
                <dd class="forminput">
                    <select class="formtb FormField" style="width: 225px" id="country" name="country"  size="1" onChange="updateStatesMenu(this.value)">
                    <option value="">Choose a Country</option>
                    
                    <option value="AX">Aaland Islands</option>
                    <option value="AF">Afghanistan</option>
                    <option value="AL">Albania</option>
                    <option value="DZ">Algeria</option>
                    <option value="AS">American Samoa</option>
                    <option value="AD">Andorra</option>
                    <option value="AO">Angola</option>
                    <option value="AI">Anguilla</option>
                    <option value="AQ">Antarctica</option>
                    <option value="AG">Antigua and Barbuda</option>
                    <option value="AR">Argentina</option>
                    <option value="AM">Armenia</option>
                    <option value="AW">Aruba</option>
                    <option value="AU">Australia</option>
                    <option value="AT">Austria</option>
                    <option value="AZ">Azerbaijan</option>
                    <option value="BS">Bahamas</option>
                    <option value="BH">Bahrain</option>
                    <option value="BD">Bangladesh</option>
                    <option value="BB">Barbados</option>
                    <option value="BY">Belarus</option>
                    <option value="BE">Belgium</option>
                    <option value="BZ">Belize</option>
                    <option value="BJ">Benin</option>
                    <option value="BM">Bermuda</option>
                    <option value="BT">Bhutan</option>
                    <option value="BO">Bolivia</option>
                    <option value="BA">Bosnia and Herzegowina</option>
                    <option value="BW">Botswana</option>
                    <option value="BV">Bouvet Island</option>
                    <option value="BR">Brazil</option>
                    <option value="IO">British Indian Ocean Territory</option>
                    <option value="BN">Brunei Darussalam</option>
                    <option value="BG">Bulgaria</option>
                    <option value="BF">Burkina Faso</option>
                    <option value="BI">Burundi</option>
                    <option value="KH">Cambodia</option>
                    <option value="CM">Cameroon</option>
                    <option value="CA">Canada</option>
                    <option value="CV">Cape Verde</option>
                    <option value="KY">Cayman Islands</option>
                    <option value="CF">Central African Republic</option>
                    <option value="TD">Chad</option>
                    <option value="CL">Chile</option>
                    <option value="CN">China</option>
                    <option value="CX">Christmas Island</option>
                    <option value="CC">Cocos (Keeling) Islands</option>
                    <option value="CO">Colombia</option>
                    <option value="KM">Comoros</option>
                    <option value="CG">Congo</option>
                    <option value="CK">Cook Islands</option>
                    <option value="CR">Costa Rica</option>
                    <option value="CI">Cote D'Ivoire</option>
                    <option value="HR">Croatia</option>
                    <option value="CU">Cuba</option>
                    <option value="CY">Cyprus</option>
                    <option value="CZ">Czech Republic</option>
                    <option value="DK">Denmark</option>
                    <option value="DJ">Djibouti</option>
                    <option value="DM">Dominica</option>
                    <option value="DO">Dominican Republic</option>
                    <option value="TP">East Timor</option>
                    <option value="EC">Ecuador</option>
                    <option value="EG">Egypt</option>
                    <option value="SV">El Salvador</option>
                    <option value="EN">England</option>
                    <option value="GQ">Equatorial Guinea</option>
                    <option value="ER">Eritrea</option>
                    <option value="EE">Estonia</option>
                    <option value="ET">Ethiopia</option>
                    <option value="FK">Falkland Islands (Malvinas)</option>
                    <option value="FO">Faroe Islands</option>
                    <option value="FJ">Fiji</option>
                    <option value="FI">Finland</option>
                    <option value="FR">France</option>
                    <option value="FX">France, Metropolitan</option>
                    <option value="GF">French Guiana</option>
                    <option value="PF">French Polynesia</option>
                    <option value="TF">French Southern Territories</option>
                    <option value="GA">Gabon</option>
                    <option value="GM">Gambia</option>
                    <option value="GE">Georgia</option>
                    <option value="DE">Germany</option>
                    <option value="GH">Ghana</option>
                    <option value="GI">Gibraltar</option>
                    <option value="GR">Greece</option>
                    <option value="GL">Greenland</option>
                    <option value="GD">Grenada</option>
                    <option value="GP">Guadeloupe</option>
                    <option value="GU">Guam</option>
                    <option value="GT">Guatemala</option>
                    <option value="GB">Guernsey</option>
                    <option value="GN">Guinea</option>
                    <option value="GW">Guinea-bissau</option>
                    <option value="GY">Guyana</option>
                    <option value="HT">Haiti</option>
                    <option value="HM">Heard and Mc Donald Islands</option>
                    <option value="HN">Honduras</option>
                    <option value="HK">Hong Kong</option>
                    <option value="HU">Hungary</option>
                    <option value="IS">Iceland</option>
                    <option value="IN">India</option>
                    <option value="ID">Indonesia</option>
                    <option value="IR">Iran (Islamic Republic of)</option>
                    <option value="IQ">Iraq</option>
                    <option value="IE">Ireland</option>
                    <option value="IM">Isle of Man</option>
                    <option value="IL">Israel</option>
                    <option value="IT">Italy</option>
                    <option value="JM">Jamaica</option>
                    <option value="JP">Japan</option>
                    <option value="JY">Jersey</option>
                    <option value="JO">Jordan</option>
                    <option value="KZ">Kazakhstan</option>
                    <option value="KE">Kenya</option>
                    <option value="KI">Kiribati</option>
                    <option value="KP">Korea, Democratic People's Republic of</option>
                    <option value="KR">Korea, Republic of</option>
                    <option value="KW">Kuwait</option>
                    <option value="KG">Kyrgyzstan</option>
                    <option value="LA">Lao People's Democratic Republic</option>
                    <option value="LV">Latvia</option>
                    <option value="LB">Lebanon</option>
                    <option value="LS">Lesotho</option>
                    <option value="LR">Liberia</option>
                    <option value="LY">Libyan Arab Jamahiriya</option>
                    <option value="LI">Liechtenstein</option>
                    <option value="LT">Lithuania</option>
                    <option value="LU">Luxembourg</option>
                    <option value="MO">Macau</option>
                    <option value="MK">Macedonia, The Former Yugoslav Republic of</option>
                    <option value="MG">Madagascar</option>
                    <option value="MW">Malawi</option>
                    <option value="MY">Malaysia</option>
                    <option value="MV">Maldives</option>
                    <option value="ML">Mali</option>
                    <option value="MT">Malta</option>
                    <option value="MH">Marshall Islands</option>
                    <option value="MQ">Martinique</option>
                    <option value="MR">Mauritania</option>
                    <option value="MU">Mauritius</option>
                    <option value="YT">Mayotte</option>
                    <option value="MX">Mexico</option>
                    <option value="FM">Micronesia, Federated States of</option>
                    <option value="MD">Moldova, Republic of</option>
                    <option value="MC">Monaco</option>
                    <option value="MN">Mongolia</option>
                    <option value="MS">Montserrat</option>
                    <option value="MA">Morocco</option>
                    <option value="MZ">Mozambique</option>
                    <option value="MM">Myanmar</option>
                    <option value="NA">Namibia</option>
                    <option value="NR">Nauru</option>
                    <option value="NP">Nepal</option>
                    <option value="NL">Netherlands</option>
                    <option value="AN">Netherlands Antilles</option>
                    <option value="NC">New Caledonia</option>
                    <option value="NZ">New Zealand</option>
                    <option value="NI">Nicaragua</option>
                    <option value="NE">Niger</option>
                    <option value="NG">Nigeria</option>
                    <option value="NU">Niue</option>
                    <option value="NF">Norfolk Island</option>
                    <option value="ND">Northern Ireland</option>
                    <option value="MP">Northern Mariana Islands</option>
                    <option value="NO">Norway</option>
                    <option value="OM">Oman</option>
                    <option value="PK">Pakistan</option>
                    <option value="PW">Palau</option>
                    <option value="PA">Panama</option>
                    <option value="PG">Papua New Guinea</option>
                    <option value="PY">Paraguay</option>
                    <option value="PE">Peru</option>
                    <option value="PH">Philippines</option>
                    <option value="PN">Pitcairn</option>
                    <option value="PL">Poland</option>
                    <option value="PT">Portugal</option>
                    <option value="PR">Puerto Rico</option>
                    <option value="QA">Qatar</option>
                    <option value="RE">Reunion</option>
                    <option value="RO">Romania</option>
                    <option value="RU">Russian Federation</option>
                    <option value="RW">Rwanda</option>
                    <option value="KN">Saint Kitts and Nevis</option>
                    <option value="LC">Saint Lucia</option>
                    <option value="VC">Saint Vincent and the Grenadines</option>
                    <option value="WS">Samoa</option>
                    <option value="SM">San Marino</option>
                    <option value="ST">Sao Tome and Principe</option>
                    <option value="SA">Saudi Arabia</option>
                    <option value="SS">Scotland</option>
                    <option value="SN">Senegal</option>
                    <option value="SC">Seychelles</option>
                    <option value="SL">Sierra Leone</option>
                    <option value="SG">Singapore</option>
                    <option value="SK">Slovakia (Slovak Republic)</option>
                    <option value="SI">Slovenia</option>
                    <option value="SB">Solomon Islands</option>
                    <option value="SO">Somalia</option>
                    <option value="ZA">South Africa</option>
                    <option value="GS">South Georgia and the South Sandwich Islands</option>
                    <option value="ES">Spain</option>
                    <option value="LK">Sri Lanka</option>
                    <option value="SH">St. Helena</option>
                    <option value="PM">St. Pierre and Miquelon</option>
                    <option value="SD">Sudan</option>
                    <option value="SR">Suriname</option>
                    <option value="SJ">Svalbard and Jan Mayen Islands</option>
                    <option value="SZ">Swaziland</option>
                    <option value="SE">Sweden</option>
                    <option value="CH">Switzerland</option>
                    <option value="SY">Syrian Arab Republic</option>
                    <option value="TW">Taiwan</option>
                    <option value="TJ">Tajikistan</option>
                    <option value="TZ">Tanzania, United Republic of</option>
                    <option value="TH">Thailand</option>
                    <option value="TG">Togo</option>
                    <option value="TK">Tokelau</option>
                    <option value="TO">Tonga</option>
                    <option value="TT">Trinidad and Tobago</option>
                    <option value="TN">Tunisia</option>
                    <option value="TR">Turkey</option>
                    <option value="TM">Turkmenistan</option>
                    <option value="TC">Turks and Caicos Islands</option>
                    <option value="TV">Tuvalu</option>
                    <option value="UG">Uganda</option>
                    <option value="UA">Ukraine</option>
                    <option value="AE">United Arab Emirates</option>
                    <option value="GB">United Kingdom</option>
                    <option value="US" selected="selected">United States</option>
                    <option value="UM">United States Minor Outlying Islands</option>
                    <option value="UY">Uruguay</option>
                    <option value="UZ">Uzbekistan</option>
                    <option value="VU">Vanuatu</option>
                    <option value="VA">Vatican City State (Holy See)</option>
                    <option value="VE">Venezuela</option>
                    <option value="VN">Viet Nam</option>
                    <option value="VG">Virgin Islands (British)</option>
                    <option value="VI">Virgin Islands (U.S.)</option>
                    <option value="WL">Wales</option>
                    <option value="WF">Wallis and Futuna Islands</option>
                    <option value="EH">Western Sahara</option>
                    <option value="YE">Yemen</option>
                    <option value="YU">Yugoslavia</option>
                    <option value="ZR">Zaire</option>
                    <option value="ZM">Zambia</option>
                    <option value="ZW">Zimbabwe</option>                  </select>
                        </dd>
                <div class="clear"></div>
              </div>
                      <div class="inpcontainer">
                <div class="formlabel">
                          <p id="state_label">State/Province</p>
                        </div>
                <dd class="forminput">
                          <div id="stateOptions">
                    <select name="state" id="state" class="formtb FormField">
                              <option value="AL">Alabama</option>
<option value="AK">Alaska</option>
<option value="AS">American Samoa</option>
<option value="AZ">Arizona</option>
<option value="AR">Arkansas</option>
<option value="AE-A">Armed Forces Africa</option>
<option value="AA">Armed Forces Americas</option>
<option value="AE-C">Armed Forces Canada</option>
<option value="AE-E">Armed Forces Europe</option>
<option value="AE-M">Armed Forces Middle East</option>
<option value="AP">Armed Forces Pacific</option>
<option value="CA">California</option>
<option value="CO">Colorado</option>
<option value="CT">Connecticut</option>
<option value="DE">Delaware</option>
<option value="DC">District of Columbia</option>
<option value="FM">Federated States of Micronesia</option>
<option value="FL">Florida</option>
<option value="GA">Georgia</option>
<option value="GU">Guam</option>
<option value="HI">Hawaii</option>
<option value="ID">Idaho</option>
<option value="IL">Illinois</option>
<option value="IN">Indiana</option>
<option value="IA">Iowa</option>
<option value="KS">Kansas</option>
<option value="KY">Kentucky</option>
<option value="LA">Louisiana</option>
<option value="ME">Maine</option>
<option value="MD">Maryland</option>
<option value="MA">Massachusetts</option>
<option value="MI">Michigan</option>
<option value="MN">Minnesota</option>
<option value="MS">Mississippi</option>
<option value="MO">Missouri</option>
<option value="MT">Montana</option>
<option value="NE">Nebraska</option>
<option value="NV">Nevada</option>
<option value="NH">New Hampshire</option>
<option value="NJ">New Jersey</option>
<option value="NM">New Mexico</option>
<option value="NY">New York</option>
<option value="NC">North Carolina</option>
<option value="ND">North Dakota</option>
<option value="MP">Northern Mariana Islands</option>
<option value="OH">Ohio</option>
<option value="OK">Oklahoma</option>
<option value="OR">Oregon</option>
<option value="PA">Pennsylvania</option>
<option value="PR">Puerto Rico</option>
<option value="MH">Republic of Marshall Islands</option>
<option value="RI">Rhode Island</option>
<option value="SC">South Carolina</option>
<option value="SD">South Dakota</option>
<option value="TN">Tennessee</option>
<option value="TX">Texas</option>
<option value="UT">Utah</option>
<option value="VT">Vermont</option>
<option value="VI">Virgin Islands of the U.S.</option>
<option value="VA">Virginia</option>
<option value="WA">Washington</option>
<option value="WV">West Virginia</option>
<option value="WI">Wisconsin</option>
<option value="WY">Wyoming</option>
                            </select>
                  </div>
                        </dd>
                <div class="clear"></div>
              </div>
                      <div class="inpcontainer">
                <div class="formlabel">
                          <p id="zip_label">Zip/Postcode</p>
                        </div>
                <dd class="forminput">
                          <input type="hidden" value="Zip" id="input13" />
                          <input type="text" class="formtb FormField" id="zip" name="zip" value="" />
                        </dd>
                <div class="clear"></div>
              </div>
                      <div class="inpcontainer">
                <div class="formlabel">
                          <p id="phone_label">Phone Number</p>
                        </div>
                <dd class="forminput">
                          <input type="hidden" value="Phone" id="input4" />
                          <input type="text" class="formtb FormField" id="phone" name="phone" value="" />
                        </dd>
                <div class="clear"></div>
              </div>
                      <div class="inpcontainer">
                <div class="formlabel">
                          <p id="email_label">Email Address</p>
                        </div>
                <dd class="forminput">
                          <input type="hidden" value="Email Address" id="input1" />
                          <input type="text" class="formtb FormField" id="email" name="email" value="" />
                        </dd>
                <div class="clear"></div>
              </div>
                      <!-- email info again -->
                      <div class="inpcontainer">
                <div class="formlabel">
                          <p id="email_label2">Verify Email</p>
                        </div>
                <dd class="forminput">
                          <input type="text" name="email2" id="email2" class="formtb FormField" value="" />
                        </dd>
                <div class="clear"></div>
              </div>
                      <!-- CREDIT CARD INFORMATION -->
                      <div class="inpcontainer">
                <div class="formlabel">
                          <p id="cc_number_label">Credit Card No</p>
                        </div>
                <div class="forminput">
                          <input class="formtb" style="width:170px;" type="text" name="cc_number" id="cc_number" value="" />
                          &nbsp;&nbsp;<a id="info1" title=""><img src="/theme/assets/ohn/images/bluegreen/info-icon.png" alt="Loading..." /></a> </div>
                <div class="clear"></div>
              </div>
                      <div class="inpcontainer">
                <div class="formlabel">
                          <p id="cc_exp_label">Expiration Date</p>
                        </div>
                <div class="forminput">
                          <select name="cc_month" id="cc_month" class="formtb" style="width:100px;">
                    <option value='01'>01 - Jan</option>
                    <option value='02'>02 - Feb</option>
                    <option value='03'>03 - Mar</option>
                    <option value='04'>04 - Apr</option>
                    <option value='05'>05 - May</option>
                    <option value='06'>06 - Jun</option>
                    <option value='07'>07 - Jul</option>
                    <option value='08'>08 - Aug</option>
                    <option value='09'>09 - Sep</option>
                    <option value='10'>10 - Oct</option>
                    <option value='11'>11 - Nov</option>
                    <option value='12'>12 - Dec</option>
                  </select>
                          <select name="cc_year" id="cc_year" class="formtb" style="width:100px;">
                    
                    <option  value="2014">2014</option>
                    <option  value="2015">2015</option>
                    <option  value="2016">2016</option>
                    <option  value="2017">2017</option>
                    <option  value="2018">2018</option>
                    <option  value="2019">2019</option>
                    <option  value="2020">2020</option>
                    <option  value="2021">2021</option>
                    <option  value="2022">2022</option>                  </select>
                        </div>
                <div class="clear"></div>
              </div>
                      <div class="inpcontainer">
                <div class="formlabel">
                          <p id="cc_cvv_label">CVV</p>
                        </div>
                <div class="forminput">
                          <input class="formtb" style="width:80px;" type="text" name="cc_cvv" id="cc_cvv" value=""/>
                          &nbsp;&nbsp;<a id="info2" title=""><img src="/theme/assets/ohn/images/bluegreen/info-icon.png" alt="Loading…" /></a> </div>
                <div class="clear"></div>
              </div>
                      
                      <!-- TERMS AND CONDITIONS AGREEMENT-->
                      <div class="tos">
                <input type="checkbox" name="disclaimer" id="disclaimer" value="disclaimer"/>
                <input name="itc" id="itc" type="hidden" class="short" value="1" />
                <label id="disclaimer_label">I have read and agree to the</label>
                <a href="/theme/assets/ohn/terms" title="Terms and Conditions" class="jdialog"><strong>Terms and Conditions</strong></a>.
                <div class="clear"></div>
              </div>
                      <div class="access" id="submitter">
				<input type="submit" name="submit" id="submitButton" class="accessbutton" value="" onclick="internalLink=true; barstow(); return false;" />             
				
			</div>
                    </div>
          </div>
                </div>
      </form>
              <div class="formbottom"></div>
              <br />
              <div style="float:right; margin: 0px; padding-top:20px; text-align:center;"> <a href="6.html#" onClick="window.open('http://www.security-guaranteed.com/verify/ohcuniversity/com','mywindow','menubar=1,resizable=1,width=530px,height=800px');" class="badge"><img  src="/theme/assets/ohn/badge/ecommerce" style="margin:5px;" alt="Security Guaranteed" /></a> <a href="6.html#" onClick="window.open('http://www.security-guaranteed.com/verify/ohcuniversity/com','mywindow','menubar=1,resizable=1,width=530px,height=800px');" class="badge"><img src="/theme/assets/ohn/badge/security" style="margin:5px;" alt="Security Guaranteed" /></a> <br>
        <a href="6.html#" onClick="window.open('http://www.security-guaranteed.com/verify/ohcuniversity/com','mywindow','menubar=1,resizable=1,width=530px,height=800px'); class="badge""><img src="/theme/assets/ohn/badge/privacy" style="margin:5px;" alt="Security Guaranteed" /></a> <a href="6.html#" onClick="window.open('http://www.security-guaranteed.com/verify/ohcuniversity/com','mywindow','menubar=1,resizable=1,width=530px,height=800px');" class="badge"><img src="/theme/assets/ohn/badge/business" style="margin:5px;" alt="Security Guaranteed" /></a>        <div style="background: url('https://ohcuniversity.com/images/3ds/bggray_01.png') center center no-repeat; height: 15px; width: 391px;"></div>
        <div style="background: url('https://ohcuniversity.com/images/3ds/bggray_02.png') center center repeat-y; width: 391px;">
                  <div style="width: 390px; margin-bottom: -10px; z-index: 2000; position: absolute; left: 548px;"> </div>
                </div>
        <div style="background: url('https://ohcuniversity.com/images/3ds/bggray_03.png') bottom center no-repeat; height: 15px; width: 391px;"></div>
      </div>
            </div>
  </div>
          <div class="footer2"></div>
          <div class="footercontent">
    				<ul class="footermenu">
        <li><a href="/theme/assets/ohn/ohcu-disclaimer" class="jdialog" title="OHCU Disclaimer">DISCLAIMER</a></li>
        <li>|</li>
        <li><a href="/theme/assets/ohn/ohcu-terms" class="jdialog" title="OHCU Terms">TERMS</a></li>
        <li>|</li>
        <li><a href="/theme/assets/ohn/ohcu-refund-policy" class="jdialog" title="OHCU Refund Policy">REFUND POLICY</a></li>
        <li>|</li>
        <li><a href="/theme/assets/ohn/ohcu-privacy" class="jdialog" title="OHCU Privacy Policy">PRIVACY</a></li>
        <li>|</li>
        <li><a href="https://ohcuniversity.com/" target="login">MEMBERS LOGIN</a></li>
        <li>|</li>
        <li><a href="/theme/assets/ohn/ohcu-contact" class="jdialog" title="OHCU Contact Info">CONTACT</a></li>
		</ul>  
<div class="line"></div>
              <p></p>
              <center>
                <strong>IMPORTANT NOTICE!</strong>
              </center>
              <p></p>
              <p>Stock and option trading has large potential rewards, but also large potential risks.  You must be aware of the risks and willing to accept them in order to invest in the futures equity or options markets.  Don’t trade with money you can’t afford to lose.  This is neither a solicitation nor an offer to buy/sell securities, or listed options.</p>
              <div class="line"></div>
            </div>
		
        </div>
<div id='dialog'>s</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js" type="text/javascript"></script> 
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js" type="text/javascript"></script>
<script>

$(".badge").click(function() {
	event.preventDefault();
});

$(document).ready(function() {
	$('a').bind('click', function(event) {
		internalLink = true;
	});
});

function validateEmail(sEmail) {
    var filter = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
    if (filter.test(sEmail)) {
        return true;
    }
    else {
        return false;
    }
}

function resetButton() {
	$("#submitter").css("background","none").html('<input type="submit" name="submit" id="submitButton" class="accessbutton" value="" onclick="internalLink=true; barstow(); return false;" />');
}

$('#statusMessage').hide();
$("#processing").hide();

//$("#submitButton").click(function(event) {
function barstow() {
$("#submitter").css("background","url(/theme/assets/ohn/images/bluegreen/button-processing.png) center center no-repeat").html('<img src="/theme/assets/ohn/images/button-processing-spinner.gif">');
$("p#first_label").css('color', '#ffffff');
$("p#last_label").css('color', '#ffffff');
$("p#address_label").css('color', '#ffffff');
$("p#country_label").css('color', '#ffffff');
$("p#city_label").css('color', '#ffffff');
$("p#state_label").css('color', '#ffffff');
$("p#email_label").css('color', '#ffffff');
$("p#email_label2").css('color', '#ffffff');
$("p#phone_label").css('color', '#ffffff');
$("p#zip_label").css('color', '#ffffff');
$("p#cc_number_label").css('color', '#ffffff');
$("p#cc_exp_label").css('color', '#ffffff');
$("#cc_year").css('color', '#000000'); 
$("#cc_month").css('color', '#000000'); 
$("p#cc_cvv_label").css('color', '#ffffff');
$("#disclaimer_label").css('color', '#ffffff');

// validate and process form here  
$('#statusMessage').hide();
$("#processing").hide();

var first = $("input#first").val();
	if (first.length == 0) {
	$("p#first_label").css('color', 'red');
	$("input#first").focus(); 
	//$('#statusMessage').show(); 
	//$('#statusMessage').text("First Name is required!"); 
	resetButton();
	$( "#submitButton").unbind();
	return false;  
}  
var last = $("input#last").val();
	if (last.length == 0) {
	$("p#last_label").css('color', 'red');
	$("input#last").focus();   
	//$('#statusMessage').show(); 
	//$('#statusMessage').text("Last Name is required!");  
	resetButton();  
	return false;  
}  
var address = $("input#address").val();
	if (address.length == 0) {
	$("p#address_label").css('color', 'red'); 
	$("input#address").focus(); 
	//$('#statusMessage').show(); 
	//$('#statusMessage').text("Address is required!");  
	resetButton();   
	return false;  
}  
var country = document.getElementById('country').value;
	if (country.length == 0) {
	$("p#country_label").css('color', 'red');   
	$("input#country").focus(); 
	//$('#statusMessage').show(); 
	//$('#statusMessage').text("Country is required!");  
	resetButton(); 
	return false;  
}
var city = $("input#city").val();
	if (city.length == 0) {
	$("p#city_label").css('color', 'red');  
	$("input#city").focus(); 
	//$('#statusMessage').show(); 
	//$('#statusMessage').text("City is required!");  
	resetButton();  
	return false;  
}  
var state = document.getElementById('state').value;
	if (state.length == 0) {
	$("p#state_label").css('color', 'red');  
	$("input#state").focus();   
	//$('#statusMessage').show(); 
	//$('#statusMessage').text("State is required!");  
	resetButton(); 
	return false;  
}
/* var email = $("input#email").val();
	if (email.length < 5 || !validateEmail(email)) {
	$("p#email_label").css('color', 'red'); 
	$("input#email").focus(); 
	$('#statusMessage').show(); 
	$('#statusMessage').text("A Valid Email is required!");     
	return false;  
} */

var phone = $("input#phone").val();
	if (phone.length < 10) {
	$("p#phone_label").css('color', 'red'); 
	$("input#phone").focus();  
	//$('#statusMessage').show(); 
	//$('#statusMessage').text("Phone Number is required!");  
	resetButton();  
	return false;  
}  
var zip = $("input#zip").val();
	if (zip.length == 0) {
	$("p#zip_label").css('color', 'red'); 
	$("input#zip").focus(); 
	//$('#statusMessage').show(); 
	//$('#statusMessage').text("Postal/ZIP Code is required!");  
	resetButton();   
	return false;  
}  
var cc_number = $("input#cc_number").val();
	if (cc_number.length < 13) {
	$("p#cc_number_label").css('color', 'red'); 
	$("input#cc_number").focus(); 
	//$('#statusMessage').html("Please check the Credit Card Number");
	resetButton();
	//$('#statusMessage').show();
	$("#processing").hide();  
	return false;  
}  
var year = document.getElementById('cc_year').value;
	if (year.length != 4 || year < 2014 || isNaN(year)) {
	$("p#exp_label").css('color', 'red'); 
	$("#cc_year").css('color', 'red'); 
	$("input#cc_year").focus();  
	//$('#statusMessage').show(); 
	//$('#statusMessage').text("Check your Card Expiration Date!");
	resetButton();    
	return false;  
} 
var month = document.getElementById('cc_month').value;
	if (month.length != 2 || month > 12 || month < 1 || isNaN(month) || (year == 14 && month < 04)) {
	$("p#exp_label").css('color', 'red'); 
	$("#month").css('color', 'red'); 
	$("input#month").focus();
	//$('#statusMessage').show();
	//$('#statusMessage').text("Check your Card Expiration Date!");
	resetButton();
	return false;  
} 
var cc_cvv = $("input#cc_cvv").val();
	if (cc_cvv.length == 0 || cc_cvv.length > 4 || isNaN(cc_cvv)) {
	$("p#cc_cvv_label").css('color', 'red');  
	$("input#cc_cvv").focus();
	//$('#statusMessage').show();
	//$('#statusMessage').html("Check your Card CVV Number! <img src='https://ohcuniversity.com/images/cvv-help.png'>");
	resetButton();
	return false;  
}  
$("#processing").show(); 

var data = $("#checkoutForm").serialize();

window.location = '/discount';

return false;

$.post('/discount', data, function(data) {
	if (data.indexOf('Error:') == 0) {
		//alert('Error starting');
		resetButton();
		epc_disable = false;
		var bits = data.split(';');
		alert(bits[0].replace("Error:", ""));
		var fields = bits[1].split(',');
		for (i=0;i<fields.length;i++) {
			$("p#" + fields[i] + "_label").css('color', 'red');
		}
		return false;
	} else if (data.indexOf('Success') == 0 || data.indexOf('Reloaded') == 0)   {
		//alert('Success...');
		internalLink=true;
		$("#enrollButton").html('<div align="center"><a href="/discount"><img src="https://ohcuniversity.com/images/success-continue.png" alt="CONTINUE!"></a></div>');
		$("checkoutForm").attr("action", "/discount")
		//$('#statusMessage').css('border','2px solid #70a414').html('<h2><a href="/theme/assets/ohn/vip"><img src="https://ohcuniversity.com/images/success-continue.png" alt="CONTINUE!"></a></h2>');
		$("#submitter").html('<a href="/discount"><img src="/theme/assets/ohn/images/bluegreen/button-continue-vip.png"></a>');
		//$('#statusMessage').show();
		//$("#processing").hide().delay(4000);
		window.location = '/discount';
	}
});
}
	
	$(".jdialog").click(function() {
		var myUrl = $(this).attr("href");
		var myTitle = $(this).attr("title");
		$("#dialog").load(myUrl).dialog({
             draggable: true,
			 position: "top",
			 width:'70%',
             title: myTitle,
			 modal:true
		}); 
		return false;
	});	
	</script>
</body>
</html>




<?php
// include footer
//$theme->load('footer');



