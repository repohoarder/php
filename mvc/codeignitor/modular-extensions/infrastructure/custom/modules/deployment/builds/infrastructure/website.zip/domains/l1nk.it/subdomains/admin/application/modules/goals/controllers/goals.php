<?php

class Goals extends MX_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function create()
	{
		$data 	= array();

		// set template layout to use
		$this->template->set_layout('default');

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: Add Goal');

		// load view
		$this->template->build('goals/create', $data);
	}

	public function view()
	{
		$data 	= array();

		// set template layout to use
		$this->template->set_layout('default');

		// set the page's title
		$this->template->title(SITE_TITLE.' Admin: View Goals');

		// load view
		$this->template->build('goals/view', $data);
	}

}