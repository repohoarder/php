
<?php
// testing
$campaigns 	= array(
	array(
		'id'	=> 'all',
		'name'	=> 'All Campaigns'
	),
	array(
		'id'	=> 1,
		'name'	=> 'MaxLeanX Buyer'
	),
	array(
		'id'	=> 3,
		'name'	=> 'Auto Landing Page'
	)
);

?>


<div class="panel-wrapper fixed"> 

	<div class="panel"> 

		<div class="title"> 

			<h4>Add Filters</h4> 

			<div class="collapse">collapse</div> 

		</div>  

		<div class="content"> <!-- ## Panel Content  -->  

			<form method="post" action="">

				<div class="group fixed"> 
					<label>Add Campaign</label>
					<div id="uniform-undefined">
						<select name="campaign" style="opacity: 0;"> 
							<?php
							// iterate all domains
							foreach ($campaigns AS $key => $value):

								// see if we need to auto select this campaign
								$select 	= ($campaign == $value['id'])? 'selected': '';

							?>
								<option value="<?php echo $value['id']; ?>" <?php echo $select; ?>><?php echo $value['name']; ?></option>
							<?php
							endforeach;
							?>
						</select>

						<a href="#" class="button-blue">Add</a>

					</div> 

				</div>

			</form>

		</div>

	</div>

	<div class="shadow"></div> 

</div>

<br><br>


<div class="panel-wrapper"> 

	<div class="panel"> 

		<div class="title"> 
			
			<h4><?php echo ucwords($campaign); ?> Campaign(s)</h4> 

			<div class="collapse"><a href="/lead/export">Export</a></div> 
		</div>  

		<div class="content"> 
			<!-- ## Panel Content  -->  
			<table id="sample-table" class=""> 
				<thead> 
					<tr> 
						<th>Campaign</th>
						<th>Local</th> 
						<th>Domain</th> 
						<th>IP</th>
						<th>Date</th>
					</tr> 
				</thead> 

				<tbody> 
					<tr> 
						<td>MaxLeanX Buyer</td> 
						<td>jsmith</td>
						<td>gmail.com</td>
						<td>98.129.100.23</td> 
						<td></td>
					</tr> 

					<tr> 
						<td>Auto Landing Page</td> 
						<td>jhowley</td>
						<td>yahoo.com</td> 
						<td>89.202.12.45</td> 
						<td></td>
					</tr> 

					<tr> 
						<td>MaxLeanX Buyer</td> 
						<td>jsmith</td>
						<td>gmail.com</td>
						<td>98.129.100.23</td> 
						<td></td>
					</tr> 

					<tr> 
						<td>Auto Landing Page</td> 
						<td>jhowley</td>
						<td>yahoo.com</td> 
						<td>89.202.12.45</td> 
						<td></td>
					</tr> 

					<tr> 
						<td>MaxLeanX Buyer</td> 
						<td>jsmith</td>
						<td>gmail.com</td>
						<td>98.129.100.23</td> 
						<td></td>
					</tr> 

					<tr> 
						<td>Auto Landing Page</td> 
						<td>jhowley</td>
						<td>yahoo.com</td> 
						<td>89.202.12.45</td> 
						<td></td>
					</tr> 

					<tr> 
						<td>MaxLeanX Buyer</td> 
						<td>jsmith</td>
						<td>gmail.com</td>
						<td>98.129.100.23</td> 
						<td></td>
					</tr> 

					<tr> 
						<td>Auto Landing Page</td> 
						<td>jhowley</td>
						<td>yahoo.com</td> 
						<td>89.202.12.45</td> 
						<td></td>
					</tr> 
				</tbody> 
			</table>  
			<!-- ## / Panel Content  --> 

		</div> 
		
	</div>  

	<div class="shadow"></div>

</div>

